// Copyright 2012 Google Inc. All rights reserved.
(function() {

    var data = {
        "resource": {
            "version": "1",

            "macros": [{
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }],
            "tags": [],
            "predicates": [],
            "rules": []
        },
        "runtime": []




    };


    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var aa, ea = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        fa = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            return b ? b.call(a) : {
                next: ea(a)
            }
        },
        ha = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ia;
    if ("function" == typeof Object.setPrototypeOf) ia = Object.setPrototypeOf;
    else {
        var ja;
        a: {
            var ka = {
                    a: !0
                },
                ma = {};
            try {
                ma.__proto__ = ka;
                ja = ma.a;
                break a
            } catch (a) {}
            ja = !1
        }
        ia = ja ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var na = ia,
        oa = function(a, b) {
            a.prototype = ha(b.prototype);
            a.prototype.constructor = a;
            if (na) na(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.uj = b.prototype
        },
        qa = this || self,
        ra = function(a) {
            return a
        };
    var sa = function() {},
        ta = function(a) {
            return "function" == typeof a
        },
        h = function(a) {
            return "string" == typeof a
        },
        ua = function(a) {
            return "number" == typeof a && !isNaN(a)
        },
        va = Array.isArray,
        wa = function(a, b) {
            if (Array.prototype.indexOf) {
                var c = a.indexOf(b);
                return "number" == typeof c ? c : -1
            }
            for (var d = 0; d < a.length; d++)
                if (a[d] === b) return d;
            return -1
        },
        xa = function(a, b) {
            if (a && va(a))
                for (var c = 0; c < a.length; c++)
                    if (a[c] && b(a[c])) return a[c]
        },
        ya = function(a, b) {
            if (!ua(a) || !ua(b) || a > b) a = 0, b = 2147483647;
            return Math.floor(Math.random() * (b -
                a + 1) + a)
        },
        Ca = function(a, b) {
            for (var c = new za, d = 0; d < a.length; d++) c.set(a[d], !0);
            for (var e = 0; e < b.length; e++)
                if (c.get(b[e])) return !0;
            return !1
        },
        Ea = function(a, b) {
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
        },
        Ha = function(a) {
            return !!a && ("[object Arguments]" == Object.prototype.toString.call(a) || Object.prototype.hasOwnProperty.call(a, "callee"))
        },
        Ja = function(a) {
            return Math.round(Number(a)) || 0
        },
        Ma = function(a) {
            return "false" == String(a).toLowerCase() ? !1 : !!a
        },
        Na = function(a) {
            var b = [];
            if (va(a))
                for (var c =
                        0; c < a.length; c++) b.push(String(a[c]));
            return b
        },
        Oa = function(a) {
            return a ? a.replace(/^\s+|\s+$/g, "") : ""
        },
        Pa = function() {
            return new Date(Date.now())
        },
        l = function() {
            return Pa().getTime()
        },
        za = function() {
            this.prefix = "gtm.";
            this.values = {}
        };
    za.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    za.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    var Qa = function(a, b, c) {
            return a && a.hasOwnProperty(b) ? a[b] : c
        },
        Ra = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = void 0;
                    try {
                        c()
                    } catch (d) {}
                }
            }
        },
        Sa = function(a, b) {
            for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
        },
        Ta = function(a) {
            for (var b in a)
                if (a.hasOwnProperty(b)) return !0;
            return !1
        },
        Ua = function(a, b) {
            for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
            return c
        },
        Va = function(a, b) {
            for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
            d[e[e.length - 1]] = b;
            return c
        },
        Wa = /^\w{1,9}$/,
        Xa = function(a, b) {
            a = a || {};
            b = b || ",";
            var c = [];
            Ea(a, function(d, e) {
                Wa.test(d) && e && c.push(d)
            });
            return c.join(b)
        };
    /*

     SPDX-License-Identifier: Apache-2.0
    */
    var Ya, Za = function() {
        if (void 0 === Ya) {
            var a = null,
                b = qa.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: ra,
                        createScript: ra,
                        createScriptURL: ra
                    })
                } catch (c) {
                    qa.console && qa.console.error(c.message)
                }
                Ya = a
            } else Ya = a
        }
        return Ya
    };
    var ab = function(a, b) {
        this.m = b === $a ? a : ""
    };
    ab.prototype.toString = function() {
        return this.m + ""
    };
    var $a = {},
        eb = function(a) {
            var b = Za(),
                c = b ? b.createScriptURL(a) : a;
            return new ab(c, $a)
        };
    var fb = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    var gb;
    a: {
        var hb = qa.navigator;
        if (hb) {
            var ib = hb.userAgent;
            if (ib) {
                gb = ib;
                break a
            }
        }
        gb = ""
    }

    function kb(a) {
        return -1 != gb.indexOf(a)
    };
    var lb = {},
        mb = function(a, b, c) {
            this.m = c === lb ? a : ""
        };
    mb.prototype.toString = function() {
        return this.m.toString()
    };
    var nb = function(a) {
            return a instanceof mb && a.constructor === mb ? a.m : "type_error:SafeHtml"
        },
        ob = function(a) {
            var b = Za(),
                c = b ? b.createHTML(a) : a;
            return new mb(c, null, lb)
        },
        pb = new mb(qa.trustedTypes && qa.trustedTypes.emptyHTML || "", 0, lb);

    function qb(a, b) {
        a.src = b instanceof ab && b.constructor === ab ? b.m : "type_error:TrustedResourceUrl";
        var c, d, e = (a.ownerDocument && a.ownerDocument.defaultView || window).document,
            f = null === (d = e.querySelector) || void 0 === d ? void 0 : d.call(e, "script[nonce]");
        (c = f ? f.nonce || f.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", c)
    };
    var rb = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        sb = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };
    var tb = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        var c = a.firstChild.firstChild;
        a.innerHTML = nb(pb);
        return !c.parentElement
    });
    var B = window,
        G = document,
        ub = navigator,
        vb = G.currentScript && G.currentScript.src,
        wb = function(a, b) {
            var c = B[a];
            B[a] = void 0 === c ? b : c;
            return B[a]
        },
        xb = function(a) {
            var b = G.getElementsByTagName("script")[0] || G.body || G.head;
            b.parentNode.insertBefore(a, b)
        },
        yb = function(a, b) {
            b && (a.addEventListener ? a.onload = b : a.onreadystatechange = function() {
                a.readyState in {
                    loaded: 1,
                    complete: 1
                } && (a.onreadystatechange = null, b())
            })
        },
        zb = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Ab = function(a, b, c, d) {
            var e = G.createElement("script");
            d && Ea(d, function(f, g) {
                f = f.toLowerCase();
                zb.hasOwnProperty(f) || e.setAttribute(f, g)
            });
            e.type = "text/javascript";
            e.async = !0;
            qb(e, eb(a));
            yb(e, b);
            c && (e.onerror = c);
            xb(e);
            return e
        },
        Bb = function() {
            if (vb) {
                var a = vb.toLowerCase();
                if (0 === a.indexOf("https://")) return 2;
                if (0 === a.indexOf("http://")) return 3
            }
            return 1
        },
        Cb = function(a, b) {
            var c = G.createElement("iframe");
            c.height = "0";
            c.width = "0";
            c.style.display = "none";
            c.style.visibility = "hidden";
            var d = G.body && G.body.lastChild || G.body || G.head;
            d.parentNode.insertBefore(c,
                d);
            yb(c, b);
            void 0 !== a && (c.src = a);
            return c
        },
        Eb = function(a, b, c) {
            var d = new Image(1, 1);
            d.onload = function() {
                d.onload = null;
                b && b()
            };
            d.onerror = function() {
                d.onerror = null;
                c && c()
            };
            d.src = a;
            return d
        },
        Fb = function(a, b, c, d) {
            a.addEventListener ? a.addEventListener(b, c, !!d) : a.attachEvent && a.attachEvent("on" + b, c)
        },
        Gb = function(a, b, c) {
            a.removeEventListener ? a.removeEventListener(b, c, !1) : a.detachEvent && a.detachEvent("on" + b, c)
        },
        H = function(a) {
            B.setTimeout(a, 0)
        },
        Hb = function(a, b) {
            return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value :
                null
        },
        Ib = function(a) {
            var b = a.innerText || a.textContent || "";
            b && " " != b && (b = b.replace(/^[\s\xa0]+|[\s\xa0]+$/g, ""));
            b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
            return b
        },
        Jb = function(a) {
            var b = G.createElement("div"),
                c = ob("A<div>" + a + "</div>"),
                d = b;
            if (tb())
                for (; d.lastChild;) d.removeChild(d.lastChild);
            d.innerHTML = nb(c);
            b = b.lastChild;
            for (var e = []; b.firstChild;) e.push(b.removeChild(b.firstChild));
            return e
        },
        Kb = function(a, b, c) {
            c = c || 100;
            for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
            for (var f = a, g = 0; f && g <= c; g++) {
                if (d[String(f.tagName).toLowerCase()]) return f;
                f = f.parentElement
            }
            return null
        },
        Lb = function(a) {
            var b;
            try {
                b = ub.sendBeacon && ub.sendBeacon(a)
            } catch (c) {}
            b || Eb(a)
        },
        Mb = function(a, b) {
            var c = a[b];
            c && "string" === typeof c.animVal && (c = c.animVal);
            return c
        },
        Nb = function(a) {
            var b = G.featurePolicy;
            return b && ta(b.features) ? -1 !== b.features().indexOf(a) : !1
        };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
    var Ob = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        Pb = function(a) {
            if (null == a) return String(a);
            var b = Ob.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        Qb = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        Rb = function(a) {
            if (!a || "object" != Pb(a) || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !Qb(a, "constructor") && !Qb(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return void 0 ===
                b || Qb(a, b)
        },
        M = function(a, b) {
            var c = b || ("array" == Pb(a) ? [] : {}),
                d;
            for (d in a)
                if (Qb(a, d)) {
                    var e = a[d];
                    "array" == Pb(e) ? ("array" != Pb(c[d]) && (c[d] = []), c[d] = M(e, c[d])) : Rb(e) ? (Rb(c[d]) || (c[d] = {}), c[d] = M(e, c[d])) : c[d] = e
                }
            return c
        };
    var Yb = function(a) {
        if (void 0 === a || va(a) || Rb(a)) return !0;
        switch (typeof a) {
            case "boolean":
            case "number":
            case "string":
            case "function":
                return !0
        }
        return !1
    };
    var Zb = function() {
        var a = function(b) {
            return {
                toString: function() {
                    return b
                }
            }
        };
        return {
            Lg: a("consent"),
            Mg: a("consent_always_fire"),
            Ne: a("convert_case_to"),
            Oe: a("convert_false_to"),
            Pe: a("convert_null_to"),
            Qe: a("convert_true_to"),
            Re: a("convert_undefined_to"),
            ej: a("debug_mode_metadata"),
            gj: a("event_data_overrides"),
            jb: a("function"),
            Ah: a("instance_name"),
            Ch: a("live_only"),
            Dh: a("malware_disabled"),
            Eh: a("metadata"),
            ij: a("original_activity_id"),
            jj: a("original_vendor_template_id"),
            Gh: a("once_per_event"),
            zf: a("once_per_load"),
            lj: a("priority_override"),
            mj: a("respected_consent_types"),
            Df: a("setup_tags"),
            Ff: a("tag_id"),
            Gf: a("teardown_tags")
        }
    }();
    var zc;
    var Ac = [],
        Bc = [],
        Cc = [],
        Dc = [],
        Ec = [],
        Ic = {},
        Jc, Kc, Lc, Mc = function(a, b) {
            var c = a["function"];
            if (!c) throw Error("Error: No function name given for function call.");
            var d = Ic[c],
                e = {},
                f;
            for (f in a)
                if (a.hasOwnProperty(f))
                    if (0 === f.indexOf("vtp_")) d && b && b.Rf && b.Rf(a[f]), e[void 0 !== d ? f : f.substr(4)] = a[f];
                    else if (f === Zb.Mg.toString() && a[f]) {}
            d && b && b.Qf && (e.vtp_gtmCachedValues = b.Qf);
            return void 0 !== d ? d(e) : zc(c, e, b)
        },
        Oc = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = Nc(a[e], b, c));
            return d
        },
        Nc = function(a, b, c) {
            if (va(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(Nc(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var g = Ac[f];
                        if (!g || b.xe(g)) return;
                        c[f] = !0;
                        try {
                            var k = Oc(g, b, c);
                            k.vtp_gtmEventId = b.id;
                            d = Mc(k, b);
                            Lc && (d = Lc.Vh(d, k))
                        } catch (z) {
                            b.hg && b.hg(z, Number(f)), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var m = 1; m < a.length; m += 2) d[Nc(a[m], b, c)] = Nc(a[m + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var n = !1, p = 1; p < a.length; p++) {
                            var q = Nc(a[p], b, c);
                            Kc && (n = n || q === Kc.Xc);
                            d.push(q)
                        }
                        return Kc && n ? Kc.Zh(d) : d.join("");
                    case "escape":
                        d = Nc(a[1], b, c);
                        if (Kc && va(a[1]) && "macro" === a[1][0] && Kc.vi(a)) return Kc.Ki(d);
                        d = String(d);
                        for (var t = 2; t < a.length; t++) $b[a[t]] && (d = $b[a[t]](d));
                        return d;
                    case "tag":
                        var u = a[1];
                        if (!Dc[u]) throw Error("Unable to resolve tag reference " +
                            u + ".");
                        return d = {
                            Yf: a[2],
                            index: u
                        };
                    case "zb":
                        var r = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        r["function"] = a[1];
                        var v = Pc(r, b, c),
                            x = !!a[4];
                        return x || 2 !== v ? x !== (1 === v) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
                }
            }
            return a
        },
        Pc = function(a, b, c) {
            try {
                return Jc(Oc(a, b, c))
            } catch (d) {
                JSON.stringify(a)
            }
            return 2
        };
    var Sc = function(a) {
            function b(t) {
                for (var u = 0; u < t.length; u++) d[t[u]] = !0
            }
            for (var c = [], d = [], e = Qc(a), f = 0; f < Bc.length; f++) {
                var g = Bc[f],
                    k = Rc(g, e);
                if (k) {
                    for (var m = g.add || [], n = 0; n < m.length; n++) c[m[n]] = !0;
                    b(g.block || [])
                } else null === k && b(g.block || []);
            }
            for (var p = [], q = 0; q < Dc.length; q++) c[q] && !d[q] && (p[q] = !0);
            return p
        },
        Rc = function(a, b) {
            for (var c = a["if"] || [], d = 0; d < c.length; d++) {
                var e = b(c[d]);
                if (0 === e) return !1;
                if (2 === e) return null
            }
            for (var f =
                    a.unless || [], g = 0; g < f.length; g++) {
                var k = b(f[g]);
                if (2 === k) return null;
                if (1 === k) return !1
            }
            return !0
        },
        Qc = function(a) {
            var b = [];
            return function(c) {
                void 0 === b[c] && (b[c] = Pc(Cc[c], a));
                return b[c]
            }
        };
    var Tc = {
        Vh: function(a, b) {
            b[Zb.Ne] && "string" === typeof a && (a = 1 == b[Zb.Ne] ? a.toLowerCase() : a.toUpperCase());
            b.hasOwnProperty(Zb.Pe) && null === a && (a = b[Zb.Pe]);
            b.hasOwnProperty(Zb.Re) && void 0 === a && (a = b[Zb.Re]);
            b.hasOwnProperty(Zb.Qe) && !0 === a && (a = b[Zb.Qe]);
            b.hasOwnProperty(Zb.Oe) && !1 === a && (a = b[Zb.Oe]);
            return a
        }
    };
    var P = {
        cc: "_ee",
        bd: "_syn_or_mod",
        nj: "_uei",
        Vd: "_eu",
        kj: "_pci",
        Bb: "event_callback",
        Nc: "event_timeout",
        xa: "gtag.config",
        Ha: "gtag.get",
        ra: "purchase",
        zb: "refund",
        cb: "begin_checkout",
        wb: "add_to_cart",
        xb: "remove_from_cart",
        Vg: "view_cart",
        Te: "add_to_wishlist",
        Ga: "view_item",
        Rb: "view_promotion",
        Ic: "select_promotion",
        yd: "select_item",
        yb: "view_item_list",
        Se: "add_payment_info",
        Ug: "add_shipping_info",
        Ja: "value_key",
        Sa: "value_callback",
        ya: "allow_ad_personalization_signals",
        Yb: "restricted_data_processing",
        Tb: "allow_google_signals",
        Ba: "cookie_expires",
        Vb: "cookie_update",
        $b: "session_duration",
        Rc: "session_engaged_time",
        Ka: "user_properties",
        na: "transport_url",
        R: "ads_data_redaction",
        sa: "user_data",
        Wb: "first_party_collection",
        C: "ad_storage",
        H: "analytics_storage",
        Le: "region",
        Me: "wait_for_update",
        Aa: "conversion_linker",
        za: "conversion_cookie_prefix",
        ca: "value",
        ba: "currency",
        tf: "trip_type",
        V: "items",
        kf: "passengers",
        Bd: "allow_custom_scripts",
        ac: "session_id",
        rf: "quantity",
        Va: "transaction_id",
        hb: "language",
        Lc: "country",
        Jc: "allow_enhanced_conversions",
        Gd: "aw_merchant_id",
        Ed: "aw_feed_country",
        Fd: "aw_feed_language",
        Dd: "discount",
        aa: "developer_id",
        Sc: "delivery_postal_code",
        Md: "estimated_delivery_date",
        Kd: "shipping",
        Rd: "new_customer",
        Hd: "customer_lifetime_value",
        Ld: "enhanced_conversions",
        Sb: "page_view",
        ma: "linker",
        M: "domains",
        Eb: "decorate_forms",
        ff: "enhanced_conversions_automatic_settings",
        eh: "auto_detection_enabled",
        hf: "ga_temp_client_id"
    };
    P.wf = [P.ra, P.zb, P.cb, P.wb, P.xb, P.Vg, P.Te, P.Ga, P.Rb, P.Ic, P.yb, P.yd, P.Se, P.Ug];
    P.vf = [P.ya, P.Tb, P.Vb];
    P.xf = [P.Ba, P.Nc, P.$b, P.Rc];
    var xd = {},
        yd = function(a, b) {
            xd[a] = xd[a] || [];
            xd[a][b] = !0
        },
        zd = function(a) {
            for (var b = [], c = xd[a] || [], d = 0; d < c.length; d++) c[d] && (b[Math.floor(d / 6)] ^= 1 << d % 6);
            for (var e = 0; e < b.length; e++) b[e] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e] || 0);
            return b.join("")
        };
    var Ad = function(a) {
        yd("GTM", a)
    };
    var Bd = new function(a, b) {
        this.m = a;
        this.defaultValue = void 0 === b ? !1 : b
    }(1933);
    var Dd = function() {
        var a = Cd,
            b = "ve";
        if (a.ve && a.hasOwnProperty(b)) return a.ve;
        var c = new a;
        a.ve = c;
        a.hasOwnProperty(b);
        return c
    };
    var Cd = function() {
        var a = {};
        this.m = function() {
            var b = Bd.m,
                c = Bd.defaultValue;
            return null != a[b] ? a[b] : c
        };
        this.o = function() {
            a[Bd.m] = !0
        }
    };
    var Ed = [];

    function Fd() {
        var a = wb("google_tag_data", {});
        a.ics || (a.ics = {
            entries: {},
            set: Gd,
            update: Hd,
            addListener: Md,
            notifyListeners: Nd,
            active: !1,
            usedDefault: !1
        });
        return a.ics
    }

    function Gd(a, b, c, d, e, f) {
        var g = Fd();
        g.active = !0;
        g.usedDefault = !0;
        if (void 0 != b) {
            var k = g.entries,
                m = k[a] || {},
                n = m.region,
                p = c && h(c) ? c.toUpperCase() : void 0;
            d = d.toUpperCase();
            e = e.toUpperCase();
            if ("" === d || p === e || (p === d ? n !== e : !p && !n)) {
                var q = !!(f && 0 < f && void 0 === m.update),
                    t = {
                        region: p,
                        initial: "granted" === b,
                        update: m.update,
                        quiet: q
                    };
                if ("" !== d || !1 !== m.initial) k[a] = t;
                q && B.setTimeout(function() {
                    k[a] === t && t.quiet && (t.quiet = !1, Od(a), Nd(), yd("TAGGING", 2))
                }, f)
            }
        }
    }

    function Hd(a, b) {
        var c = Fd();
        c.active = !0;
        if (void 0 != b) {
            var d = Pd(a),
                e = c.entries,
                f = e[a] = e[a] || {};
            f.update = "granted" === b;
            var g = Pd(a);
            f.quiet ? (f.quiet = !1, Od(a)) : g !== d && Od(a)
        }
    }

    function Md(a, b) {
        Ed.push({
            me: a,
            hi: b
        })
    }

    function Od(a) {
        for (var b = 0; b < Ed.length; ++b) {
            var c = Ed[b];
            va(c.me) && -1 !== c.me.indexOf(a) && (c.mg = !0)
        }
    }

    function Nd(a) {
        for (var b = 0; b < Ed.length; ++b) {
            var c = Ed[b];
            if (c.mg) {
                c.mg = !1;
                try {
                    c.hi({
                        consentEventId: a
                    })
                } catch (d) {}
            }
        }
    }
    var Pd = function(a) {
            var b = Fd().entries[a] || {};
            return void 0 !== b.update ? b.update : b.initial
        },
        Qd = function(a) {
            return (Fd().entries[a] || {}).initial
        },
        Rd = function(a) {
            return !(Fd().entries[a] || {}).quiet
        },
        Sd = function() {
            return Dd().m() ? Fd().active : !1
        },
        Td = function() {
            return Fd().usedDefault
        },
        Ud = function(a, b) {
            Fd().addListener(a, b)
        },
        Vd = function(a) {
            Fd().notifyListeners(a)
        },
        Wd = function(a, b) {
            function c() {
                for (var e = 0; e < b.length; e++)
                    if (!Rd(b[e])) return !0;
                return !1
            }
            if (c()) {
                var d = !1;
                Ud(b, function(e) {
                    d || c() || (d = !0, a(e))
                })
            } else a({})
        },
        Xd = function(a, b) {
            function c() {
                for (var f = [], g = 0; g < d.length; g++) {
                    var k = d[g];
                    !1 === Pd(k) || e[k] || (f.push(k), e[k] = !0)
                }
                return f
            }
            var d = h(b) ? [b] : b,
                e = {};
            c().length !== d.length && Ud(d, function(f) {
                var g = c();
                0 < g.length && (f.me = g, a(f))
            })
        };

    function Yd(a) {
        for (var b = [], c = 0; c < Zd.length; c++) {
            var d = a(Zd[c]);
            b[c] = !0 === d ? "1" : !1 === d ? "0" : "-"
        }
        return b.join("")
    }
    var Zd = [P.C, P.H],
        $d = function(a) {
            var b = a[P.Le];
            b && Ad(40);
            var c = a[P.Me];
            c && Ad(41);
            for (var d = va(b) ? b : [b], e = {
                    Nb: 0
                }; e.Nb < d.length; e = {
                    Nb: e.Nb
                }, ++e.Nb) Ea(a, function(f) {
                return function(g, k) {
                    if (g !== P.Le && g !== P.Me) {
                        var m = d[f.Nb];
                        Fd().set(g, k, m, "IN", "IN-KA", c)
                    }
                }
            }(e))
        },
        ae = 0,
        be = function(a, b) {
            Ea(a, function(e, f) {
                Fd().update(e, f)
            });
            Vd(b);
            var c = l(),
                d = c - ae;
            ae && 0 <= d && 1E3 > d && Ad(66);
            ae = c
        },
        ce = function(a) {
            var b = Pd(a);
            return void 0 != b ? b : !0
        },
        de = function() {
            return "G1" + Yd(Pd)
        },
        ee = function() {
            return "G1" +
                Yd(Qd)
        },
        fe = function(a, b) {
            Xd(a, b)
        },
        ge = function(a, b) {
            Wd(a, b)
        };
    var ie = function(a) {
            return he ? G.querySelectorAll(a) : null
        },
        je = function(a, b) {
            if (!he) return null;
            if (Element.prototype.closest) try {
                return a.closest(b)
            } catch (e) {
                return null
            }
            var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
                d = a;
            if (!G.documentElement.contains(d)) return null;
            do {
                try {
                    if (c.call(d, b)) return d
                } catch (e) {
                    break
                }
                d = d.parentElement || d.parentNode
            } while (null !== d && 1 === d.nodeType);
            return null
        },
        ke = !1;
    if (G.querySelectorAll) try {
        var le = G.querySelectorAll(":root");
        le && 1 == le.length && le[0] == G.documentElement && (ke = !0)
    } catch (a) {}
    var he = ke;
    var me = function(a) {
            return void 0 === a || null === a ? "" : h(a) ? Oa(String(a)) : "e0"
        },
        oe = function(a) {
            return a.replace(ne, "")
        },
        qe = function(a) {
            return pe(a.replace(/\s/g, ""))
        },
        pe = function(a) {
            return Oa(a.replace(re, "").toLowerCase())
        },
        te = function(a) {
            a = a.replace(/[\s-()/.]/g, "");
            "+" !== a.charAt(0) && (a = "+" + a);
            return se.test(a) ? a : "e0"
        },
        ve = function(a) {
            var b = a.toLowerCase().split("@");
            if (2 == b.length) {
                var c = b[0];
                /^(gmail|googlemail)\./.test(b[1]) && (c = c.replace(/\./g, ""));
                c = c + "@" + b[1];
                if (ue.test(c)) return c
            }
            return "e0"
        },
        ye = function(a, b) {
            window.Promise || b([]);
            Promise.all(a.map(function(c) {
                return c.value && we(c.name) ? xe(c.value).then(function(d) {
                    c.value = d
                }) : Promise.resolve()
            })).then(function() {
                b(a)
            }).catch(function() {
                b([])
            })
        },
        xe = function(a) {
            if ("" === a || "e0" === a) return Promise.resolve(a);
            if (B.crypto && B.crypto.subtle) try {
                var b = ze(a);
                return B.crypto.subtle.digest("SHA-256", b).then(function(c) {
                    var d = Array.from(new Uint8Array(c)).map(function(e) {
                        return String.fromCharCode(e)
                    }).join("");
                    return B.btoa(d).replace(/\+/g, "-").replace(/\//g,
                        "_").replace(/=+$/, "")
                }).catch(function() {
                    return "e2"
                })
            } catch (c) {
                return Promise.resolve("e2")
            } else return Promise.resolve("e1")
        },
        ze = function(a) {
            var b;
            if (B.TextEncoder) b = (new B.TextEncoder("utf-8")).encode(a);
            else {
                for (var c = [], d = 0; d < a.length; d++) {
                    var e = a.charCodeAt(d);
                    128 > e ? c.push(e) : 2048 > e ? c.push(192 | e >> 6, 128 | e & 63) : 55296 > e || 57344 <= e ? c.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : (e = 65536 + ((e & 1023) << 10 | a.charCodeAt(++d) & 1023), c.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63))
                }
                b = new Uint8Array(c)
            }
            return b
        },
        re = /[0-9`~!@#$%^&*()_\-+=:;<>,.?|/\\[\]]/g,
        ue = /^\S+@\S+\.\S+$/,
        se = /^\+\d{11,15}$/,
        ne = /[.~]/g,
        Ae = {},
        Be = (Ae.email = "em", Ae.phone_number = "pn", Ae.first_name = "fn", Ae.last_name = "ln", Ae.street = "sa", Ae.city = "ct", Ae.region = "rg", Ae.country = "co", Ae.postal_code = "pc", Ae.error_code = "ec", Ae),
        Ce = function(a, b) {
            function c(n, p, q) {
                var t = n[p];
                va(t) || (t = [t]);
                for (var u = 0; u < t.length; ++u) {
                    var r = me(t[u]);
                    "" !== r && f.push({
                        name: p,
                        value: q(r),
                        index: void 0
                    })
                }
            }

            function d(n, p, q, t) {
                var u = me(n[p]);
                "" !== u && f.push({
                    name: p,
                    value: q(u),
                    index: t
                })
            }

            function e(n) {
                return function(p) {
                    Ad(64);
                    return n(p)
                }
            }
            var f = [];
            if ("https:" === B.location.protocol) {
                c(a, "email", ve);
                c(a, "phone_number", te);
                c(a, "first_name", e(qe));
                c(a, "last_name", e(qe));
                var g = a.home_address || {};
                c(g, "street", e(pe));
                c(g, "city", e(pe));
                c(g, "postal_code", e(oe));
                c(g, "region", e(pe));
                c(g, "country", e(oe));
                var k = a.address || {};
                va(k) || (k = [k]);
                for (var m = 0; m < k.length; m++) d(k[m], "first_name", qe, m), d(k[m], "last_name", qe, m), d(k[m], "street", pe, m), d(k[m], "city", pe, m), d(k[m], "postal_code", oe, m), d(k[m],
                    "region", pe, m), d(k[m], "country", oe, m);
                ye(f, b)
            } else f.push({
                name: "error_code",
                value: "e3",
                index: void 0
            }), b(f)
        },
        De = function(a, b) {
            Ce(a, function(c) {
                for (var d = ["tv.1"], e = 0, f = 0; f < c.length; ++f) {
                    var g = c[f].name,
                        k = c[f].value,
                        m = c[f].index,
                        n = Be[g];
                    n && k && (!we(g) || /^e\d+$/.test(k) || /^[0-9A-Za-z_-]{43}$/.test(k)) && (void 0 !== m && (n += m), d.push(n + "." + k), e++)
                }
                1 === c.length && "error_code" === c[0].name && (e = 0);
                b(encodeURIComponent(d.join("~")), e)
            })
        },
        Ee = function(a) {
            if (B.Promise) try {
                return new Promise(function(b) {
                    De(a, function(c,
                        d) {
                        b({
                            wc: c,
                            rj: d
                        })
                    })
                })
            } catch (b) {}
        },
        we = function(a) {
            return -1 !== ["email", "phone_number", "first_name", "last_name", "street"].indexOf(a)
        };
    var Fe = function() {
            this.eventModel = {};
            this.targetConfig = {};
            this.containerConfig = {};
            this.globalConfig = {};
            this.remoteConfig = {};
            this.onSuccess = function() {};
            this.onFailure = function() {};
            this.setContainerTypeLoaded = function() {};
            this.getContainerTypeLoaded = function() {};
            this.eventId = void 0;
            this.isGtmEvent = !1
        },
        Ge = function(a) {
            var b = new Fe;
            b.eventModel = a;
            return b
        },
        Oe = function(a, b) {
            a.targetConfig = b;
            return a
        },
        Pe = function(a, b) {
            a.containerConfig = b;
            return a
        },
        Qe = function(a, b) {
            a.globalConfig = b;
            return a
        },
        Re = function(a,
            b) {
            a.remoteConfig = b;
            return a
        },
        Se = function(a, b) {
            a.onSuccess = b;
            return a
        },
        Te = function(a, b) {
            a.setContainerTypeLoaded = b;
            return a
        },
        Ue = function(a, b) {
            a.getContainerTypeLoaded = b;
            return a
        },
        Ve = function(a, b) {
            a.onFailure = b;
            return a
        };
    Fe.prototype.getWithConfig = function(a) {
        if (void 0 !== this.eventModel[a]) return this.eventModel[a];
        if (void 0 !== this.targetConfig[a]) return this.targetConfig[a];
        if (void 0 !== this.containerConfig[a]) return this.containerConfig[a];
        if (void 0 !== this.globalConfig[a]) return this.globalConfig[a];
        if (void 0 !== this.remoteConfig[a]) return this.remoteConfig[a]
    };
    var We = function(a) {
            function b(d) {
                for (var e = Object.keys(d), f = 0; f < e.length; ++f) c[e[f]] = 1
            }
            var c = {};
            b(a.eventModel);
            b(a.targetConfig);
            b(a.containerConfig);
            b(a.globalConfig);
            return Object.keys(c)
        },
        Xe = function(a, b, c) {
            function d(g) {
                Rb(g) && Ea(g, function(k, m) {
                    f = !0;
                    e[k] = m
                })
            }
            var e = {},
                f = !1;
            c && 1 !== c || (d(a.remoteConfig[b]), d(a.globalConfig[b]), d(a.containerConfig[b]), d(a.targetConfig[b]));
            c && 2 !== c || d(a.eventModel[b]);
            return f ? e : void 0
        },
        Ye = function(a) {
            var b = [P.Ub, P.Ve, P.We, P.Xe, P.Ye, P.Ze, P.$e],
                c = {},
                d = !1,
                e = function(f) {
                    for (var g =
                            0; g < b.length; g++) void 0 !== f[b[g]] && (c[b[g]] = f[b[g]], d = !0);
                    return d
                };
            if (e(a.eventModel) || e(a.targetConfig) || e(a.containerConfig) || e(a.globalConfig)) return c;
            e(a.remoteConfig);
            return c
        };
    var Ze = {},
        S = null,
        $e = Math.random();
    Ze.I = "GTM-M7LXSPZ";
    Ze.ad = "a40";
    Ze.Og = "ChAI8JL1igYQlcGHsLWZ35pmEiQAkgqjy8Lx1dxyt1AQznovhPtudmUjva7JlQc0QOtAvUc0csIaAtAD";
    var af = {
            __cl: !0,
            __ecl: !0,
            __ehl: !0,
            __evl: !0,
            __fal: !0,
            __fil: !0,
            __fsl: !0,
            __hl: !0,
            __jel: !0,
            __lcl: !0,
            __sdl: !0,
            __tl: !0,
            __ytl: !0
        },
        bf = {
            __paused: !0,
            __tg: !0
        },
        cf;
    for (cf in af) af.hasOwnProperty(cf) && (bf[cf] = !0);
    var df = "www.googletagmanager.com/gtm.js";
    var ef = df,
        ff = Ma(""),
        gf = null,
        hf = null,
        jf = "https://www.googletagmanager.com/a?id=" + Ze.I + "&cv=1",
        kf = {},
        lf = {},
        mf = function() {
            var a = S.sequence || 1;
            S.sequence = a + 1;
            return a
        };
    Ze.Ng = "true";
    var nf = "";
    Ze.Ib = nf;
    var of = {}, pf = new za, qf = {}, rf = {}, uf = {
        name: "dataLayer",
        set: function(a, b) {
            M(Va(a, b), qf);
            sf()
        },
        get: function(a) {
            return tf(a, 2)
        },
        reset: function() {
            pf = new za;
            qf = {};
            sf()
        }
    }, tf = function(a, b) {
        return 2 != b ? pf.get(a) : vf(a)
    }, vf = function(a) {
        var b, c = a.split(".");
        b = b || [];
        for (var d = qf, e = 0; e < c.length; e++) {
            if (null === d) return !1;
            if (void 0 === d) break;
            d = d[c[e]];
            if (-1 !== wa(b, d)) return
        }
        return d
    }, wf = function(a, b) {
        rf.hasOwnProperty(a) || (pf.set(a, b), M(Va(a, b), qf), sf())
    }, sf = function(a) {
        Ea(rf, function(b, c) {
            pf.set(b, c);
            M(Va(b,
                void 0), qf);
            M(Va(b, c), qf);
            a && delete rf[b]
        })
    }, yf = function(a, b, c) { of [a] = of [a] || {}; of [a][b] = xf(b, c)
    }, xf = function(a, b) {
        var c, d = 1 !== (void 0 === b ? 2 : b) ? vf(a) : pf.get(a);
        "array" === Pb(d) || "object" === Pb(d) ? c = M(d) : c = d;
        return c
    }, zf = function(a, b) {
        if ( of [a]) return of[a][b]
    }, Af = function(a, b) { of [a] && delete of [a][b]
    };
    var Bf, Cf = !1,
        Df = function(a) {
            if (!Cf) {
                Cf = !0;
                Bf = Bf || {}
            }
            return Bf[a]
        };
    var Ef = function(a) {
        if (G.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top == b.bottom || b.left == b.right || !B.getComputedStyle) return !0;
        var c = B.getComputedStyle(a, null);
        if ("hidden" === c.visibility) return !0;
        for (var d = a, e = c; d;) {
            if ("none" === e.display) return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var k = g.indexOf("opacity(");
                0 <= k && (g = g.substring(k + 8, g.indexOf(")", k)), "%" == g.charAt(g.length - 1) && (g = g.substring(0, g.length - 1)), f = Math.min(g, f))
            }
            if (void 0 !== f && 0 >= f) return !0;
            (d = d.parentElement) && (e = B.getComputedStyle(d,
                null))
        }
        return !1
    };
    var Nf = /:[0-9]+$/,
        Of = function(a, b, c) {
            for (var d = a.split("&"), e = 0; e < d.length; e++) {
                var f = d[e].split("=");
                if (decodeURIComponent(f[0]).replace(/\+/g, " ") === b) {
                    var g = f.slice(1).join("=");
                    return c ? g : decodeURIComponent(g).replace(/\+/g, " ")
                }
            }
        },
        Rf = function(a, b, c, d, e) {
            b && (b = String(b).toLowerCase());
            if ("protocol" === b || "port" === b) a.protocol = Pf(a.protocol) || Pf(B.location.protocol);
            "port" === b ? a.port = String(Number(a.hostname ? a.port : B.location.port) || ("http" == a.protocol ? 80 : "https" == a.protocol ? 443 : "")) : "host" === b &&
                (a.hostname = (a.hostname || B.location.hostname).replace(Nf, "").toLowerCase());
            return Qf(a, b, c, d, e)
        },
        Qf = function(a, b, c, d, e) {
            var f, g = Pf(a.protocol);
            b && (b = String(b).toLowerCase());
            switch (b) {
                case "url_no_fragment":
                    f = Sf(a);
                    break;
                case "protocol":
                    f = g;
                    break;
                case "host":
                    f = a.hostname.replace(Nf, "").toLowerCase();
                    if (c) {
                        var k = /^www\d*\./.exec(f);
                        k && k[0] && (f = f.substr(k[0].length))
                    }
                    break;
                case "port":
                    f = String(Number(a.port) || ("http" == g ? 80 : "https" == g ? 443 : ""));
                    break;
                case "path":
                    a.pathname || a.hostname || yd("TAGGING",
                        1);
                    f = "/" == a.pathname.substr(0, 1) ? a.pathname : "/" + a.pathname;
                    var m = f.split("/");
                    0 <= wa(d || [], m[m.length - 1]) && (m[m.length - 1] = "");
                    f = m.join("/");
                    break;
                case "query":
                    f = a.search.replace("?", "");
                    e && (f = Of(f, e, void 0));
                    break;
                case "extension":
                    var n = a.pathname.split(".");
                    f = 1 < n.length ? n[n.length - 1] : "";
                    f = f.split("/")[0];
                    break;
                case "fragment":
                    f = a.hash.replace("#", "");
                    break;
                default:
                    f = a && a.href
            }
            return f
        },
        Pf = function(a) {
            return a ? a.replace(":", "").toLowerCase() : ""
        },
        Sf = function(a) {
            var b = "";
            if (a && a.href) {
                var c = a.href.indexOf("#");
                b = 0 > c ? a.href : a.href.substr(0, c)
            }
            return b
        },
        Tf = function(a) {
            var b = G.createElement("a");
            a && (b.href = a);
            var c = b.pathname;
            "/" !== c[0] && (a || yd("TAGGING", 1), c = "/" + c);
            var d = b.hostname.replace(Nf, "");
            return {
                href: b.href,
                protocol: b.protocol,
                host: b.host,
                hostname: d,
                pathname: c,
                search: b.search,
                hash: b.hash,
                port: b.port
            }
        },
        Uf = function(a) {
            function b(n) {
                var p = n.split("=")[0];
                return 0 > d.indexOf(p) ? n : p + "=0"
            }

            function c(n) {
                return n.split("&").map(b).filter(function(p) {
                    return void 0 != p
                }).join("&")
            }
            var d = "gclid dclid gbraid wbraid gclaw gcldc gclha gclgf gclgb _gl".split(" "),
                e = Tf(a),
                f = a.split(/[?#]/)[0],
                g = e.search,
                k = e.hash;
            "?" === g[0] && (g = g.substring(1));
            "#" === k[0] && (k = k.substring(1));
            g = c(g);
            k = c(k);
            "" !== g && (g = "?" + g);
            "" !== k && (k = "#" + k);
            var m = "" + f + g + k;
            "/" === m[m.length - 1] && (m = m.substring(0, m.length - 1));
            return m
        };
    var Vf = {},
        Wf = !0,
        Xf = !1;
    Vf.Jg = "true";
    var Yf = function(a) {
            if ("false" === Vf.Jg || !Wf) return !1;
            if (Xf) return !0;
            var b = Df("AW-" + a);
            return !!b && !!b.preAutoPii
        },
        Zf = new RegExp(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i),
        $f = new RegExp(/@(gmail|googlemail)\./i),
        ag = new RegExp(/support|noreply/i),
        bg = "SCRIPT STYLE IMG SVG PATH BR".split(" "),
        cg = ["BR"],
        dg = {};

    function eg(a) {
        var b;
        if (a === G.body) b = "body";
        else {
            var c;
            if (a.id) c = "#" + a.id;
            else {
                var d;
                if (a.parentElement) {
                    var e;
                    a: {
                        var f = a.parentElement;
                        if (f) {
                            for (var g = 0; g < f.childElementCount; g++)
                                if (f.children[g] === a) {
                                    e = g + 1;
                                    break a
                                }
                            e = -1
                        } else e = 1
                    }
                    d = eg(a.parentElement) + ">:nth-child(" + e + ")"
                } else d = "";
                c = d
            }
            b = c
        }
        return b
    }

    function fg(a, b) {
        if (1 >= a.length) return a;
        var c = a.filter(b);
        return 0 == c.length ? a : c
    }

    function gg(a) {
        if (0 == a.length) return null;
        var b;
        b = fg(a, function(c) {
            return !ag.test(c.Pa)
        });
        b = fg(b, function(c) {
            return "INPUT" === c.element.tagName.toUpperCase()
        });
        b = fg(b, function(c) {
            return !Ef(c.element)
        });
        return b[0]
    }
    var hg = function(a) {
            a = a || {
                te: !0,
                ue: !0
            };
            a.Za = a.Za || {
                email: !0,
                phone: !0,
                Of: !0
            };
            var b, c = a,
                d = !!c.te + "." + !!c.ue;
            c && c.kd && c.kd.length && (d += "." + c.kd.join("."));
            c && c.Za && (d += "." + c.Za.email + "." + c.Za.phone + "." + c.Za.Of);
            b = d;
            var e = dg[b];
            if (e && 200 > l() - e.timestamp) return e.result;
            var f;
            var g = [],
                k = G.body;
            if (k) {
                for (var m = k.querySelectorAll("*"), n = 0; n < m.length && 1E4 > n; n++) {
                    var p = m[n];
                    if (!(0 <= bg.indexOf(p.tagName.toUpperCase())) && p.children instanceof HTMLCollection) {
                        for (var q = !1, t = 0; t < p.childElementCount && 1E4 > t; t++)
                            if (!(0 <=
                                    cg.indexOf(p.children[t].tagName.toUpperCase()))) {
                                q = !0;
                                break
                            }
                        q || g.push(p)
                    }
                }
                f = {
                    elements: g,
                    status: 1E4 < m.length ? "2" : "1"
                }
            } else f = {
                elements: g,
                status: "4"
            };
            var u = f,
                r = u.status,
                v;
            if (a.Za && a.Za.email) {
                for (var x = u.elements, z = [], w = 0; w < x.length; w++) {
                    var y = x[w],
                        A = y.textContent;
                    "INPUT" === y.tagName.toUpperCase() && y.value && (A = y.value);
                    if (A) {
                        var C = A.match(Zf);
                        if (C) {
                            var F = C[0],
                                D;
                            if (B.location) {
                                var E = Qf(B.location, "host", !0);
                                D = 0 <= F.toLowerCase().indexOf(E)
                            } else D = !1;
                            D || z.push({
                                element: y,
                                Pa: F
                            })
                        }
                    }
                }
                var N;
                var K = a && a.kd;
                if (K && 0 !== K.length) {
                    for (var L = [], O = 0; O < z.length; O++) {
                        for (var I = !0, J = 0; J < K.length; J++) {
                            var U = K[J];
                            if (U && je(z[O].element, U)) {
                                I = !1;
                                break
                            }
                        }
                        I && L.push(z[O])
                    }
                    N = L
                } else N = z;
                v = gg(N);
                10 < z.length && (r = "3")
            }
            var T = [];
            if (v) {
                var ba = v.element,
                    Q = {
                        Pa: v.Pa,
                        tagName: ba.tagName,
                        type: 1
                    };
                a.te && (Q.querySelector = eg(ba));
                a.ue && (Q.isVisible = !Ef(ba));
                T.push(Q)
            }
            var W = {
                elements: T,
                status: r
            };
            dg[b] = {
                timestamp: l(),
                result: W
            };
            return W
        },
        ig = function(a) {
            return a.tagName + ":" + a.isVisible + ":" + a.Pa.length + ":" + $f.test(a.Pa)
        };
    var jg = function(a, b, c) {
            if (c) {
                var d = c.selector_type,
                    e = String(c.value),
                    f;
                if ("js_variable" === d) {
                    e = e.replace(/\["?'?/g, ".").replace(/"?'?\]/g, "");
                    for (var g = e.split(","), k = 0; k < g.length; k++) {
                        var m = g[k].trim();
                        if (m) {
                            if (0 === m.indexOf("dataLayer.")) f = tf(m.substring(10));
                            else {
                                var n = m.split(".");
                                f = B[n.shift()];
                                for (var p = 0; p < n.length; p++) f = f && f[n[p]]
                            }
                            if (void 0 !== f) break
                        }
                    }
                } else if ("css_selector" === d && he) {
                    var q = ie(e);
                    q && 0 < q.length && (f = Ib(q[0]) || Oa(q[0].value))
                }
                f && (a[b] = f)
            }
        },
        kg = function(a) {
            if (a) {
                var b = {};
                jg(b, "email",
                    a.email);
                jg(b, "phone_number", a.phone);
                b.address = [];
                for (var c = a.name_and_address || [], d = 0; d < c.length; d++) {
                    var e = {};
                    jg(e, "first_name", c[d].first_name);
                    jg(e, "last_name", c[d].last_name);
                    jg(e, "street", c[d].street);
                    jg(e, "city", c[d].city);
                    jg(e, "region", c[d].region);
                    jg(e, "country", c[d].country);
                    jg(e, "postal_code", c[d].postal_code);
                    b.address.push(e)
                }
                return b
            }
        },
        lg = function(a) {
            if (a) switch (a.mode) {
                case "selectors":
                    return kg(a.selectors);
                case "auto_detect":
                    var b;
                    var c = a.auto_detect;
                    if (c) {
                        var d = hg({
                                te: !1,
                                ue: !1,
                                kd: c.exclude_element_selectors,
                                Za: {
                                    email: !!c.email,
                                    phone: !!c.phone,
                                    Of: !!c.address
                                }
                            }).elements,
                            e = {};
                        if (0 < d.length)
                            for (var f = 0; f < d.length; f++) {
                                var g = d[f];
                                if (1 === g.type) {
                                    e.email = g.Pa;
                                    break
                                }
                            }
                        b = e
                    } else b = void 0;
                    return b
            }
        },
        mg = function(a) {
            switch (a.enhanced_conversions_mode) {
                case "manual":
                    var b = a.enhanced_conversions_manual_var;
                    return void 0 !== b ? b : B.enhanced_conversion_data;
                case "automatic":
                    return kg(a[P.ff])
            }
        };
    var ng = {},
        og = function(a, b) {
            if (B._gtmexpgrp && B._gtmexpgrp.hasOwnProperty(a)) return B._gtmexpgrp[a];
            void 0 === ng[a] && (ng[a] = Math.floor(Math.random() * b));
            return ng[a]
        };
    var pg = function(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; 0 <= d; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = 0 != c ? b ^ c >> 21 : b;
        return b
    };

    function qg(a, b, c) {
        for (var d = [], e = b.split(";"), f = 0; f < e.length; f++) {
            var g = e[f].split("="),
                k = g[0].replace(/^\s*|\s*$/g, "");
            if (k && k == a) {
                var m = g.slice(1).join("=").replace(/^\s*|\s*$/g, "");
                m && c && (m = decodeURIComponent(m));
                d.push(m)
            }
        }
        return d
    };

    function rg(a) {
        return "null" !== a.origin
    };
    var zg = function(a, b, c, d) {
            return sg(d) ? qg(a, String(b || tg()), c) : []
        },
        Cg = function(a, b, c, d, e) {
            if (sg(e)) {
                var f = Ag(a, d, e);
                if (1 === f.length) return f[0].id;
                if (0 !== f.length) {
                    f = Bg(f, function(g) {
                        return g.hd
                    }, b);
                    if (1 === f.length) return f[0].id;
                    f = Bg(f, function(g) {
                        return g.xc
                    }, c);
                    return f[0] ? f[0].id : void 0
                }
            }
        };

    function Dg(a, b, c, d) {
        var e = tg(),
            f = window;
        rg(f) && (f.document.cookie = a);
        var g = tg();
        return e != g || void 0 != c && 0 <= zg(b, g, !1, d).indexOf(c)
    }
    var Hg = function(a, b, c) {
            function d(u, r, v) {
                if (null == v) return delete g[r], u;
                g[r] = v;
                return u + "; " + r + "=" + v
            }

            function e(u, r) {
                if (null == r) return delete g[r], u;
                g[r] = !0;
                return u + "; " + r
            }
            if (!sg(c.Ea)) return 2;
            var f;
            void 0 == b ? f = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = Eg(b), f = a + "=" + b);
            var g = {};
            f = d(f, "path", c.path);
            var k;
            c.expires instanceof Date ? k = c.expires.toUTCString() : null != c.expires && (k = "" + c.expires);
            f = d(f, "expires", k);
            f = d(f, "max-age", c.qj);
            f = d(f, "samesite",
                c.sj);
            c.tj && (f = e(f, "secure"));
            var m = c.domain;
            if (m && "auto" === m.toLowerCase()) {
                for (var n = Fg(), p = 0; p < n.length; ++p) {
                    var q = "none" !== n[p] ? n[p] : void 0,
                        t = d(f, "domain", q);
                    t = e(t, c.flags);
                    if (!Gg(q, c.path) && Dg(t, a, b, c.Ea)) return 0
                }
                return 1
            }
            m && "none" !== m.toLowerCase() && (f = d(f, "domain", m));
            f = e(f, c.flags);
            return Gg(m, c.path) ? 1 : Dg(f, a, b, c.Ea) ? 0 : 1
        },
        Ig = function(a, b, c) {
            null == c.path && (c.path = "/");
            c.domain || (c.domain = "auto");
            return Hg(a, b, c)
        };

    function Bg(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var k = a[g],
                m = b(k);
            m === c ? d.push(k) : void 0 === f || m < f ? (e = [k], f = m) : m === f && e.push(k)
        }
        return 0 < d.length ? d : e
    }

    function Ag(a, b, c) {
        for (var d = [], e = zg(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                k = g.shift();
            if (!b || -1 !== b.indexOf(k)) {
                var m = g.shift();
                m && (m = m.split("-"), d.push({
                    id: g.join("."),
                    hd: 1 * m[0] || 1,
                    xc: 1 * m[1] || 1
                }))
            }
        }
        return d
    }
    var Eg = function(a) {
            a && 1200 < a.length && (a = a.substring(0, 1200));
            return a
        },
        Jg = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Kg = /(^|\.)doubleclick\.net$/i,
        Gg = function(a, b) {
            return Kg.test(window.document.location.hostname) || "/" === b && Jg.test(a)
        },
        tg = function() {
            return rg(window) ? window.document.cookie : ""
        },
        Fg = function() {
            var a = [],
                b = window.document.location.hostname.split(".");
            if (4 === b.length) {
                var c = b[b.length - 1];
                if (parseInt(c, 10).toString() === c) return ["none"]
            }
            for (var d = b.length - 2; 0 <= d; d--) a.push(b.slice(d).join("."));
            var e = window.document.location.hostname;
            Kg.test(e) || Jg.test(e) || a.push("none");
            return a
        },
        sg = function(a) {
            if (!Dd().m() || !a || !Sd()) return !0;
            if (!Rd(a)) return !1;
            var b = Pd(a);
            return null == b ? !0 : !!b
        };
    var Lg = function(a) {
            var b = Math.round(2147483647 * Math.random()),
                c = b;
            a && (c = b ^ pg(a) & 2147483647);
            return [c, Math.round(l() / 1E3)].join(".")
        },
        Og = function(a, b, c, d, e) {
            var f = Mg(b);
            return Cg(a, f, Ng(c), d, e)
        },
        Pg = function(a, b, c, d) {
            var e = "" + Mg(c),
                f = Ng(d);
            1 < f && (e += "-" + f);
            return [b, e, a].join(".")
        },
        Mg = function(a) {
            if (!a) return 1;
            a = 0 === a.indexOf(".") ? a.substr(1) : a;
            return a.split(".").length
        },
        Ng = function(a) {
            if (!a || "/" === a) return 1;
            "/" !== a[0] && (a = "/" + a);
            "/" !== a[a.length - 1] && (a += "/");
            return a.split("/").length - 1
        };

    function Qg(a, b, c) {
        var d, e = Number(null != a.$a ? a.$a : void 0);
        0 !== e && (d = new Date((b || l()) + 1E3 * (e || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: d
        }
    };
    var Rg = ["1"],
        Sg = {},
        Vg = function(a, b) {
            b = void 0 === b ? !0 : b;
            var c = Tg(a.prefix);
            if (!Sg[c] && !Ug(c, a.path, a.domain) && b) {
                var d = Tg(a.prefix),
                    e = Lg(),
                    f = Pg(e, "1", a.domain, a.path),
                    g = Qg(a);
                g.Ea = "ad_storage";
                if (0 === Ig(d, f, g)) {
                    var k = wb("google_tag_data", {});
                    k._gcl_au ? yd("GTM", 57) : k._gcl_au = e
                }
                Ug(c, a.path, a.domain)
            }
        };

    function Ug(a, b, c) {
        var d = Og(a, b, c, Rg, "ad_storage");
        d && (Sg[a] = d);
        return d
    }

    function Tg(a) {
        return (a || "_gcl") + "_au"
    };
    var Wg = function(a) {
        for (var b = [], c = G.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                Ie: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, k) {
            return k.timestamp - g.timestamp
        });
        return b
    };

    function Xg(a, b) {
        var c = Wg(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!("1" !== f[0] || b && 3 > f.length || !b && 3 !== f.length) && Number(f[1])) {
                d[c[e].Ie] || (d[c[e].Ie] = []);
                var g = {
                    version: f[0],
                    timestamp: 1E3 * Number(f[1]),
                    oa: f[2]
                };
                b && 3 < f.length && (g.labels = f.slice(3));
                d[c[e].Ie].push(g)
            }
        }
        return d
    };

    function Yg() {
        for (var a = Zg, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function $g() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var Zg, ah;

    function bh(a) {
        function b(m) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = ah[n];
                if (null != p) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return m
        }
        Zg = Zg || $g();
        ah = ah || Yg();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                k = b(64);
            if (64 === k && -1 === e) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            64 != g && (c += String.fromCharCode(f << 4 & 240 | g >> 2), 64 != k && (c += String.fromCharCode(g << 6 & 192 | k)))
        }
    };
    var ch;
    var gh = function() {
            var a = dh,
                b = eh,
                c = fh(),
                d = function(g) {
                    a(g.target || g.srcElement || {})
                },
                e = function(g) {
                    b(g.target || g.srcElement || {})
                };
            if (!c.init) {
                Fb(G, "mousedown", d);
                Fb(G, "keyup", d);
                Fb(G, "submit", e);
                var f = HTMLFormElement.prototype.submit;
                HTMLFormElement.prototype.submit = function() {
                    b(this);
                    f.call(this)
                };
                c.init = !0
            }
        },
        hh = function(a, b, c, d, e) {
            var f = {
                callback: a,
                domains: b,
                fragment: 2 === c,
                placement: c,
                forms: d,
                sameHost: e
            };
            fh().decorators.push(f)
        },
        ih = function(a, b, c) {
            for (var d = fh().decorators, e = {}, f = 0; f < d.length; ++f) {
                var g =
                    d[f],
                    k;
                if (k = !c || g.forms) a: {
                    var m = g.domains,
                        n = a,
                        p = !!g.sameHost;
                    if (m && (p || n !== G.location.hostname))
                        for (var q = 0; q < m.length; q++)
                            if (m[q] instanceof RegExp) {
                                if (m[q].test(n)) {
                                    k = !0;
                                    break a
                                }
                            } else if (0 <= n.indexOf(m[q]) || p && 0 <= m[q].indexOf(n)) {
                        k = !0;
                        break a
                    }
                    k = !1
                }
                if (k) {
                    var t = g.placement;
                    void 0 == t && (t = g.fragment ? 2 : 1);
                    t === b && Sa(e, g.callback())
                }
            }
            return e
        },
        fh = function() {
            var a = wb("google_tag_data", {}),
                b = a.gl;
            b && b.decorators || (b = {
                decorators: []
            }, a.gl = b);
            return b
        };
    var jh = /(.*?)\*(.*?)\*(.*)/,
        kh = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        lh = /^(?:www\.|m\.|amp\.)+/,
        mh = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function nh(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }
    var ph = function(a) {
            var b = [],
                c;
            for (c in a)
                if (a.hasOwnProperty(c)) {
                    var d = a[c];
                    if (void 0 !== d && d === d && null !== d && "[object Object]" !== d.toString()) {
                        b.push(c);
                        var e = b,
                            f = e.push,
                            g, k = String(d);
                        Zg = Zg || $g();
                        ah = ah || Yg();
                        for (var m = [], n = 0; n < k.length; n += 3) {
                            var p = n + 1 < k.length,
                                q = n + 2 < k.length,
                                t = k.charCodeAt(n),
                                u = p ? k.charCodeAt(n + 1) : 0,
                                r = q ? k.charCodeAt(n + 2) : 0,
                                v = t >> 2,
                                x = (t & 3) << 4 | u >> 4,
                                z = (u & 15) << 2 | r >> 6,
                                w = r & 63;
                            q || (w = 64, p || (z = 64));
                            m.push(Zg[v], Zg[x], Zg[z], Zg[w])
                        }
                        g = m.join("");
                        f.call(e, g)
                    }
                }
            var y = b.join("*");
            return ["1", oh(y),
                y
            ].join("*")
        },
        oh = function(a, b) {
            var c = [window.navigator.userAgent, (new Date).getTimezoneOffset(), window.navigator.userLanguage || window.navigator.language, Math.floor((new Date).getTime() / 60 / 1E3) - (void 0 === b ? 0 : b), a].join("*"),
                d;
            if (!(d = ch)) {
                for (var e = Array(256), f = 0; 256 > f; f++) {
                    for (var g = f, k = 0; 8 > k; k++) g = g & 1 ? g >>> 1 ^ 3988292384 : g >>> 1;
                    e[f] = g
                }
                d = e
            }
            ch = d;
            for (var m = 4294967295, n = 0; n < c.length; n++) m = m >>> 8 ^ ch[(m ^ c.charCodeAt(n)) & 255];
            return ((m ^ -1) >>> 0).toString(36)
        },
        rh = function() {
            return function(a) {
                var b = Tf(B.location.href),
                    c = b.search.replace("?", ""),
                    d = Of(c, "_gl", !0) || "";
                a.query = qh(d) || {};
                var e = Rf(b, "fragment").match(nh("_gl"));
                a.fragment = qh(e && e[3] || "") || {}
            }
        },
        sh = function(a) {
            var b = rh(),
                c = fh();
            c.data || (c.data = {
                query: {},
                fragment: {}
            }, b(c.data));
            var d = {},
                e = c.data;
            e && (Sa(d, e.query), a && Sa(d, e.fragment));
            return d
        },
        qh = function(a) {
            var b;
            b = void 0 === b ? 3 : b;
            try {
                if (a) {
                    var c;
                    a: {
                        for (var d = a, e = 0; 3 > e; ++e) {
                            var f = jh.exec(d);
                            if (f) {
                                c = f;
                                break a
                            }
                            d = decodeURIComponent(d)
                        }
                        c = void 0
                    }
                    var g = c;
                    if (g && "1" === g[1]) {
                        var k = g[3],
                            m;
                        a: {
                            for (var n = g[2], p = 0; p <
                                b; ++p)
                                if (n === oh(k, p)) {
                                    m = !0;
                                    break a
                                }
                            m = !1
                        }
                        if (m) {
                            for (var q = {}, t = k ? k.split("*") : [], u = 0; u < t.length; u += 2) q[t[u]] = bh(t[u + 1]);
                            return q
                        }
                    }
                }
            } catch (r) {}
        };

    function th(a, b, c, d) {
        function e(p) {
            var q = p,
                t = nh(a).exec(q),
                u = q;
            if (t) {
                var r = t[2],
                    v = t[4];
                u = t[1];
                v && (u = u + r + v)
            }
            p = u;
            var x = p.charAt(p.length - 1);
            p && "&" !== x && (p += "&");
            return p + n
        }
        d = void 0 === d ? !1 : d;
        var f = mh.exec(c);
        if (!f) return "";
        var g = f[1],
            k = f[2] || "",
            m = f[3] || "",
            n = a + "=" + b;
        d ? m = "#" + e(m.substring(1)) : k = "?" + e(k.substring(1));
        return "" + g + k + m
    }

    function uh(a, b) {
        var c = "FORM" === (a.tagName || "").toUpperCase(),
            d = ih(b, 1, c),
            e = ih(b, 2, c),
            f = ih(b, 3, c);
        if (Ta(d)) {
            var g = ph(d);
            c ? vh("_gl", g, a) : wh("_gl", g, a, !1)
        }
        if (!c && Ta(e)) {
            var k = ph(e);
            wh("_gl", k, a, !0)
        }
        for (var m in f)
            if (f.hasOwnProperty(m)) a: {
                var n = m,
                    p = f[m],
                    q = a;
                if (q.tagName) {
                    if ("a" === q.tagName.toLowerCase()) {
                        wh(n, p, q, void 0);
                        break a
                    }
                    if ("form" === q.tagName.toLowerCase()) {
                        vh(n, p, q);
                        break a
                    }
                }
                "string" == typeof q && th(n, p, q, void 0)
            }
    }

    function wh(a, b, c, d) {
        if (c.href) {
            var e = th(a, b, c.href, void 0 === d ? !1 : d);
            fb.test(e) && (c.href = e)
        }
    }

    function vh(a, b, c) {
        if (c && c.action) {
            var d = (c.method || "").toLowerCase();
            if ("get" === d) {
                for (var e = c.childNodes || [], f = !1, g = 0; g < e.length; g++) {
                    var k = e[g];
                    if (k.name === a) {
                        k.setAttribute("value", b);
                        f = !0;
                        break
                    }
                }
                if (!f) {
                    var m = G.createElement("input");
                    m.setAttribute("type", "hidden");
                    m.setAttribute("name", a);
                    m.setAttribute("value", b);
                    c.appendChild(m)
                }
            } else if ("post" === d) {
                var n = th(a, b, c.action);
                fb.test(n) && (c.action = n)
            }
        }
    }
    var dh = function(a) {
            try {
                var b;
                a: {
                    for (var c = a, d = 100; c && 0 < d;) {
                        if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                            b = c;
                            break a
                        }
                        c = c.parentNode;
                        d--
                    }
                    b = null
                }
                var e = b;
                if (e) {
                    var f = e.protocol;
                    "http:" !== f && "https:" !== f || uh(e, e.hostname)
                }
            } catch (g) {}
        },
        eh = function(a) {
            try {
                if (a.action) {
                    var b = Rf(Tf(a.action), "host");
                    uh(a, b)
                }
            } catch (c) {}
        },
        xh = function(a, b, c, d) {
            gh();
            hh(a, b, "fragment" === c ? 2 : 1, !!d, !1)
        },
        yh = function(a, b) {
            gh();
            hh(a, [Qf(B.location, "host", !0)], b, !0, !0)
        },
        zh = function() {
            var a = G.location.hostname,
                b = kh.exec(G.referrer);
            if (!b) return !1;
            var c = b[2],
                d = b[1],
                e = "";
            if (c) {
                var f = c.split("/"),
                    g = f[1];
                e = "s" === g ? decodeURIComponent(f[2]) : decodeURIComponent(g)
            } else if (d) {
                if (0 === d.indexOf("xn--")) return !1;
                e = d.replace(/-/g, ".").replace(/\.\./g, "-")
            }
            var k = a.replace(lh, ""),
                m = e.replace(lh, ""),
                n;
            if (!(n = k === m)) {
                var p = "." + m;
                n = k.substring(k.length - p.length, k.length) === p
            }
            return n
        },
        Ah = function(a, b) {
            return !1 === a ? !1 : a || b || zh()
        };
    var Bh = {};
    var Ch = /^\w+$/,
        Dh = /^[\w-]+$/,
        Eh = {
            aw: "_aw",
            dc: "_dc",
            gf: "_gf",
            ha: "_ha",
            gp: "_gp",
            gb: "_gb"
        },
        Fh = function() {
            if (!Dd().m() || !Sd()) return !0;
            var a = Pd("ad_storage");
            return null == a ? !0 : !!a
        },
        Gh = function(a, b) {
            Rd("ad_storage") ? Fh() ? a() : Xd(a, "ad_storage") : b ? yd("TAGGING", 3) : Wd(function() {
                Gh(a, !0)
            }, ["ad_storage"])
        },
        Ih = function(a) {
            return Hh(a).map(function(b) {
                return b.oa
            })
        },
        Hh = function(a) {
            var b = [];
            if (!rg(B) || !G.cookie) return b;
            var c = zg(a, G.cookie, void 0, "ad_storage");
            if (!c || 0 == c.length) return b;
            for (var d = {}, e = 0; e < c.length; d = {
                    Ec: d.Ec
                }, e++) {
                var f = Jh(c[e]);
                if (null != f) {
                    var g = f,
                        k = g.version;
                    d.Ec = g.oa;
                    var m = g.timestamp,
                        n = g.labels,
                        p = xa(b, function(q) {
                            return function(t) {
                                return t.oa === q.Ec
                            }
                        }(d));
                    p ? (p.timestamp = Math.max(p.timestamp, m), p.labels = Kh(p.labels, n || [])) : b.push({
                        version: k,
                        oa: d.Ec,
                        timestamp: m,
                        labels: n
                    })
                }
            }
            b.sort(function(q, t) {
                return t.timestamp - q.timestamp
            });
            return Lh(b)
        };

    function Kh(a, b) {
        for (var c = {}, d = [], e = 0; e < a.length; e++) c[a[e]] = !0, d.push(a[e]);
        for (var f = 0; f < b.length; f++) c[b[f]] || d.push(b[f]);
        return d
    }

    function Mh(a) {
        return a && "string" == typeof a && a.match(Ch) ? a : "_gcl"
    }
    var Oh = function() {
            var a = Tf(B.location.href),
                b = Rf(a, "query", !1, void 0, "gclid"),
                c = Rf(a, "query", !1, void 0, "gclsrc"),
                d = Rf(a, "query", !1, void 0, "wbraid"),
                e = Rf(a, "query", !1, void 0, "dclid");
            if (!b || !c || !d) {
                var f = a.hash.replace("#", "");
                b = b || Of(f, "gclid", void 0);
                c = c || Of(f, "gclsrc", void 0);
                d = d || Of(f, "wbraid", void 0)
            }
            return Nh(b, c, e, d)
        },
        Nh = function(a, b, c, d) {
            var e = {},
                f = function(g, k) {
                    e[k] || (e[k] = []);
                    e[k].push(g)
                };
            e.gclid = a;
            e.gclsrc = b;
            e.dclid = c;
            void 0 !== d && Dh.test(d) && (e.gbraid = d, f(d, "gb"));
            if (void 0 !== a && a.match(Dh)) switch (b) {
                case void 0:
                    f(a,
                        "aw");
                    break;
                case "aw.ds":
                    f(a, "aw");
                    f(a, "dc");
                    break;
                case "ds":
                    f(a, "dc");
                    break;
                case "3p.ds":
                    f(a, "dc");
                    break;
                case "gf":
                    f(a, "gf");
                    break;
                case "ha":
                    f(a, "ha")
            }
            c && f(c, "dc");
            return e
        },
        Qh = function(a) {
            var b = Oh();
            Gh(function() {
                Ph(b, !1, a)
            })
        };

    function Ph(a, b, c, d, e) {
        function f(x, z) {
            var w = Rh(x, g);
            w && (Ig(w, z, k), m = !0)
        }
        c = c || {};
        e = e || [];
        var g = Mh(c.prefix);
        d = d || l();
        var k = Qg(c, d, !0);
        k.Ea = "ad_storage";
        var m = !1,
            n = Math.round(d / 1E3),
            p = function(x) {
                var z = ["GCL", n, x];
                0 < e.length && z.push(e.join("."));
                return z.join(".")
            };
        a.aw && f("aw", p(a.aw[0]));
        a.dc && f("dc", p(a.dc[0]));
        a.gf && f("gf", p(a.gf[0]));
        a.ha && f("ha", p(a.ha[0]));
        a.gp && f("gp", p(a.gp[0]));
        if ((void 0 == Bh.enable_gbraid_cookie_write ? 0 : Bh.enable_gbraid_cookie_write) && !m && a.gb) {
            var q = a.gb[0],
                t = Rh("gb", g),
                u = !1;
            if (!b)
                for (var r = Hh(t), v = 0; v < r.length; v++) r[v].oa === q && r[v].labels && 0 < r[v].labels.length && (u = !0);
            u || f("gb", p(q))
        }
    }
    var Th = function(a, b) {
            var c = sh(!0);
            Gh(function() {
                for (var d = Mh(b.prefix), e = 0; e < a.length; ++e) {
                    var f = a[e];
                    if (void 0 !== Eh[f]) {
                        var g = Rh(f, d),
                            k = c[g];
                        if (k) {
                            var m = Math.min(Sh(k), l()),
                                n;
                            b: {
                                var p = m;
                                if (rg(B))
                                    for (var q = zg(g, G.cookie, void 0, "ad_storage"), t = 0; t < q.length; ++t)
                                        if (Sh(q[t]) > p) {
                                            n = !0;
                                            break b
                                        }
                                n = !1
                            }
                            if (!n) {
                                var u = Qg(b, m, !0);
                                u.Ea = "ad_storage";
                                Ig(g, k, u)
                            }
                        }
                    }
                }
                Ph(Nh(c.gclid, c.gclsrc), !1, b)
            })
        },
        Rh = function(a, b) {
            var c = Eh[a];
            if (void 0 !== c) return b + c
        },
        Sh = function(a) {
            return 0 !== Uh(a.split(".")).length ? 1E3 * (Number(a.split(".")[1]) ||
                0) : 0
        };

    function Jh(a) {
        var b = Uh(a.split("."));
        return 0 === b.length ? null : {
            version: b[0],
            oa: b[2],
            timestamp: 1E3 * (Number(b[1]) || 0),
            labels: b.slice(3)
        }
    }

    function Uh(a) {
        return 3 > a.length || "GCL" !== a[0] && "1" !== a[0] || !/^\d+$/.test(a[1]) || !Dh.test(a[2]) ? [] : a
    }
    var Vh = function(a, b, c, d, e) {
            if (va(b) && rg(B)) {
                var f = Mh(e),
                    g = function() {
                        for (var k = {}, m = 0; m < a.length; ++m) {
                            var n = Rh(a[m], f);
                            if (n) {
                                var p = zg(n, G.cookie, void 0, "ad_storage");
                                p.length && (k[n] = p.sort()[p.length - 1])
                            }
                        }
                        return k
                    };
                Gh(function() {
                    xh(g, b, c, d)
                })
            }
        },
        Lh = function(a) {
            return a.filter(function(b) {
                return Dh.test(b.oa)
            })
        },
        Wh = function(a, b) {
            if (rg(B)) {
                for (var c = Mh(b.prefix), d = {}, e = 0; e < a.length; e++) Eh[a[e]] && (d[a[e]] = Eh[a[e]]);
                Gh(function() {
                    Ea(d, function(f, g) {
                        var k = zg(c + g, G.cookie, void 0, "ad_storage");
                        k.sort(function(u,
                            r) {
                            return Sh(r) - Sh(u)
                        });
                        if (k.length) {
                            var m = k[0],
                                n = Sh(m),
                                p = 0 !== Uh(m.split(".")).length ? m.split(".").slice(3) : [],
                                q = {},
                                t;
                            t = 0 !== Uh(m.split(".")).length ? m.split(".")[2] : void 0;
                            q[f] = [t];
                            Ph(q, !0, b, n, p)
                        }
                    })
                })
            }
        };

    function Xh(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }
    var Yh = function(a) {
        function b(e, f, g) {
            g && (e[f] = g)
        }
        if (Sd()) {
            var c = Oh();
            if (Xh(c, a)) {
                var d = {};
                b(d, "gclid", c.gclid);
                b(d, "dclid", c.dclid);
                b(d, "gclsrc", c.gclsrc);
                b(d, "wbraid", c.gbraid);
                yh(function() {
                    return d
                }, 3);
                yh(function() {
                    var e = {};
                    return e._up = "1", e
                }, 1)
            }
        }
    };

    function Zh(a, b) {
        var c = Mh(b),
            d = Rh(a, c);
        if (!d) return 0;
        for (var e = Hh(d), f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function $h(a) {
        var b = 0,
            c;
        for (c in a)
            for (var d = a[c], e = 0; e < d.length; e++) b = Math.max(b, Number(d[e].timestamp));
        return b
    };

    function li(a) {
        var b = ub && ub.userAgent || "";
        if (0 > b.indexOf("Safari") || /Chrome|Coast|Opera|Edg|Silk|Android/.test(b)) return !1;
        var c = (/Version\/([\d\.]+)/.exec(b) || [])[1] || "";
        if ("" === c) return !1;
        for (var d = a.split("."), e = c.split("."), f = 0; f < e.length; f++) {
            if (void 0 === d[f]) return !0;
            if (e[f] != d[f]) return Number(e[f]) > Number(d[f])
        }
        return e.length >= d.length
    };
    var si = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        ti = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        ui = {
            cl: ["ecl"],
            customPixels: ["customScripts", "html"],
            ecl: ["cl"],
            ehl: ["hl"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        vi = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
    var wi = function() {
            var a = !1;
            return a
        },
        yi = function(a) {
            var b = tf("gtm.allowlist") || tf("gtm.whitelist");
            b && Ad(9);
            wi() && (b = "google gtagfl lcl zone oid op".split(" "));
            var c = b && Ua(Na(b), ti),
                d = tf("gtm.blocklist") ||
                tf("gtm.blacklist");
            d || (d = tf("tagTypeBlacklist")) && Ad(3);
            d ? Ad(8) : d = [];
            xi() && (d = Na(d), d.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
            0 <= wa(Na(d), "google") && Ad(2);
            var e = d && Ua(Na(d), ui),
                f = {};
            return function(g) {
                var k = g && g[Zb.jb];
                if (!k || "string" != typeof k) return !0;
                k = k.replace(/^_*/, "");
                if (void 0 !== f[k]) return f[k];
                var m = lf[k] || [],
                    n = a(k, m);
                if (b) {
                    var p;
                    if (p =
                        n) a: {
                        if (0 > wa(c, k))
                            if (m && 0 < m.length)
                                for (var q = 0; q < m.length; q++) {
                                    if (0 > wa(c, m[q])) {
                                        Ad(11);
                                        p = !1;
                                        break a
                                    }
                                } else {
                                    p = !1;
                                    break a
                                }
                        p = !0
                    }
                    n = p
                }
                var t = !1;
                if (d) {
                    var u = 0 <= wa(e, k);
                    if (u) t = u;
                    else {
                        var r = Ca(e, m || []);
                        r && Ad(10);
                        t = r
                    }
                }
                var v = !n || t;
                v || !(0 <= wa(m, "sandboxedScripts")) || c && -1 !== wa(c, "sandboxedScripts") || (v = Ca(e, vi));
                return f[k] = v
            }
        },
        xi = function() {
            return si.test(B.location && B.location.hostname)
        };
    var zi = !1,
        Ai = 0,
        Bi = [];

    function Ci(a) {
        if (!zi) {
            var b = G.createEventObject,
                c = "complete" == G.readyState,
                d = "interactive" == G.readyState;
            if (!a || "readystatechange" != a.type || c || !b && d) {
                zi = !0;
                for (var e = 0; e < Bi.length; e++) H(Bi[e])
            }
            Bi.push = function() {
                for (var f = 0; f < arguments.length; f++) H(arguments[f]);
                return 0
            }
        }
    }

    function Di() {
        if (!zi && 140 > Ai) {
            Ai++;
            try {
                G.documentElement.doScroll("left"), Ci()
            } catch (a) {
                B.setTimeout(Di, 50)
            }
        }
    }
    var Ei = function(a) {
        zi ? a() : Bi.push(a)
    };
    var Gi = function(a, b) {
            this.m = !1;
            this.D = [];
            this.N = {
                tags: []
            };
            this.Z = !1;
            this.o = this.B = 0;
            Fi(this, a, b)
        },
        Hi = function(a, b, c, d) {
            if (bf.hasOwnProperty(b) || "__zone" === b) return -1;
            var e = {};
            Rb(d) && (e = M(d, e));
            e.id = c;
            e.status = "timeout";
            return a.N.tags.push(e) - 1
        },
        Ii = function(a, b, c, d) {
            var e = a.N.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        Ji = function(a) {
            if (!a.m) {
                for (var b = a.D, c = 0; c < b.length; c++) b[c]();
                a.m = !0;
                a.D.length = 0
            }
        },
        Fi = function(a, b, c) {
            ta(b) && Ki(a, b);
            c && B.setTimeout(function() {
                return Ji(a)
            }, Number(c))
        },
        Ki = function(a,
            b) {
            var c = Ra(function() {
                return H(function() {
                    b(Ze.I, a.N)
                })
            });
            a.m ? c() : a.D.push(c)
        },
        Li = function(a) {
            a.B++;
            return Ra(function() {
                a.o++;
                a.Z && a.o >= a.B && Ji(a)
            })
        };
    var Mi = function() {
            function a(d) {
                return !ua(d) || 0 > d ? 0 : d
            }
            if (!S._li && B.performance && B.performance.timing) {
                var b = B.performance.timing.navigationStart,
                    c = ua(uf.get("gtm.start")) ? uf.get("gtm.start") : 0;
                S._li = {
                    cst: a(c - b),
                    cbt: a(hf - b)
                }
            }
        },
        Ni = function(a) {
            B.performance && B.performance.mark(Ze.I + "_" + a + "_start")
        },
        Oi = function(a) {
            if (B.performance) {
                var b = Ze.I + "_" + a + "_start",
                    c = Ze.I + "_" + a + "_duration";
                B.performance.measure(c, b);
                var d = B.performance.getEntriesByName(c)[0];
                B.performance.clearMarks(b);
                B.performance.clearMeasures(c);
                var e = S._p || {};
                void 0 === e[a] && (e[a] = d.duration, S._p = e);
                return d.duration
            }
        },
        Pi = function() {
            if (B.performance && B.performance.now) {
                var a = S._p || {};
                a.PAGEVIEW = B.performance.now();
                S._p = a
            }
        };
    var Qi = {},
        Ri = function() {
            return B.GoogleAnalyticsObject && B[B.GoogleAnalyticsObject]
        },
        Si = !1;

    function Wi() {
        return B.GoogleAnalyticsObject || "ga"
    }
    var Xi = function(a) {},
        Yi = function(a, b) {
            return function() {
                var c = Ri(),
                    d = c && c.getByName && c.getByName(a);
                if (d) {
                    var e = d.get("sendHitTask");
                    d.set("sendHitTask", function(f) {
                        var g = f.get("hitPayload"),
                            k = f.get("hitCallback"),
                            m = 0 > g.indexOf("&tid=" + b);
                        m && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                        e(f);
                        m && (f.set("hitPayload",
                            g, !0), f.set("hitCallback", k, !0), f.set("_x_19", void 0, !0), e(f))
                    })
                }
            }
        };
    var ej = function(a) {},
        ij = function(a) {},
        jj =
        function() {
            return "&tc=" + Dc.filter(function(a) {
                return a
            }).length
        },
        mj = function() {
            2022 <= kj().length && lj()
        },
        nj = function(a) {
            return 0 === a.indexOf("gtm.") ? encodeURIComponent(a) : "*"
        },
        pj = function() {
            oj || (oj = B.setTimeout(lj, 500))
        },
        lj = function() {
            oj && (B.clearTimeout(oj), oj = void 0);
            void 0 === qj || rj[qj] && !sj && !tj || (uj[qj] || vj.wi() || 0 >= wj-- ? (Ad(1), uj[qj] = !0) : (vj.Ri(), Eb(kj(!0)), rj[qj] = !0, xj = yj = zj = tj = sj = ""))
        },
        kj = function(a) {
            var b = qj;
            if (void 0 === b) return "";
            var c = zd("GTM"),
                d = zd("TAGGING");
            return [Aj, rj[b] ? "" : "&es=1",
                Bj[b], ej(b), c ? "&u=" + c : "", d ? "&ut=" + d : "", jj(), sj, tj, zj, yj, ij(a), xj, "&z=0"
            ].join("")
        },
        Dj = function() {
            Aj = Cj()
        },
        Cj = function() {
            return [jf, "&v=3&t=t", "&pid=" + ya(), "&rv=" + Ze.ad].join("")
        },
        hj = ["L", "S", "Y"],
        dj = ["S", "E"],
        Ej = {
            sampleRate: "0.005000",
            Gg: "",
            Fg: Number("5")
        },
        Fj = 0 <= G.location.search.indexOf("?gtm_latency=") || 0 <= G.location.search.indexOf("&gtm_latency="),
        Gj;
    if (!(Gj = Fj)) {
        var Hj = Math.random(),
            Ij = Ej.sampleRate;
        Gj = Hj < Ij
    }
    var Jj = Gj,
        Kj = {
            label: Ze.I + " Container",
            children: [{
                label: "Initialization",
                children: []
            }]
        },
        Aj = Cj(),
        rj = {},
        sj = "",
        tj = "",
        xj = "",
        yj = "",
        gj = {},
        fj = !1,
        cj = {},
        Lj = {},
        zj = "",
        qj = void 0,
        Bj = {},
        uj = {},
        oj = void 0,
        Mj = 5;
    0 < Ej.Fg && (Mj = Ej.Fg);
    var vj = function(a, b) {
            for (var c = 0, d = [], e = 0; e < a; ++e) d.push(0);
            return {
                wi: function() {
                    return c < a ? !1 : l() - d[c % a] < b
                },
                Ri: function() {
                    var f = c++ % a;
                    d[f] = l()
                }
            }
        }(Mj, 1E3),
        wj = 1E3,
        Oj = function(a, b) {
            if (Jj && !uj[a] && qj !==
                a) {
                lj();
                qj = a;
                xj = sj = "";
                Bj[a] = "&e=" + nj(b) + "&eid=" + a;
                pj();
            }
        },
        Pj = function(a, b, c, d) {
            if (Jj && b) {
                var e, f = String(b[Zb.jb] || "").replace(/_/g, "");
                0 === f.indexOf("cvt") && (f = "cvt");
                e = f;
                var g = c + e;
                if (!uj[a]) {
                    a !== qj && (lj(), qj = a);
                    sj = sj ? sj + "." + g : "&tr=" + g;
                    var k = b["function"];
                    if (!k) throw Error("Error: No function name given for function call.");
                    var m = (Ic[k] ? "1" : "2") + e;
                    xj = xj ? xj + "." + m : "&ti=" + m;
                    pj();
                    mj()
                }
            }
        };
    var Wj = function(a, b, c) {
            if (Jj && !uj[a]) {
                a !== qj && (lj(), qj = a);
                var d = c + b;
                tj = tj ? tj + "." + d : "&epr=" + d;
                pj();
                mj()
            }
        },
        Xj = function(a, b, c) {};
    var Yj = {
            active: !0,
            isAllowed: function() {
                return !0
            }
        },
        Zj = function(a) {
            var b = S.zones;
            return b ? b.checkState(Ze.I, a) : Yj
        },
        ak = function(a) {
            var b = S.zones;
            !b && a && (b = S.zones = a());
            return b
        };

    function bk() {}

    function ck() {};

    function dk(a, b, c, d) {
        var e = Dc[a],
            f = ek(a, b, c, d);
        if (!f) return null;
        var g = Nc(e[Zb.Df], c, []);
        if (g && g.length) {
            var k = g[0];
            f = dk(k.index, {
                onSuccess: f,
                onFailure: 1 === k.Yf ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function ek(a, b, c, d) {
        function e() {
            if (f[Zb.Dh]) k();
            else {
                var x = Oc(f, c, []);
                var z = x[Zb.Lg];
                if (null != z)
                    for (var w = 0; w < z.length; w++)
                        if (!ce(z[w])) {
                            k();
                            return
                        }
                var y = Hi(c.kb, String(f[Zb.jb]), Number(f[Zb.Ff]), x[Zb.Eh]),
                    A = !1;
                x.vtp_gtmOnSuccess = function() {
                    if (!A) {
                        A = !0;
                        var D = l() - F;
                        Pj(c.id, Dc[a], "5", D);
                        Ii(c.kb, y, "success",
                            D);
                        g()
                    }
                };
                x.vtp_gtmOnFailure = function() {
                    if (!A) {
                        A = !0;
                        var D = l() - F;
                        Pj(c.id, Dc[a], "6", D);
                        Ii(c.kb, y, "failure", D);
                        k()
                    }
                };
                x.vtp_gtmTagId = f.tag_id;
                x.vtp_gtmEventId = c.id;
                Pj(c.id, f, "1");
                var C = function() {
                    var D = l() - F;
                    Pj(c.id, f, "7", D);
                    Ii(c.kb, y, "exception", D);
                    A || (A = !0, k())
                };
                var F = l();
                try {
                    Mc(x, c)
                } catch (D) {
                    C(D)
                }
            }
        }
        var f = Dc[a],
            g = b.onSuccess,
            k = b.onFailure,
            m = b.terminate;
        if (c.xe(f)) return null;
        var n = Nc(f[Zb.Gf], c, []);
        if (n && n.length) {
            var p = n[0],
                q = dk(p.index, {
                    onSuccess: g,
                    onFailure: k,
                    terminate: m
                }, c, d);
            if (!q) return null;
            g = q;
            k = 2 === p.Yf ? m : q
        }
        if (f[Zb.zf] || f[Zb.Gh]) {
            var t = f[Zb.zf] ? Ec :
                c.Zi,
                u = g,
                r = k;
            if (!t[a]) {
                e = Ra(e);
                var v = fk(a, t, e);
                g = v.onSuccess;
                k = v.onFailure
            }
            return function() {
                t[a](u, r)
            }
        }
        return e
    }

    function fk(a, b, c) {
        var d = [],
            e = [];
        b[a] = gk(d, e, c);
        return {
            onSuccess: function() {
                b[a] = hk;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = ik;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function gk(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function hk(a) {
        a()
    }

    function ik(a, b) {
        b()
    };
    var lk = function(a, b) {
        for (var c = [], d = 0; d < Dc.length; d++)
            if (a[d]) {
                var e = Dc[d];
                var f = Li(b.kb);
                try {
                    var g = dk(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var k = c,
                            m = k.push,
                            n = d,
                            p = e["function"];
                        if (!p) throw "Error: No function name given for function call.";
                        var q = Ic[p];
                        m.call(k, {
                            yg: n,
                            ng: q ? q.priorityOverride || 0 : 0,
                            execute: g
                        })
                    } else jk(d, b), f()
                } catch (r) {
                    f()
                }
            }
        var t = b.kb;
        t.Z = !0;
        t.o >= t.B && Ji(t);
        c.sort(kk);
        for (var u = 0; u < c.length; u++) c[u].execute();
        return 0 < c.length
    };

    function kk(a, b) {
        var c, d = b.ng,
            e = a.ng;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (0 !== c) f = c;
        else {
            var g = a.yg,
                k = b.yg;
            f = g > k ? 1 : g < k ? -1 : 0
        }
        return f
    }

    function jk(a, b) {
        if (!Jj) return;
        var c = function(d) {
            var e = b.xe(Dc[d]) ? "3" : "4",
                f = Nc(Dc[d][Zb.Df], b, []);
            f && f.length && c(f[0].index);
            Pj(b.id, Dc[d], e);
            var g = Nc(Dc[d][Zb.Gf], b, []);
            g && g.length && c(g[0].index)
        };
        c(a);
    }
    var mk = !1,
        sk = function(a) {
            var b = l(),
                c = a["gtm.uniqueEventId"],
                d = a.event;
            if ("gtm.js" === d) {
                if (mk) return !1;
                mk = !0;
            }
            var g = Zj(c),
                k = !1;
            if (!g.active) {
                if ("gtm.js" !== d) return !1;
                k = !0;
                g = Zj(Number.MAX_SAFE_INTEGER)
            }
            Oj(c, d);
            var m = a.eventCallback,
                n = a.eventTimeout,
                p = m;
            var q = {
                id: c,
                name: d,
                xe: yi(g.isAllowed),
                Zi: [],
                hg: function() {
                    Ad(6)
                },
                Rf: nk(c),
                kb: new Gi(p, n)
            };
            q.Qf = ok();
            pk(c, q.kb);
            var t = Sc(q);
            k && (t = qk(t));
            var u = lk(t, q);
            "gtm.js" !== d && "gtm.sync" !== d || Xi(Ze.I);
            return rk(t, u)
        };

    function nk(a) {
        return function(b) {
            Jj && (Yb(b) || Xj(a, "input", b))
        }
    }

    function pk(a, b) {
        yf(a, "event", 1);
        yf(a, "ecommerce", 1);
        yf(a, "gtm");
        yf(a, "eventModel");
    }

    function ok() {
        var a = {};
        a.event = xf("event", 1);
        a.ecommerce = xf("ecommerce", 1);
        a.gtm = xf("gtm");
        a.eventModel = xf("eventModel");
        return a
    }

    function qk(a) {
        for (var b = [], c = 0; c < a.length; c++) a[c] && af[String(Dc[c][Zb.jb])] && (b[c] = !0);
        return b
    }

    function rk(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && Dc[c] && !bf[String(Dc[c][Zb.jb])]) return !0;
        return !1
    }

    function tk(a, b) {
        if (a) {
            var c = "" + a;
            0 !== c.indexOf("http://") && 0 !== c.indexOf("https://") && (c = "https://" + c);
            "/" === c[c.length - 1] && (c = c.substring(0, c.length - 1));
            return Tf("" + c + b).href
        }
    }

    function uk(a, b) {
        return vk() ? tk(a, b) : void 0
    }

    function vk() {
        var a = !1;
        return a
    };
    var wk = function() {
        var a = !1;
        return a
    };
    var xk;
    if (3 === Ze.ad.length) xk = "g";
    else {
        var yk = "G";
        xk = yk
    }
    var zk = {
            "": "n",
            UA: "u",
            AW: "a",
            DC: "d",
            G: "e",
            GF: "f",
            HA: "h",
            GTM: xk,
            OPT: "o"
        },
        Ak = function(a) {
            var b = Ze.I.split("-"),
                c = b[0].toUpperCase(),
                d = zk[c] || "i",
                e = a && "GTM" === c ? b[1] : "OPT" === c ? b[1] : "",
                f;
            if (3 === Ze.ad.length) {
                var g = "w";
                f = "2" + g
            } else f = "";
            return f + d + Ze.ad + e
        };

    function Bk(a, b) {
        if ("" === a) return b;
        var c = Number(a);
        return isNaN(c) ? b : c
    };
    var Ck = function(a, b) {
        a.addEventListener && a.addEventListener.call(a, "message", b, !1)
    };

    function Dk() {
        return kb("iPhone") && !kb("iPod") && !kb("iPad")
    };
    kb("Opera");
    kb("Trident") || kb("MSIE");
    kb("Edge");
    !kb("Gecko") || -1 != gb.toLowerCase().indexOf("webkit") && !kb("Edge") || kb("Trident") || kb("MSIE") || kb("Edge"); - 1 != gb.toLowerCase().indexOf("webkit") && !kb("Edge") && kb("Mobile");
    kb("Macintosh");
    kb("Windows");
    kb("Linux") || kb("CrOS");
    var Ek = qa.navigator || null;
    Ek && (Ek.appVersion || "").indexOf("X11");
    kb("Android");
    Dk();
    kb("iPad");
    kb("iPod");
    Dk() || kb("iPad") || kb("iPod");
    gb.toLowerCase().indexOf("kaios");
    var Fk = function(a, b) {
            for (var c = a, d = 0; 50 > d; ++d) {
                var e;
                try {
                    e = !(!c.frames || !c.frames[b])
                } catch (k) {
                    e = !1
                }
                if (e) return c;
                var f;
                a: {
                    try {
                        var g = c.parent;
                        if (g && g != c) {
                            f = g;
                            break a
                        }
                    } catch (k) {}
                    f = null
                }
                if (!(c = f)) break
            }
            return null
        },
        Gk = function(a) {
            var b = G;
            b = void 0 === b ? window.document : b;
            if (!a || !b.head) return null;
            var c = document.createElement("meta");
            b.head.appendChild(c);
            c.httpEquiv = "origin-trial";
            c.content = a;
            return c
        };
    var Hk = function() {};
    var Ik = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        Jk = function(a, b) {
            this.o = a;
            this.m = null;
            this.D = {};
            this.Z = 0;
            this.N = void 0 === b ? 500 : b;
            this.B = null
        };
    oa(Jk, Hk);
    var Lk = function(a) {
        return "function" === typeof a.o.__tcfapi || null != Kk(a)
    };
    Jk.prototype.addEventListener = function(a) {
        var b = {},
            c = sb(function() {
                return a(b)
            }),
            d = 0; - 1 !== this.N && (d = setTimeout(function() {
            b.tcString = "tcunavailable";
            b.internalErrorState = 1;
            c()
        }, this.N));
        var e = function(f, g) {
            clearTimeout(d);
            f ? (b = f, b.internalErrorState = Ik(b), g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
            a(b)
        };
        try {
            Mk(this, "addEventListener", e)
        } catch (f) {
            b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d),
                d = 0), c()
        }
    };
    Jk.prototype.removeEventListener = function(a) {
        a && a.listenerId && Mk(this, "removeEventListener", null, a.listenerId)
    };
    var Ok = function(a, b, c) {
            var d;
            d = void 0 === d ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (void 0 !== f) {
                        e = f[void 0 === d ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (0 === g) return !1;
            var k = c;
            2 === c ? (k = 0, 2 === g && (k = 1)) : 3 === c && (k = 1, 1 === g && (k = 0));
            var m;
            if (0 === k)
                if (a.purpose && a.vendor) {
                    var n = Nk(a.vendor.consents, void 0 === d ? "755" : d);
                    m = n && "1" === b && a.purposeOneTreatment && ("DE" === a.publisherCC || "CH" === a.publisherCC) ? !0 : n && Nk(a.purpose.consents, b)
                } else m = !0;
            else m = 1 === k ? a.purpose &&
                a.vendor ? Nk(a.purpose.legitimateInterests, b) && Nk(a.vendor.legitimateInterests, void 0 === d ? "755" : d) : !0 : !0;
            return m
        },
        Nk = function(a, b) {
            return !(!a || !a[b])
        },
        Mk = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.o.__tcfapi) {
                var e = a.o.__tcfapi;
                e(b, 2, c, d)
            } else if (Kk(a)) {
                Pk(a);
                var f = ++a.Z;
                a.D[f] = c;
                if (a.m) {
                    var g = {};
                    a.m.postMessage((g.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: f,
                        parameter: d
                    }, g), "*")
                }
            } else c({}, !1)
        },
        Kk = function(a) {
            if (a.m) return a.m;
            a.m = Fk(a.o, "__tcfapiLocator");
            return a.m
        },
        Pk = function(a) {
            a.B ||
                (a.B = function(b) {
                    try {
                        var c;
                        c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                        a.D[c.callId](c.returnValue, c.success)
                    } catch (d) {}
                }, Ck(a.o, a.B))
        };
    var Qk = !0;
    Qk = !1;
    var Rk = {
            1: 0,
            3: 0,
            4: 0,
            7: 3,
            9: 3,
            10: 3
        },
        Sk = Bk("", 550),
        Tk = Bk("", 500);

    function Uk() {
        var a = S.tcf || {};
        return S.tcf = a
    }
    var Vk = function(a, b) {
            this.B = a;
            this.m = b;
            this.o = l();
        },
        Wk = function(a) {},
        Xk = function(a) {},
        cl = function() {
            var a = Uk(),
                b = new Jk(B, Qk ? 3E3 : -1),
                c = new Vk(b, a);
            if ((Yk() ? !0 === B.gtag_enable_tcf_support : !1 !== B.gtag_enable_tcf_support) && !a.active && ("function" === typeof B.__tcfapi || Lk(b))) {
                a.active = !0;
                a.zc = {};
                Zk();
                var d = null;
                Qk ? d = B.setTimeout(function() {
                    $k(a);
                    al(a);
                    d = null
                }, Tk) : a.tcString = "tcunavailable";
                try {
                    b.addEventListener(function(e) {
                        d && (clearTimeout(d), d = null);
                        if (0 !== e.internalErrorState) $k(a), al(a), Wk(c);
                        else {
                            var f;
                            a.gdprApplies = e.gdprApplies;
                            if (!1 === e.gdprApplies) f = bl(), b.removeEventListener(e);
                            else if ("tcloaded" === e.eventStatus || "useractioncomplete" === e.eventStatus || "cmpuishown" === e.eventStatus) {
                                var g = {},
                                    k;
                                for (k in Rk)
                                    if (Rk.hasOwnProperty(k))
                                        if ("1" === k) {
                                            var m = e,
                                                n = !0;
                                            n = void 0 === n ? !1 : n;
                                            var p;
                                            var q = m;
                                            !1 === q.gdprApplies ? p = !0 : (void 0 === q.internalErrorState && (q.internalErrorState = Ik(q)), p = "error" === q.cmpStatus || 0 !== q.internalErrorState || "loaded" === q.cmpStatus && ("tcloaded" === q.eventStatus || "useractioncomplete" ===
                                                q.eventStatus) ? !0 : !1);
                                            g["1"] = p ? !1 === m.gdprApplies || "tcunavailable" === m.tcString || void 0 === m.gdprApplies && !n || "string" !== typeof m.tcString || !m.tcString.length ? !0 : Ok(m, "1", 0) : !1
                                        } else g[k] = Ok(e, k, Rk[k]);
                                f = g
                            }
                            f && (a.tcString = e.tcString || "tcempty", a.zc = f, al(a), Wk(c))
                        }
                    }), Xk(c)
                } catch (e) {
                    d && (clearTimeout(d), d = null), $k(a), al(a)
                }
            }
        };

    function $k(a) {
        a.type = "e";
        a.tcString = "tcunavailable";
        Qk && (a.zc = bl())
    }

    function Zk() {
        var a = {},
            b = (a.ad_storage = "denied", a.wait_for_update = Sk, a);
        $d(b)
    }
    var Yk = function() {
        var a = !1;
        a = !0;
        return a
    };

    function bl() {
        var a = {},
            b;
        for (b in Rk) Rk.hasOwnProperty(b) && (a[b] = !0);
        return a
    }

    function al(a) {
        var b = {},
            c = (b.ad_storage = a.zc["1"] ? "granted" : "denied", b);
        dl();
        be(c, 0)
    }
    var el = function() {
            var a = Uk();
            if (a.active && void 0 !== a.loadTime) return Number(a.loadTime)
        },
        dl = function() {
            var a = Uk();
            return a.active ? a.tcString || "" : ""
        },
        fl = function() {
            var a = Uk();
            return a.active && void 0 !== a.gdprApplies ? a.gdprApplies ? "1" : "0" : ""
        },
        gl = function(a) {
            if (!Rk.hasOwnProperty(String(a))) return !0;
            var b = Uk();
            return b.active && b.zc ? !!b.zc[String(a)] : !0
        };

    function ml(a) {
        a = a || {};
        if (rg(B) && G.cookie) {
            var b = Og(Mh(a.prefix) + "_ec", a.domain, a.path, ["1"], P.C);
            if (b) {
                var c = b.split(".");
                if (3 === c.length) {
                    var d = 1E3 * Number(c[1]) || 0;
                    if (0 !== d) return {
                        Wf: c[0] + "." + c[1],
                        $h: d,
                        fg: 1E3 * Number(c[2]) || 0
                    }
                }
            }
        }
    }

    function nl(a) {
        if (!Sd() || Pd(P.C)) {
            var b = ml(a);
            if (b && !(18E5 < l() - b.fg)) return b.Wf
        }
    };
    var ol = !1;
    var pl = function() {
            this.m = {}
        },
        ql = function(a, b, c) {
            null != c && (a.m[b] = c)
        },
        rl = function(a) {
            return Object.keys(a.m).map(function(b) {
                return encodeURIComponent(b) + "=" + encodeURIComponent(a.m[b])
            }).join("&")
        },
        tl = function(a, b, c, d, e) {};
    var vl = /[A-Z]+/,
        wl = /\s/,
        xl = function(a) {
            if (h(a) && (a = Oa(a), !wl.test(a))) {
                var b = a.indexOf("-");
                if (!(0 > b)) {
                    var c = a.substring(0, b);
                    if (vl.test(c)) {
                        for (var d = a.substring(b + 1).split("/"), e = 0; e < d.length; e++)
                            if (!d[e]) return;
                        return {
                            id: a,
                            prefix: c,
                            containerId: c + "-" + d[0],
                            K: d
                        }
                    }
                }
            }
        },
        zl = function(a) {
            for (var b = {}, c = 0; c < a.length; ++c) {
                var d = xl(a[c]);
                d && (b[d.id] = d)
            }
            yl(b);
            var e = [];
            Ea(b, function(f, g) {
                e.push(g)
            });
            return e
        };

    function yl(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                "AW" === d.prefix && d.K[1] && b.push(d.containerId)
            }
        for (var e = 0; e < b.length; ++e) delete a[b[e]]
    };
    var Bl = function(a, b, c, d) {
            return (2 === Al() || d || "http:" != B.location.protocol ? a : b) + c
        },
        Al = function() {
            var a = Bb(),
                b;
            if (1 === a) a: {
                var c = ef;c = c.toLowerCase();
                for (var d = "https://" + c, e = "http://" + c, f = 1, g = G.getElementsByTagName("script"), k = 0; k < g.length && 100 > k; k++) {
                    var m = g[k].src;
                    if (m) {
                        m = m.toLowerCase();
                        if (0 === m.indexOf(e)) {
                            b = 3;
                            break a
                        }
                        1 === f && 0 === m.indexOf(d) && (f = 2)
                    }
                }
                b = f
            }
            else b = a;
            return b
        };
    var Sm = function() {
            var a = !0;
            gl(7) && gl(9) && gl(10) || (a = !1);
            var b = !0;
            b = !1;
            b && !Rm() && (a = !1);
            return a
        },
        Rm = function() {
            var a = !0;
            gl(3) && gl(4) || (a = !1);
            return a
        };
    var yn = !1;
    yn = !0;
    var zn = !1;
    zn = !0;

    function An() {
        var a = S;
        return a.gcq = a.gcq || new Bn
    }
    var Cn = function(a, b, c) {
            An().register(a, b, c)
        },
        Dn = function(a, b, c, d) {
            An().push("event", [b, a], c, d)
        },
        En = function(a, b) {
            An().push("config", [a], b)
        },
        Fn = function(a, b, c, d) {
            An().push("get", [a, b], c, d)
        },
        Gn = {},
        Hn = function() {
            this.status = 1;
            this.containerConfig = {};
            this.targetConfig = {};
            this.remoteConfig = {};
            this.o = {};
            this.B = null;
            this.m = !1
        },
        In = function(a, b, c, d, e) {
            this.type = a;
            this.B = b;
            this.P = c || "";
            this.m = d;
            this.o = e
        },
        Bn = function() {
            this.o = {};
            this.B = {};
            this.m = [];
            this.D = {
                AW: !1,
                UA: !1
            };
            this.enableDeferrableCommandAfterConfig =
                yn
        },
        Jn = function(a, b) {
            var c = xl(b);
            return a.o[c.containerId] = a.o[c.containerId] || new Hn
        },
        Kn = function(a, b, c) {
            if (b) {
                var d = xl(b);
                if (d && 1 === Jn(a, b).status) {
                    Jn(a, b).status = 2;
                    var e = {};
                    Jj && (e.timeoutId = B.setTimeout(function() {
                        Ad(38);
                        pj()
                    }, 3E3));
                    a.push("require", [e], d.containerId);
                    Gn[d.containerId] = l();
                    if (wk()) {} else {
                        var g = "/gtag/js?id=" + encodeURIComponent(d.containerId) + "&l=dataLayer&cx=c";
                        Ze.Ib && "SGTM_TOKEN" !== Ze.Ib.replaceAll("@@", "") && (g += "&sign=" + Ze.Ib);
                        var k = ("http:" != B.location.protocol ? "https:" : "http:") + ("//www.googletagmanager.com" + g),
                            m = uk(c, g) || k;
                        Ab(m)
                    }
                }
            }
        },
        Ln = function(a, b, c, d) {
            if (d.P) {
                var e = Jn(a, d.P),
                    f = e.B;
                if (f) {
                    var g = M(c),
                        k = M(e.targetConfig[d.P]),
                        m = M(e.containerConfig),
                        n = M(e.remoteConfig),
                        p = M(a.B),
                        q = tf("gtm.uniqueEventId"),
                        t = xl(d.P).prefix,
                        u = Ra(function() {
                            var v =
                                g[P.Bb];
                            v && H(v)
                        }),
                        r = Ue(Te(Ve(Se(Qe(Re(Pe(Oe(Ge(g), k), m), n), p), function() {
                            Wj(q, t, "2");
                            zn && u()
                        }), function() {
                            Wj(q, t, "3");
                            zn && u()
                        }), function(v, x) {
                            a.D[v] = x
                        }), function(v) {
                            return a.D[v]
                        });
                    try {
                        Wj(q, t, "1");
                        f(d.P, b, d.B, r)
                    } catch (v) {
                        Wj(q, t, "4");
                    }
                }
            }
        };
    Bn.prototype.register = function(a, b, c) {
        var d = Jn(this, a);
        if (3 !== d.status) {
            d.B = b;
            d.status = 3;
            c && (M(d.remoteConfig, c), d.remoteConfig = c);
            var e = xl(a),
                f = Gn[e.containerId];
            if (void 0 !== f) {
                var g = S[e.containerId].bootstrap,
                    k = e.prefix.toUpperCase();
                S[e.containerId]._spx && (k = k.toLowerCase());
                var m = tf("gtm.uniqueEventId"),
                    n = k,
                    p = l() - g;
                if (Jj && !uj[m]) {
                    m !== qj && (lj(), qj = m);
                    var q = n + "." + Math.floor(g - f) + "." + Math.floor(p);
                    yj = yj ? yj + "," + q : "&cl=" + q
                }
                delete Gn[e.containerId]
            }
            this.flush()
        }
    };
    Bn.prototype.push = function(a, b, c, d) {
        var e = Math.floor(l() / 1E3);
        Kn(this, c, b[0][P.na] || this.B[P.na]);
        yn && c && Jn(this, c).m && (d = !1);
        this.m.push(new In(a, e, c, b, d));
        d || this.flush()
    };
    Bn.prototype.insert = function(a, b, c) {
        var d = Math.floor(l() / 1E3);
        0 < this.m.length ? this.m.splice(1, 0, new In(a, d, c, b, !1)) : this.m.push(new In(a, d, c, b, !1))
    };
    Bn.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.m.length;) {
            var f = this.m[0];
            if (f.o) yn ? !f.P || Jn(this, f.P).m ? (f.o = !1, this.m.push(f)) : c.push(f) : (f.o = !1, this.m.push(f)), this.m.shift();
            else {
                switch (f.type) {
                    case "require":
                        if (3 !== Jn(this, f.P).status && !a) {
                            yn && this.m.push.apply(this.m, c);
                            return
                        }
                        Jj && B.clearTimeout(f.m[0].timeoutId);
                        break;
                    case "set":
                        Ea(f.m[0], function(t, u) {
                            M(Va(t, u), b.B)
                        });
                        break;
                    case "config":
                        e.Fa = {};
                        Ea(f.m[0], function(t) {
                            return function(u, r) {
                                M(Va(u, r), t.Fa)
                            }
                        }(e));
                        var g = !!e.Fa[P.Tc];
                        delete e.Fa[P.Tc];
                        var k = Jn(this, f.P),
                            m = xl(f.P),
                            n = m.containerId === m.id;
                        g || (n ? k.containerConfig = {} : k.targetConfig[f.P] = {});
                        k.m && g || Ln(this, P.xa, e.Fa, f);
                        k.m = !0;
                        delete e.Fa[P.cc];
                        n ? M(e.Fa, k.containerConfig) : M(e.Fa, k.targetConfig[f.P]);
                        yn && (d = !0);
                        break;
                    case "event":
                        e.Dc = {};
                        Ea(f.m[0], function(t) {
                            return function(u, r) {
                                M(Va(u, r), t.Dc)
                            }
                        }(e));
                        Ln(this, f.m[1], e.Dc, f);
                        break;
                    case "get":
                        var p = {},
                            q = (p[P.Ja] = f.m[0], p[P.Sa] = f.m[1], p);
                        Ln(this, P.Ha, q, f)
                }
                this.m.shift();
                Mn(this, f)
            }
            e = {
                Fa: e.Fa,
                Dc: e.Dc
            }
        }
        yn && (this.m.push.apply(this.m,
            c), d && this.flush())
    };
    var Mn = function(a, b) {
        if ("require" !== b.type)
            if (b.P)
                for (var c = a.getCommandListeners(b.P)[b.type] || [], d = 0; d < c.length; d++) c[d]();
            else
                for (var e in a.o)
                    if (a.o.hasOwnProperty(e)) {
                        var f = a.o[e];
                        if (f && f.o)
                            for (var g = f.o[b.type] || [], k = 0; k < g.length; k++) g[k]()
                    }
    };
    Bn.prototype.getRemoteConfig = function(a) {
        return Jn(this, a).remoteConfig
    };
    Bn.prototype.getCommandListeners = function(a) {
        return Jn(this, a).o
    };
    var Nn = function(a, b, c) {
            var d = {
                event: b,
                "gtm.element": a,
                "gtm.elementClasses": Mb(a, "className"),
                "gtm.elementId": a["for"] || Hb(a, "id") || "",
                "gtm.elementTarget": a.formTarget || Mb(a, "target") || ""
            };
            c && (d["gtm.triggers"] = c.join(","));
            d["gtm.elementUrl"] = (a.attributes && a.attributes.formaction ? a.formAction : "") || a.action || Mb(a, "href") || a.src || a.code || a.codebase || "";
            return d
        },
        On = function(a) {
            S.hasOwnProperty("autoEventsSettings") || (S.autoEventsSettings = {});
            var b = S.autoEventsSettings;
            b.hasOwnProperty(a) || (b[a] = {});
            return b[a]
        },
        Pn = function(a, b, c) {
            On(a)[b] = c
        },
        Qn = function(a, b, c, d) {
            var e = On(a),
                f = Qa(e, b, d);
            e[b] = c(f)
        },
        Rn = function(a, b, c) {
            var d = On(a);
            return Qa(d, b, c)
        };
    var Sn = ["input", "select", "textarea"],
        Tn = ["button", "hidden", "image", "reset", "submit"],
        Un = function(a) {
            var b = a.tagName.toLowerCase();
            return !xa(Sn, function(c) {
                return c === b
            }) || "input" === b && xa(Tn, function(c) {
                return c === a.type.toLowerCase()
            }) ? !1 : !0
        },
        Vn = function(a) {
            return a.form ? a.form.tagName ? a.form : G.getElementById(a.form) : Kb(a, ["form"], 100)
        },
        Wn = function(a, b, c) {
            if (!a.elements) return 0;
            for (var d = b.dataset[c], e = 0, f = 1; e < a.elements.length; e++) {
                var g = a.elements[e];
                if (Un(g)) {
                    if (g.dataset[c] === d) return f;
                    f++
                }
            }
            return 0
        };
    var ao = !1,
        bo = [];

    function co() {
        if (!ao) {
            ao = !0;
            for (var a = 0; a < bo.length; a++) H(bo[a])
        }
    }
    var eo = function(a) {
        ao ? H(a) : bo.push(a)
    };

    function fo(a, b) {
        a = String(a);
        b = String(b);
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    }
    var go = new za;

    function ho(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + d,
                f = go.get(e);
            f || (f = new RegExp(b, d), go.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function io(a, b) {
        function c(g) {
            var k = Tf(g),
                m = Rf(k, "protocol"),
                n = Rf(k, "host", !0),
                p = Rf(k, "port"),
                q = Rf(k, "path").toLowerCase().replace(/\/$/, "");
            if (void 0 === m || "http" == m && "80" == p || "https" == m && "443" == p) m = "web", p = "default";
            return [m, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function jo(a) {
        return ko(a) ? 1 : 0
    }

    function ko(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && va(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = M(a, {});
                M({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (jo(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return 0 <= String(b).indexOf(String(c));
            case "_css":
                var f;
                a: {
                    if (b) {
                        var g = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];
                        try {
                            for (var k = 0; k < g.length; k++)
                                if (b[g[k]]) {
                                    f = b[g[k]](c);
                                    break a
                                }
                        } catch (n) {}
                    }
                    f = !1
                }
                return f;
            case "_ew":
                return fo(b, c);
            case "_eq":
                return String(b) ==
                    String(c);
            case "_ge":
                return Number(b) >= Number(c);
            case "_gt":
                return Number(b) > Number(c);
            case "_lc":
                var m;
                m = String(b).split(",");
                return 0 <= wa(m, String(c));
            case "_le":
                return Number(b) <= Number(c);
            case "_lt":
                return Number(b) < Number(c);
            case "_re":
                return ho(b, c, a.ignore_case);
            case "_sw":
                return 0 == String(b).indexOf(String(c));
            case "_um":
                return io(b, c)
        }
        return !1
    };
    Object.freeze({
        dl: 1,
        id: 1
    });
    var oo = "HA GF G UA AW DC".split(" "),
        po = !1;
    po = !0;
    var qo = !1,
        ro = !1;

    function so(a, b) {
        var c = {
            event: a
        };
        b && (c.eventModel = M(b), b[P.Bb] && (c.eventCallback = b[P.Bb]), b[P.Nc] && (c.eventTimeout = b[P.Nc]));
        return c
    }

    function to(a) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: mf()
        });
        return a["gtm.uniqueEventId"]
    }

    function uo() {
        return qo
    }
    var vo = {
            config: function(a) {
                var b, c = to(a);
                return b
            },
            consent: function(a) {
                function b() {
                    uo() && M(a[2], {
                        subcommand: a[1]
                    })
                }
                if (3 === a.length) {
                    Ad(39);
                    var c = mf(),
                        d = a[1];
                    "default" === d ? (b(), $d(a[2])) : "update" === d && (b(), be(a[2], c))
                }
            },
            event: function(a) {
                var b = a[1];
                if (!(2 > a.length) && h(b)) {
                    var c;
                    if (2 < a.length) {
                        if (!Rb(a[2]) && void 0 != a[2] || 3 < a.length) return;
                        c = a[2]
                    }
                    var d = so(b, c),
                        e = to(a);
                    d["gtm.uniqueEventId"] = e;
                    return d
                }
            },
            get: function(a) {},
            js: function(a) {
                if (2 == a.length && a[1].getTime) {
                    ro = !0;
                    uo();
                    var b = {};
                    return b.event = "gtm.js", b["gtm.start"] = a[1].getTime(), b["gtm.uniqueEventId"] = to(a), b
                }
            },
            policy: function() {},
            set: function(a) {
                var b;
                2 == a.length && Rb(a[1]) ?
                    b = M(a[1]) : 3 == a.length && h(a[1]) && (b = {}, Rb(a[2]) || va(a[2]) ? b[a[1]] = M(a[2]) : b[a[1]] = a[2]);
                if (b) {
                    b._clear = !0;
                    return b
                }
            }
        },
        wo = {
            policy: !0
        };
    var xo = function(a, b) {
            var c = a.hide;
            if (c && void 0 !== c[b] && c.end) {
                c[b] = !1;
                var d = !0,
                    e;
                for (e in c)
                    if (c.hasOwnProperty(e) && !0 === c[e]) {
                        d = !1;
                        break
                    }
                d && (c.end(), c.end = null)
            }
        },
        zo = function(a) {
            var b = yo(),
                c = b && b.hide;
            c && c.end && (c[a] = !0)
        };
    var Qo = function(a) {
        if (Po(a)) return a;
        this.m = a
    };
    Qo.prototype.mi = function() {
        return this.m
    };
    var Po = function(a) {
        return !a || "object" !== Pb(a) || Rb(a) ? !1 : "getUntrustedUpdateValue" in a
    };
    Qo.prototype.getUntrustedUpdateValue = Qo.prototype.mi;
    var Ro = [],
        So = !1,
        To = !1,
        Uo = function(a) {
            return B["dataLayer"].push(a)
        },
        Vo = function(a, b) {
            var c = S["dataLayer"],
                d = c ? c.subscribers : 1,
                e = 0,
                f = !1,
                g = void 0;
            b && (g = B.setTimeout(function() {
                f || (f = !0, a());
                g = void 0
            }, b));
            return function() {
                ++e === d && (g && (B.clearTimeout(g), g = void 0), f || (a(), f = !0))
            }
        };

    function Wo(a) {
        var b = a._clear;
        Ea(a, function(d, e) {
            "_clear" !== d && (b && wf(d, void 0), wf(d, e))
        });
        gf || (gf = a["gtm.start"]);
        var c = a["gtm.uniqueEventId"];
        if (!a.event) return !1;
        c || (c = mf(), a["gtm.uniqueEventId"] = c, wf("gtm.uniqueEventId", c));
        return sk(a)
    }

    function Xo() {
        var a = Ro[0];
        if (null == a || "object" !== typeof a) return !1;
        if (a.event) return !0;
        if (Ha(a)) {
            var b = a[0];
            if ("config" === b || "event" === b || "js" === b) return !0
        }
        return !1
    }

    function Yo() {
        for (var a = !1; !To && 0 < Ro.length;) {
            if (!So && Xo()) {
                var b = {},
                    c = (b.event = "gtm.init_consent", b),
                    d = {},
                    e = (d.event = "gtm.init", d);
                var f = Ro[0]["gtm.uniqueEventId"];
                f && (c["gtm.uniqueEventId"] = f - 2, e["gtm.uniqueEventId"] = f - 1);
                Ro.unshift(c, e);
                So = !0
            }
            To = !0;
            delete qf.eventModel;
            sf();
            var g = Ro.shift();
            if (null != g) {
                var k = Po(g);
                if (k) {
                    var m = g;
                    g = Po(m) ? m.getUntrustedUpdateValue() : void 0;
                    for (var n = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], p = 0; p < n.length; p++) {
                        var q = n[p],
                            t = tf(q, 1);
                        if (va(t) || Rb(t)) t = M(t);
                        rf[q] = t
                    }
                }
                try {
                    if (ta(g)) try {
                        g.call(uf)
                    } catch (A) {} else if (va(g)) {
                        var u = g;
                        if (h(u[0])) {
                            var r = u[0].split("."),
                                v = r.pop(),
                                x = u.slice(1),
                                z = tf(r.join("."), 2);
                            if (void 0 !== z && null !== z) try {
                                z[v].apply(z, x)
                            } catch (A) {}
                        }
                    } else {
                        if (Ha(g)) {
                            a: {
                                var w = g;
                                if (w.length &&
                                    h(w[0])) {
                                    var y = vo[w[0]];
                                    if (y && (!k || !wo[w[0]])) {
                                        g = y(w);
                                        break a
                                    }
                                }
                                g = void 0
                            }
                            if (!g) {
                                To = !1;
                                continue
                            }
                        }
                        a = Wo(g) || a
                    }
                } finally {
                    k && sf(!0)
                }
            }
            To = !1
        }
        return !a
    }

    function Zo() {
        var b = Yo();
        try {
            xo(B["dataLayer"], Ze.I)
        } catch (c) {}
        return b
    }
    var ap = function() {
            var a = wb("dataLayer", []),
                b = wb("google_tag_manager", {});
            b = b["dataLayer"] = b["dataLayer"] || {};
            Ei(function() {
                b.gtmDom || (b.gtmDom = !0, a.push({
                    event: "gtm.dom"
                }))
            });
            eo(function() {
                b.gtmLoad || (b.gtmLoad = !0, a.push({
                    event: "gtm.load"
                }))
            });
            b.subscribers = (b.subscribers || 0) + 1;
            var c = a.push;
            a.push = function() {
                var e;
                if (0 < S.SANDBOXED_JS_SEMAPHORE) {
                    e = [];
                    for (var f = 0; f < arguments.length; f++) e[f] = new Qo(arguments[f])
                } else e = [].slice.call(arguments, 0);
                var g = c.apply(a, e);
                Ro.push.apply(Ro, e);
                if (300 <
                    this.length)
                    for (Ad(4); 300 < this.length;) this.shift();
                var k = "boolean" !== typeof g || g;
                return Yo() && k
            };
            var d = a.slice(0);
            Ro.push.apply(Ro, d);
            if ($o()) {
                H(Zo)
            }
        },
        $o = function() {
            var a = !0;
            return a
        };
    var bp = {};
    bp.Xc = new String("undefined");
    var cp = function(a) {
        this.m = function(b) {
            for (var c = [], d = 0; d < a.length; d++) c.push(a[d] === bp.Xc ? b : a[d]);
            return c.join("")
        }
    };
    cp.prototype.toString = function() {
        return this.m("undefined")
    };
    cp.prototype.valueOf = cp.prototype.toString;
    bp.Ih = cp;
    bp.ee = {};
    bp.Zh = function(a) {
        return new cp(a)
    };
    var dp = {};
    bp.Si = function(a, b) {
        var c = mf();
        dp[c] = [a, b];
        return c
    };
    bp.Tf = function(a) {
        var b = a ? 0 : 1;
        return function(c) {
            var d = dp[c];
            if (d && "function" === typeof d[b]) d[b]();
            dp[c] = void 0
        }
    };
    bp.vi = function(a) {
        for (var b = !1, c = !1, d = 2; d < a.length; d++) b =
            b || 8 === a[d], c = c || 16 === a[d];
        return b && c
    };
    bp.Ki = function(a) {
        if (a === bp.Xc) return a;
        var b = mf();
        bp.ee[b] = a;
        return 'google_tag_manager["' + Ze.I + '"].macro(' + b + ")"
    };
    bp.Fi = function(a, b, c) {
        a instanceof bp.Ih && (a = a.m(bp.Si(b, c)), b = sa);
        return {
            ri: a,
            onSuccess: b
        }
    };
    var op = B.clearTimeout,
        pp = B.setTimeout,
        V = function(a, b, c) {
            if (wk()) {
                b && H(b)
            } else return Ab(a, b, c, void 0)
        },
        qp = function() {
            return new Date
        },
        rp = function() {
            return B.location.href
        },
        sp = function(a) {
            return Rf(Tf(a), "fragment")
        },
        tp = function(a) {
            return Sf(Tf(a))
        },
        up = function(a, b) {
            return tf(a, b || 2)
        },
        vp = function(a, b, c) {
            var d;
            b ? (a.eventCallback = b, c && (a.eventTimeout = c), d = Uo(a)) : d = Uo(a);
            return d
        },
        wp = function(a, b) {
            B[a] = b
        },
        X = function(a,
            b, c) {
            b && (void 0 === B[a] || c && !B[a]) && (B[a] = b);
            return B[a]
        },
        xp = function(a, b, c) {
            return zg(a, b, void 0 === c ? !0 : !!c)
        },
        yp = function(a, b, c) {
            return 0 === Ig(a, b, c)
        },
        zp = function(a, b) {
            if (wk()) {
                b && H(b)
            } else Cb(a, b)
        },
        Ap = function(a) {
            return !!Rn(a, "init", !1)
        },
        Bp = function(a) {
            Pn(a, "init", !0)
        },
        Cp = function(a) {
            var b = ef + "?id=" + encodeURIComponent(a) + "&l=dataLayer";
            Ze.Ib && "SGTM_TOKEN" !== Ze.Ib.replaceAll("@@", "") && (b += "&sign=" + Ze.Ib);
            V(Bl("https://",
                "http://", b))
        },
        Dp = function(a, b, c) {
            Jj && (Yb(a) || Xj(c, b, a))
        };
    var Ep = bp.Fi;
    var aq = encodeURI,
        Y = encodeURIComponent,
        bq = Eb;
    var cq = function(a, b) {
        if (!a) return !1;
        var c = Rf(Tf(a), "host");
        if (!c) return !1;
        for (var d = 0; b && d < b.length; d++) {
            var e = b[d] && b[d].toLowerCase();
            if (e) {
                var f = c.length - e.length;
                0 < f && "." != e.charAt(0) && (f--, e = "." + e);
                if (0 <= f && c.indexOf(e, f) == f) return !0
            }
        }
        return !1
    };
    var dq = function(a, b, c) {
        for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
        return e ? d : null
    };

    function Lr() {
        return B.gaGlobal = B.gaGlobal || {}
    }
    var Mr = function() {
            var a = Lr();
            a.hid = a.hid || ya();
            return a.hid
        },
        Nr = function(a, b) {
            var c = Lr();
            if (void 0 == c.vid || b && !c.from_cookie) c.vid = a, c.from_cookie = b
        };
    var ns = function() {
        if (ta(B.__uspapi)) {
            var a = "";
            try {
                B.__uspapi("getUSPData", 1, function(b, c) {
                    if (c && b) {
                        var d = b.uspString;
                        d && RegExp("^[\\da-zA-Z-]{1,20}$").test(d) && (a = d)
                    }
                })
            } catch (b) {}
            return a
        }
    };
    var Ns = window,
        Os = document,
        Ps = function(a) {
            var b = Ns._gaUserPrefs;
            if (b && b.ioo && b.ioo() || a && !0 === Ns["ga-disable-" + a]) return !0;
            try {
                var c = Ns.external;
                if (c && c._gaUserPrefs && "oo" == c._gaUserPrefs) return !0
            } catch (f) {}
            for (var d = qg("AMP_TOKEN", String(Os.cookie), !0), e = 0; e < d.length; e++)
                if ("$OPT_OUT" == d[e]) return !0;
            return Os.getElementById("__gaOptOutExtension") ? !0 : !1
        };
    var Qs = {};

    function Ts(a) {
        delete a.eventModel[P.cc];
        Vs(a.eventModel)
    }
    var Vs = function(a) {
        Ea(a, function(c) {
            "_" === c.charAt(0) && delete a[c]
        });
        var b = a[P.Ka] || {};
        Ea(b, function(c) {
            "_" === c.charAt(0) && delete b[c]
        })
    };
    var Ys = function(a, b, c) {
            Dn(b, c, a)
        },
        Zs = function(a, b, c) {
            Dn(b, c, a, !0)
        },
        ct = function(a, b) {};

    function $s(a, b) {}
    var Z = {
        g: {}
    };





    Z.g.e = ["google"],
        function() {
            (function(a) {
                Z.__e = a;
                Z.__e.h = "e";
                Z.__e.isVendorTemplate = !0;
                Z.__e.priorityOverride = 0
            })(function(a) {
                var b = String(zf(a.vtp_gtmEventId, "event"));
                a.vtp_gtmCachedValues && (b = String(a.vtp_gtmCachedValues.event));
                return b
            })
        }();
    Z.g.f = ["google"],
        function() {
            (function(a) {
                Z.__f = a;
                Z.__f.h = "f";
                Z.__f.isVendorTemplate = !0;
                Z.__f.priorityOverride = 0
            })(function(a) {
                var b = up("gtm.referrer", 1) || G.referrer;
                return b ? a.vtp_component && "URL" != a.vtp_component ? Rf(Tf(String(b)), a.vtp_component, a.vtp_stripWww, a.vtp_defaultPages, a.vtp_queryKey) : tp(String(b)) : String(b)
            })
        }();
    Z.g.u = ["google"],
        function() {
            var a = function(b) {
                return {
                    toString: function() {
                        return b
                    }
                }
            };
            (function(b) {
                Z.__u = b;
                Z.__u.h = "u";
                Z.__u.isVendorTemplate = !0;
                Z.__u.priorityOverride = 0
            })(function(b) {
                var c;
                c = (c = b.vtp_customUrlSource ? b.vtp_customUrlSource : up("gtm.url", 1)) || rp();
                var d = b[a("vtp_component")];
                if (!d || "URL" == d) return tp(String(c));
                var e = Tf(String(c)),
                    f;
                if ("QUERY" === d) a: {
                    var g = b[a("vtp_multiQueryKeys").toString()],
                        k = b[a("vtp_queryKey").toString()] || "",
                        m = b[a("vtp_ignoreEmptyQueryParam").toString()],
                        n;g ? va(k) ?
                    n = k : n = String(k).replace(/\s+/g, "").split(",") : n = [String(k)];
                    for (var p = 0; p < n.length; p++) {
                        var q = Rf(e, "QUERY", void 0, void 0, n[p]);
                        if (void 0 != q && (!m || "" !== q)) {
                            f = q;
                            break a
                        }
                    }
                    f = void 0
                }
                else f = Rf(e, d, "HOST" == d ? b[a("vtp_stripWww")] : void 0, "PATH" == d ? b[a("vtp_defaultPages")] : void 0, void 0);
                return f
            })
        }();

















    var dt = {};
    dt.macro = function(a) {
        if (bp.ee.hasOwnProperty(a)) return bp.ee[a]
    }, dt.onHtmlSuccess = bp.Tf(!0), dt.onHtmlFailure = bp.Tf(!1);
    dt.dataLayer = uf;
    dt.callback = function(a) {
        kf.hasOwnProperty(a) && ta(kf[a]) && kf[a]();
        delete kf[a]
    };
    dt.bootstrap = 0;
    dt._spx = !1;

    function et() {
        S[Ze.I] = dt;
        Sa(lf, Z.g);
        Kc = Kc || bp;
        Lc = Tc
    }

    function ft() {
        var a = !1;
        a && Ni("INIT");
        Dd().o();
        S = B.google_tag_manager = B.google_tag_manager || {};
        cl();
        Bh.enable_gbraid_cookie_write = !0;
        var b = !!S[Ze.I];
        if (b) {
            var c = S.zones;
            c && c.unregisterChild(Ze.I);
        } else {
            for (var d = data.resource || {}, e = d.macros || [], f = 0; f < e.length; f++) Ac.push(e[f]);
            for (var g = d.tags || [], k = 0; k < g.length; k++) Dc.push(g[k]);
            for (var m = d.predicates || [], n = 0; n < m.length; n++) Cc.push(m[n]);
            for (var p = d.rules || [], q = 0; q < p.length; q++) {
                for (var t = p[q], u = {}, r = 0; r < t.length; r++) u[t[r][0]] = Array.prototype.slice.call(t[r], 1);
                Bc.push(u)
            }
            Ic = Z;
            Jc = jo;
            et();
            ap();
            zi = !1;
            Ai = 0;
            if ("interactive" == G.readyState && !G.createEventObject || "complete" == G.readyState) Ci();
            else {
                Fb(G, "DOMContentLoaded", Ci);
                Fb(G, "readystatechange", Ci);
                if (G.createEventObject && G.documentElement.doScroll) {
                    var v = !0;
                    try {
                        v = !B.frameElement
                    } catch (A) {}
                    v &&
                        Di()
                }
                Fb(B, "load", Ci)
            }
            ao = !1;
            "complete" === G.readyState ? co() : Fb(B, "load", co);
            Jj && B.setInterval(Dj, 864E5);
            hf = (new Date).getTime();
            if (a) {
                var y = Oi("INIT");
            }
        }
    }
    (function(a) {
        function b(u) {
            var r = l();
            return u < r + 3E5 && u > r - 9E5
        }
        if (!B["__TAGGY_INSTALLED"]) {
            var c = !1;
            if (G.referrer) {
                var d = Tf(G.referrer);
                c = "cct.google" === Qf(d, "host")
            }
            if (!c) {
                var e = zg("googTaggyReferrer");
                c = e.length && e[0].length
            }
            c && (B["__TAGGY_INSTALLED"] = !0, Ab("https://cct.google/taggy/agent.js"))
        }
        var g = function(u) {
                var r = "GTM",
                    v = "GTM";
                var x = B["google.tagmanager.debugui2.queue"];
                x || (x = [], B["google.tagmanager.debugui2.queue"] = x, Ab("https://www.googletagmanager.com/debug/bootstrap?id=" + Ze.I + "&src=" + v + "&cond=" + u + "&gtm=" + Ak()));
                var z = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: vb,
                        containerProduct: r,
                        debug: !1,
                        id: Ze.I
                    }
                };
                z.data.resume = function() {
                    a()
                };
                Ze.Ng && (z.data.initialPublish = !0);
                x.push(z)
            },
            k = void 0,
            m = Rf(B.location, "query", !1, void 0, "gtm_debug"),
            n = !0;
        n && "x" === m && (k = 1);
        !k && b(Number(m)) && (k = 2);
        if (!k && G.referrer) {
            var p = Tf(G.referrer);
            "tagassistant.google.com" === Qf(p, "host") && (k = 3)
        }
        if (!k) {
            var q = zg("__TAG_ASSISTANT");
            q.length && q[0].length && (k = 4)
        }
        if (!k && G.documentElement.hasAttribute("data-tag-assistant-present")) {
            k = 5;
            var t = Number(G.documentElement.getAttribute("data-tag-assistant-present"));
            k = b(t) ? 5 : void 0;
        }
        k && vb ? g(k) : a()
    })(ft);

})()