//var id='';
//var idL='';
// function clickit(gotid) {
//	 if(window.innerWidth>"600px"){
//     if(id!=''){
//      if(document.getElementById(id).value==''){
//     document.getElementById(id).style.visibility = "hidden";}
//     document.getElementById(gotid).style.visibility = "visible";
//     
//    if(id!='Number'){
//     document.getElementById('input-'+id).placeholder=id;}
//    else{
//    document.getElementById('input-'+id).placeholder="Phone "+id;
//    }	 
//     document.getElementById('input-'+gotid).placeholder="";
//
//     }else{
//         document.getElementById(gotid).style.visibility = "visible";
//     }
//     id =gotid;}
// }
//
//function clickitlogin(gotidL){
//    if(window.innerWidth>"600px"){
//     if(idL!=''){
//        if(document.getElementById(idL).value==''){
//     document.getElementById(idL).style.visibility = "hidden";}
//     document.getElementById(gotidL).style.visibility = "visible";
//    if(idL=='EmailLogin'){
//     document.getElementById('input-'+idL).placeholder="Email";	 }
//    if(idL=='PasswordLogin'){
//     document.getElementById('input-'+idL).placeholder="Password";	 }
//     document.getElementById('input-'+gotidL).placeholder="";
//     }else{
//         document.getElementById(gotidL).style.visibility = "visible";
//     }
//     idL = gotidL;
//	}
// }

//open-close


function openRForm() {
    document.getElementById("disable-div").style.display = "block";
    document.getElementById("RForm").style.display = "block";
}

function openLForm() {
    document.getElementById("disable-div").style.display = "block";
    document.getElementById("LForm").style.display = "block";
}

function closeForm() {
    document.getElementById("disable-div").style.display = "none";
    document.getElementById("RForm").style.display = "none";
    document.getElementById("LForm").style.display = "none";
    document.getElementById("disable-div").style.display = "none";
}

function closeForgot() {
    document.getElementById("forgot-password").style.display = "none";
    document.getElementById("disable-div-1").style.display = "none";
}

function closeOtp() {
    document.getElementById("confirm-otp").style.display = "none";
    document.getElementById("disable-div-1").style.display = "none";
}

function changeto(chng) {
    if (chng == 'LForm') {
        document.getElementById("RForm").style.display = "none";
        document.getElementById("LForm").style.display = "block";
    } else {
        document.getElementById("LForm").style.display = "none";
        document.getElementById("RForm").style.display = "block";
    }
}

function send(name, email) {
    $.ajax({
        url: "googlesign.php",
        type: 'post',
        data: {
            name: name,
            email: email
        },
        success: function(response) {
            if (!sessionStorage.getItem('reloaded')) {
                sessionStorage.setItem("reloaded", "yes");
                location.reload(true);
            }
        }
    });
}

function onSignIn(googleUser) {

    var profile = googleUser.getBasicProfile();
    var getname = profile.getName();
    var getemail = profile.getEmail();
    //	sessionStorage.clear();
    send(getname, getemail);
}

function signOut() {
    var auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(function() {
        console.log('User signed out.');
        sessionStorage.clear();
        $.ajax({
            url: "logout.php",
            type: 'post',
            data: {

            },
            success: function(response) {
                window.location.reload();
            }
        });
    });
    $.ajax({
        url: "logout.php",
        type: 'post',
        data: {

        },
        success: function(response) {
            window.location.reload();
        }
    });
}
$(document).ready(function() {
    $(".forgot").click(function() {

        document.getElementById("forgot-password").style.display = "block";
        document.getElementById("disable-div-1").style.display = "block";
    });
});

var otp = Math.floor(Math.random() * 90000) + 10000;

$(document).ready(function() {
    $("#otp-send").click(function() {

        var $myForm = $('#register');
        var number = $('#input-Number').val();
        if (!$myForm[0].checkValidity()) {
            // If the form is invalid, submit it. The form won't actually submit;
            // this will just cause the browser to display the native HTML5 error messages.
            $myForm.find(':submit').click();
        } else {
            var settings = {
                "async": true,
                "crossDomain": true,
                "url": "https://cors-anywhere.herokuapp.com/https://www.fast2sms.com/dev/bulk",
                "method": "POST",
                "headers": {
                    "authorization": "R6v2n8N0pPmwlG7LohtK1egOWsIH9x3BTrkduCZ4UDEjFcJaAVZwTCNpk04AQL6HRVXuUvi2Yxa5jlKW",
                    "cache-control": "no-cache",
                    "content-type": "application/x-www-form-urlencoded"
                },
                "data": {
                    "sender_id": "FSTSMS",
                    "language": "english",
                    "route": "qt",
                    "numbers": number,
                    "message": "26731",
                    "variables": "{#AA#}",
                    "variables_values": otp
                }
            };
            $.ajax(settings).done(function(response) {
                console.log(response);
            });
            document.getElementById("confirm-otp").style.display = "block";
            document.getElementById("disable-div-1").style.display = "block";
            event.preventDefault();
        }

    });
});

$(document).ready(function() {
    $("#verify-otp").click(function() {
        event.preventDefault();
        if ($('#otp').val() == otp) {
            document.getElementById("register").submit();
        } else {
            alert("Otp not verified.");
        }

    });
});

//$(document).ready(function(){
//$("#forgot-link").click(function(){
//	var email=$("#forgot-email").text();
//	$.ajax({
//			url: "resetpassword.php",
//			type: 'post',
//			data:{
//				email:email
//			},
//			success: function(response){
//			alert("Email sent!");
//			}
//		});
//	
//});
//});