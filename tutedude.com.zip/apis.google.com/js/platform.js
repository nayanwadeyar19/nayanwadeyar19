var gapi = window.gapi = window.gapi || {};
gapi._bs = new Date().getTime();
(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var n, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        ha = function(a, b) {
            if (b) a: {
                var c = da;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    ha("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.ca = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.ca
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    ha("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ia(aa(this))
                }
            })
        }
        return a
    });
    var ia = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        ja = function(a, b) {
            a instanceof String && (a += "");
            var c = 0,
                d = !1,
                e = {
                    next: function() {
                        if (!d && c < a.length) {
                            var f = c++;
                            return {
                                value: b(f, a[f]),
                                done: !1
                            }
                        }
                        d = !0;
                        return {
                            done: !0,
                            value: void 0
                        }
                    }
                };
            e[Symbol.iterator] = function() {
                return e
            };
            return e
        };
    ha("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ja(this, function(b) {
                return b
            })
        }
    });
    var q = this || self,
        ka = function(a) {
            var b = typeof a;
            return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        la = function(a) {
            var b = ka(a);
            return "array" == b || "object" == b && "number" == typeof a.length
        },
        ma = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" == b
        },
        na = "closure_uid_" + (1E9 * Math.random() >>> 0),
        oa = 0,
        pa = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        qa = function(a, b, c) {
            if (!a) throw Error();
            if (2 < arguments.length) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        ra = function(a, b, c) {
            ra = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? pa : qa;
            return ra.apply(null, arguments)
        },
        sa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.pa = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.B = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d,
                    g)
            }
        },
        ta = function(a) {
            return a
        },
        ua = function(a) {
            var b = null,
                c = q.trustedTypes;
            if (!c || !c.createPolicy) return b;
            try {
                b = c.createPolicy(a, {
                    createHTML: ta,
                    createScript: ta,
                    createScriptURL: ta
                })
            } catch (d) {
                q.console && q.console.error(d.message)
            }
            return b
        };

    function r(a) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, r);
        else {
            var b = Error().stack;
            b && (this.stack = b)
        }
        a && (this.message = String(a))
    }
    sa(r, Error);
    r.prototype.name = "CustomError";
    var va;
    var wa = function(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        r.call(this, c + a[d])
    };
    sa(wa, r);
    wa.prototype.name = "AssertionError";
    var xa = function(a, b, c, d) {
            var e = "Assertion failed";
            if (c) {
                e += ": " + c;
                var f = d
            } else a && (e += ": " + a, f = b);
            throw new wa("" + e, f || []);
        },
        ya = function(a, b, c) {
            a || xa("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        za = function(a, b) {
            throw new wa("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        Aa = function(a, b, c) {
            "string" !== typeof a && xa("Expected string but got %s: %s.", [ka(a), a], b, Array.prototype.slice.call(arguments, 2))
        };
    var Ba = Array.prototype.forEach ? function(a, b) {
        ya(null != a.length);
        Array.prototype.forEach.call(a, b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    };

    function Da(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Ea(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    var Fa;
    var w = function(a, b) {
        this.S = a === Ga && b || "";
        this.da = Ha
    };
    w.prototype.F = !0;
    w.prototype.D = function() {
        return this.S
    };
    w.prototype.toString = function() {
        return "Const{" + this.S + "}"
    };
    var Ia = function(a) {
            if (a instanceof w && a.constructor === w && a.da === Ha) return a.S;
            za("expected object of type Const, got '" + a + "'");
            return "type_error:Const"
        },
        Ha = {},
        Ga = {};
    var x = function(a, b) {
        this.P = b === Ja ? a : ""
    };
    x.prototype.F = !0;
    x.prototype.D = function() {
        return this.P.toString()
    };
    x.prototype.toString = function() {
        return this.P.toString()
    };
    var Ka = function(a) {
            if (a instanceof x && a.constructor === x) return a.P;
            za("expected object of type SafeUrl, got '" + a + "' of type " + ka(a));
            return "type_error:SafeUrl"
        },
        La = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
        Ma = function(a) {
            if (a instanceof x) return a;
            a = "object" == typeof a && a.F ? a.D() : String(a);
            ya(La.test(a), "%s does not match the safe URL pattern", a) || (a = "about:invalid#zClosurez");
            return new x(a, Ja)
        },
        Ja = {};
    var Na = {},
        z = function(a, b, c) {
            this.O = c === Na ? a : "";
            this.F = !0
        };
    z.prototype.D = function() {
        return this.O.toString()
    };
    z.prototype.toString = function() {
        return this.O.toString()
    };
    var Oa = function(a) {
            if (a instanceof z && a.constructor === z) return a.O;
            za("expected object of type SafeHtml, got '" + a + "' of type " + ka(a));
            return "type_error:SafeHtml"
        },
        Pa = new z(q.trustedTypes && q.trustedTypes.emptyHTML || "", 0, Na);
    var Qa = function(a, b) {
        a: {
            try {
                var c = a && a.ownerDocument,
                    d = c && (c.defaultView || c.parentWindow);
                d = d || q;
                if (d.Element && d.Location) {
                    var e = d;
                    break a
                }
            } catch (g) {}
            e = null
        }
        if (e && "undefined" != typeof e[b] && (!a || !(a instanceof e[b]) && (a instanceof e.Location || a instanceof e.Element))) {
            if (ma(a)) try {
                var f = a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a)
            } catch (g) {
                f = "<object could not be stringified>"
            } else f = void 0 === a ? "undefined" : null === a ? "null" : typeof a;
            za("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
                b, f)
        }
        return a
    };
    var Ra = {
            MATH: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        },
        Sa = function(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        }(function() {
            if ("undefined" === typeof document) return !1;
            var a = document.createElement("div"),
                b = document.createElement("div");
            b.appendChild(document.createElement("div"));
            a.appendChild(b);
            if (!a.firstChild) return !1;
            b = a.firstChild.firstChild;
            a.innerHTML = Oa(Pa);
            return !b.parentElement
        });
    var Ua = function(a, b) {
            Ea(b, function(c, d) {
                c && "object" == typeof c && c.F && (c = c.D());
                "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : Ta.hasOwnProperty(d) ? a.setAttribute(Ta[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
            })
        },
        Ta = {
            cellpadding: "cellPadding",
            cellspacing: "cellSpacing",
            colspan: "colSpan",
            frameborder: "frameBorder",
            height: "height",
            maxlength: "maxLength",
            nonce: "nonce",
            role: "role",
            rowspan: "rowSpan",
            type: "type",
            usemap: "useMap",
            valign: "vAlign",
            width: "width"
        },
        Va = function(a, b, c, d) {
            function e(h) {
                h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
            }
            for (; d < c.length; d++) {
                var f = c[d];
                if (!la(f) || ma(f) && 0 < f.nodeType) e(f);
                else {
                    a: {
                        if (f && "number" == typeof f.length) {
                            if (ma(f)) {
                                var g = "function" == typeof f.item || "string" == typeof f.item;
                                break a
                            }
                            if ("function" === typeof f) {
                                g = "function" == typeof f.item;
                                break a
                            }
                        }
                        g = !1
                    }
                    Ba(g ? Da(f) : f, e)
                }
            }
        },
        Wa = function(a, b) {
            b = String(b);
            "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
            return a.createElement(b)
        },
        Xa =
        function(a) {
            ya(a, "Node cannot be null or undefined.");
            return 9 == a.nodeType ? a : a.ownerDocument || a.document
        },
        Ya = function(a) {
            this.C = a || q.document || document
        };
    n = Ya.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.C).getElementsByTagName(String(a))
    };
    n.ga = function(a, b, c) {
        var d = this.C,
            e = arguments,
            f = e[1],
            g = Wa(d, String(e[0]));
        f && ("string" === typeof f ? g.className = f : Array.isArray(f) ? g.className = f.join(" ") : Ua(g, f));
        2 < e.length && Va(d, g, e, 2);
        return g
    };
    n.createElement = function(a) {
        return Wa(this.C, a)
    };
    n.createTextNode = function(a) {
        return this.C.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        ya(null != a && null != b, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        Va(Xa(a), a, arguments, 1)
    };
    n.canHaveChildren = function(a) {
        if (1 != a.nodeType) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    /*
     gapi.loader.OBJECT_CREATE_TEST_OVERRIDE &&*/
    var A = window,
        B = document,
        Za = A.location,
        ab = function() {},
        bb = /\[native code\]/,
        C = function(a, b, c) {
            return a[b] = a[b] || c
        },
        cb = function(a) {
            for (var b = 0; b < this.length; b++)
                if (this[b] === a) return b;
            return -1
        },
        db = function(a) {
            a = a.sort();
            for (var b = [], c = void 0, d = 0; d < a.length; d++) {
                var e = a[d];
                e != c && b.push(e);
                c = e
            }
            return b
        },
        eb = /&/g,
        fb = /</g,
        gb = />/g,
        hb = /"/g,
        ib = /'/g,
        jb = function(a) {
            return String(a).replace(eb, "&amp;").replace(fb, "&lt;").replace(gb, "&gt;").replace(hb, "&quot;").replace(ib, "&#39;")
        },
        D = function() {
            var a;
            if ((a = Object.create) &&
                bb.test(a)) a = a(null);
            else {
                a = {};
                for (var b in a) a[b] = void 0
            }
            return a
        },
        E = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        kb = function(a) {
            if (bb.test(Object.keys)) return Object.keys(a);
            var b = [],
                c;
            for (c in a) E(a, c) && b.push(c);
            return b
        },
        F = function(a, b) {
            a = a || {};
            for (var c in a) E(a, c) && (b[c] = a[c])
        },
        lb = function(a) {
            return function() {
                A.setTimeout(a, 0)
            }
        },
        G = function(a, b) {
            if (!a) throw Error(b || "");
        },
        H = C(A, "gapi", {});
    var J = function(a, b, c) {
            var d = new RegExp("([#].*&|[#])" + b + "=([^&#]*)", "g");
            b = new RegExp("([?#].*&|[?#])" + b + "=([^&#]*)", "g");
            if (a = a && (d.exec(a) || b.exec(a))) try {
                c = decodeURIComponent(a[2])
            } catch (e) {}
            return c
        },
        mb = new RegExp(/^/.source + /([a-zA-Z][-+.a-zA-Z0-9]*:)?/.source + /(\/\/[^\/?#]*)?/.source + /([^?#]*)?/.source + /(\?([^#]*))?/.source + /(#((#|[^#])*))?/.source + /$/.source),
        nb = /[\ud800-\udbff][\udc00-\udfff]|[^!-~]/g,
        ob = new RegExp(/(%([^0-9a-fA-F%]|[0-9a-fA-F]([^0-9a-fA-F%])?)?)*/.source + /%($|[^0-9a-fA-F]|[0-9a-fA-F]($|[^0-9a-fA-F]))/.source,
            "g"),
        pb = /%([a-f]|[0-9a-fA-F][a-f])/g,
        qb = /^(https?|ftp|file|chrome-extension):$/i,
        rb = function(a) {
            a = String(a);
            a = a.replace(nb, function(e) {
                try {
                    return encodeURIComponent(e)
                } catch (f) {
                    return encodeURIComponent(e.replace(/^[^%]+$/g, "\ufffd"))
                }
            }).replace(ob, function(e) {
                return e.replace(/%/g, "%25")
            }).replace(pb, function(e) {
                return e.toUpperCase()
            });
            a = a.match(mb) || [];
            var b = D(),
                c = function(e) {
                    return e.replace(/\\/g, "%5C").replace(/\^/g, "%5E").replace(/`/g, "%60").replace(/\{/g, "%7B").replace(/\|/g, "%7C").replace(/\}/g,
                        "%7D")
                },
                d = !!(a[1] || "").match(qb);
            b.B = c((a[1] || "") + (a[2] || "") + (a[3] || (a[2] && d ? "/" : "")));
            d = function(e) {
                return c(e.replace(/\?/g, "%3F").replace(/#/g, "%23"))
            };
            b.query = a[5] ? [d(a[5])] : [];
            b.j = a[7] ? [d(a[7])] : [];
            return b
        },
        sb = function(a) {
            return a.B + (0 < a.query.length ? "?" + a.query.join("&") : "") + (0 < a.j.length ? "#" + a.j.join("&") : "")
        },
        tb = function(a, b) {
            var c = [];
            if (a)
                for (var d in a)
                    if (E(a, d) && null != a[d]) {
                        var e = b ? b(a[d]) : a[d];
                        c.push(encodeURIComponent(d) + "=" + encodeURIComponent(e))
                    }
            return c
        },
        ub = function(a, b, c, d) {
            a = rb(a);
            a.query.push.apply(a.query, tb(b, d));
            a.j.push.apply(a.j, tb(c, d));
            return sb(a)
        },
        vb = new RegExp(/\/?\??#?/.source + "(" + /[\/?#]/i.source + "|" + /[\uD800-\uDBFF]/i.source + "|" + /%[c-f][0-9a-f](%[89ab][0-9a-f]){0,2}(%[89ab]?)?/i.source + "|" + /%[0-9a-f]?/i.source + ")$", "i"),
        wb = function(a, b) {
            var c = rb(b);
            b = c.B;
            c.query.length && (b += "?" + c.query.join(""));
            c.j.length && (b += "#" + c.j.join(""));
            var d = "";
            2E3 < b.length && (d = b, b = b.substr(0, 2E3), b = b.replace(vb, ""), d = d.substr(b.length));
            var e = a.createElement("div");
            a = a.createElement("a");
            c = rb(b);
            b = c.B;
            c.query.length && (b += "?" + c.query.join(""));
            c.j.length && (b += "#" + c.j.join(""));
            b = new x(b, Ja);
            Qa(a, "HTMLAnchorElement");
            b = b instanceof x ? b : Ma(b);
            a.href = Ka(b);
            e.appendChild(a);
            b = e.innerHTML;
            c = new w(Ga, "Assignment to self.");
            Aa(Ia(c), "must provide justification");
            ya(!/^[\s\xa0]*$/.test(Ia(c)), "must provide non-empty justification");
            void 0 === Fa && (Fa = ua("gapi#html"));
            b = (c = Fa) ? c.createHTML(b) : b;
            b = new z(b, null, Na);
            if (e.tagName && Ra[e.tagName.toUpperCase()]) throw Error("goog.dom.safe.setInnerHtml cannot be used to set content of " +
                e.tagName + ".");
            if (Sa())
                for (; e.lastChild;) e.removeChild(e.lastChild);
            e.innerHTML = Oa(b);
            b = String(e.firstChild.href);
            e.parentNode && e.parentNode.removeChild(e);
            c = rb(b + d);
            d = c.B;
            c.query.length && (d += "?" + c.query.join(""));
            c.j.length && (d += "#" + c.j.join(""));
            return d
        },
        xb = /^https?:\/\/[^\/%\\?#\s]+\/[^\s]*$/i;
    var yb;
    var zb = function(a, b, c, d) {
            if (A[c + "EventListener"]) A[c + "EventListener"](a, b, !1);
            else if (A[d + "tachEvent"]) A[d + "tachEvent"]("on" + a, b)
        },
        Ab = function() {
            var a = B.readyState;
            return "complete" === a || "interactive" === a && -1 == navigator.userAgent.indexOf("MSIE")
        },
        Db = function(a) {
            var b = Bb;
            if (!Ab()) try {
                b()
            } catch (c) {}
            Cb(a)
        },
        Cb = function(a) {
            if (Ab()) a();
            else {
                var b = !1,
                    c = function() {
                        if (!b) return b = !0, a.apply(this, arguments)
                    };
                A.addEventListener ? (A.addEventListener("load", c, !1), A.addEventListener("DOMContentLoaded", c, !1)) : A.attachEvent &&
                    (A.attachEvent("onreadystatechange", function() {
                        Ab() && c.apply(this, arguments)
                    }), A.attachEvent("onload", c))
            }
        },
        Eb = function(a) {
            for (; a.firstChild;) a.removeChild(a.firstChild)
        },
        Fb = {
            button: !0,
            div: !0,
            span: !0
        };
    var L;
    L = C(A, "___jsl", D());
    C(L, "I", 0);
    C(L, "hel", 10);
    var Gb = function(a) {
            return L.dpo ? L.h : J(a, "jsh", L.h)
        },
        Hb = function(a) {
            var b = C(L, "sws", []);
            b.push.apply(b, a)
        },
        Ib = function(a) {
            return C(L, "watt", D())[a]
        },
        Jb = function(a) {
            var b = C(L, "PQ", []);
            L.PQ = [];
            var c = b.length;
            if (0 === c) a();
            else
                for (var d = 0, e = function() {
                        ++d === c && a()
                    }, f = 0; f < c; f++) b[f](e)
        },
        Kb = function(a) {
            return C(C(L, "H", D()), a, D())
        };
    var Lb = C(L, "perf", D()),
        Mb = C(Lb, "g", D()),
        Nb = C(Lb, "i", D());
    C(Lb, "r", []);
    D();
    D();
    var Ob = function(a, b, c) {
            var d = Lb.r;
            "function" === typeof d ? d(a, b, c) : d.push([a, b, c])
        },
        M = function(a, b, c) {
            Mb[a] = !b && Mb[a] || c || (new Date).getTime();
            Ob(a)
        },
        Qb = function(a, b, c) {
            b && 0 < b.length && (b = Pb(b), c && 0 < c.length && (b += "___" + Pb(c)), 28 < b.length && (b = b.substr(0, 28) + (b.length - 28)), c = b, b = C(Nb, "_p", D()), C(b, c, D())[a] = (new Date).getTime(), Ob(a, "_p", c))
        },
        Pb = function(a) {
            return a.join("__").replace(/\./g, "_").replace(/\-/g, "_").replace(/,/g, "_")
        };
    var Rb = D(),
        Sb = [],
        N = function(a) {
            throw Error("Bad hint" + (a ? ": " + a : ""));
        };
    Sb.push(["jsl", function(a) {
        for (var b in a)
            if (E(a, b)) {
                var c = a[b];
                "object" == typeof c ? L[b] = C(L, b, []).concat(c) : C(L, b, c)
            }
        if (b = a.u) a = C(L, "us", []), a.push(b), (b = /^https:(.*)$/.exec(b)) && a.push("http:" + b[1])
    }]);
    var Tb = /^(\/[a-zA-Z0-9_\-]+)+$/,
        Ub = [/\/amp\//, /\/amp$/, /^\/amp$/],
        Vb = /^[a-zA-Z0-9\-_\.,!]+$/,
        Wb = /^gapi\.loaded_[0-9]+$/,
        Xb = /^[a-zA-Z0-9,._-]+$/,
        ac = function(a, b, c, d, e) {
            var f = a.split(";"),
                g = f.shift(),
                h = Rb[g],
                k = null;
            h ? k = h(f, b, c, d) : N("no hint processor for: " + g);
            k || N("failed to generate load url");
            b = k;
            c = b.match(Yb);
            (d = b.match(Zb)) && 1 === d.length && $b.test(b) && c && 1 === c.length || N("failed sanity: " + a);
            try {
                if (e && 0 < e.length) {
                    b = a = 0;
                    for (c = {}; b < e.length;) {
                        var l = e[b++];
                        d = void 0;
                        d = ma(l) ? "o" + (Object.prototype.hasOwnProperty.call(l,
                            na) && l[na] || (l[na] = ++oa)) : (typeof l).charAt(0) + l;
                        Object.prototype.hasOwnProperty.call(c, d) || (c[d] = !0, e[a++] = l)
                    }
                    e.length = a;
                    k = k + "?le=" + e.join(",")
                }
            } catch (m) {}
            return k
        },
        dc = function(a, b, c, d) {
            a = bc(a);
            Wb.test(c) || N("invalid_callback");
            b = cc(b);
            d = d && d.length ? cc(d) : null;
            var e = function(f) {
                return encodeURIComponent(f).replace(/%2C/g, ",")
            };
            return [encodeURIComponent(a.pathPrefix).replace(/%2C/g, ",").replace(/%2F/g, "/"), "/k=", e(a.version), "/m=", e(b), d ? "/exm=" + e(d) : "", "/rt=j/sv=1/d=1/ed=1", a.U ? "/am=" + e(a.U) : "",
                a.$ ? "/rs=" + e(a.$) : "", a.ba ? "/t=" + e(a.ba) : "", "/cb=", e(c)
            ].join("")
        },
        bc = function(a) {
            "/" !== a.charAt(0) && N("relative path");
            for (var b = a.substring(1).split("/"), c = []; b.length;) {
                a = b.shift();
                if (!a.length || 0 == a.indexOf(".")) N("empty/relative directory");
                else if (0 < a.indexOf("=")) {
                    b.unshift(a);
                    break
                }
                c.push(a)
            }
            a = {};
            for (var d = 0, e = b.length; d < e; ++d) {
                var f = b[d].split("="),
                    g = decodeURIComponent(f[0]),
                    h = decodeURIComponent(f[1]);
                2 == f.length && g && h && (a[g] = a[g] || h)
            }
            b = "/" + c.join("/");
            Tb.test(b) || N("invalid_prefix");
            c = 0;
            for (d = Ub.length; c < d; ++c) Ub[c].test(b) && N("invalid_prefix");
            c = ec(a, "k", !0);
            d = ec(a, "am");
            e = ec(a, "rs");
            a = ec(a, "t");
            return {
                pathPrefix: b,
                version: c,
                U: d,
                $: e,
                ba: a
            }
        },
        cc = function(a) {
            for (var b = [], c = 0, d = a.length; c < d; ++c) {
                var e = a[c].replace(/\./g, "_").replace(/-/g, "_");
                Xb.test(e) && b.push(e)
            }
            return b.join(",")
        },
        ec = function(a, b, c) {
            a = a[b];
            !a && c && N("missing: " + b);
            if (a) {
                if (Vb.test(a)) return a;
                N("invalid: " + b)
            }
            return null
        },
        $b = /^https?:\/\/[a-z0-9_.-]+\.google(rs)?\.com(:\d+)?\/[a-zA-Z0-9_.,!=\-\/]+$/,
        Zb = /\/cb=/g,
        Yb =
        /\/\//g,
        fc = function() {
            var a = Gb(Za.href);
            if (!a) throw Error("Bad hint");
            return a
        };
    Rb.m = function(a, b, c, d) {
        (a = a[0]) || N("missing_hint");
        return "https://apis.google.com" + dc(a, b, c, d)
    };
    var gc = decodeURI("%73cript"),
        hc = /^[-+_0-9\/A-Za-z]+={0,2}$/,
        ic = function(a, b) {
            for (var c = [], d = 0; d < a.length; ++d) {
                var e = a[d];
                e && 0 > cb.call(b, e) && c.push(e)
            }
            return c
        },
        jc = function() {
            var a = L.nonce;
            return void 0 !== a ? a && a === String(a) && a.match(hc) ? a : L.nonce = null : B.querySelector ? (a = B.querySelector("script[nonce]")) ? (a = a.nonce || a.getAttribute("nonce") || "", a && a === String(a) && a.match(hc) ? L.nonce = a : L.nonce = null) : null : null
        },
        mc = function(a) {
            if ("loading" != B.readyState) kc(a);
            else {
                var b = jc(),
                    c = "";
                null !== b && (c = ' nonce="' +
                    b + '"');
                a = "<" + gc + ' src="' + encodeURI(a) + '"' + c + "></" + gc + ">";
                B.write(lc ? lc.createHTML(a) : a)
            }
        },
        kc = function(a) {
            var b = B.createElement(gc);
            b.setAttribute("src", lc ? lc.createScriptURL(a) : a);
            a = jc();
            null !== a && b.setAttribute("nonce", a);
            b.async = "true";
            (a = B.getElementsByTagName(gc)[0]) ? a.parentNode.insertBefore(b, a): (B.head || B.body || B.documentElement).appendChild(b)
        },
        nc = function(a, b) {
            var c = b && b._c;
            if (c)
                for (var d = 0; d < Sb.length; d++) {
                    var e = Sb[d][0],
                        f = Sb[d][1];
                    f && E(c, e) && f(c[e], a, b)
                }
        },
        pc = function(a, b, c) {
            oc(function() {
                var d =
                    b === Gb(Za.href) ? C(H, "_", D()) : D();
                d = C(Kb(b), "_", d);
                a(d)
            }, c)
        },
        rc = function(a, b) {
            var c = b || {};
            "function" == typeof b && (c = {}, c.callback = b);
            nc(a, c);
            b = [];
            a ? b = a.split(":") : c.features && (b = c.features);
            var d = c.h || fc(),
                e = C(L, "ah", D());
            if (e["::"] && b.length) {
                a = [];
                for (var f = null; f = b.shift();) {
                    var g = f.split(".");
                    g = e[f] || e[g[1] && "ns:" + g[0] || ""] || d;
                    var h = a.length && a[a.length - 1] || null,
                        k = h;
                    h && h.hint == g || (k = {
                        hint: g,
                        features: []
                    }, a.push(k));
                    k.features.push(f)
                }
                var l = a.length;
                if (1 < l) {
                    var m = c.callback;
                    m && (c.callback = function() {
                        0 ==
                            --l && m()
                    })
                }
                for (; b = a.shift();) qc(b.features, c, b.hint)
            } else qc(b || [], c, d)
        },
        qc = function(a, b, c) {
            a = db(a) || [];
            var d = b.callback,
                e = b.config,
                f = b.timeout,
                g = b.ontimeout,
                h = b.onerror,
                k = void 0;
            "function" == typeof h && (k = h);
            var l = null,
                m = !1;
            if (f && !g || !f && g) throw "Timeout requires both the timeout parameter and ontimeout parameter to be set";
            h = C(Kb(c), "r", []).sort();
            var t = C(Kb(c), "L", []).sort(),
                u = L.le,
                p = [].concat(h),
                I = function(O, ea) {
                    if (m) return 0;
                    A.clearTimeout(l);
                    t.push.apply(t, y);
                    var fa = ((H || {}).config || {}).update;
                    fa ? fa(e) : e && C(L, "cu", []).push(e);
                    if (ea) {
                        Qb("me0", O, p);
                        try {
                            pc(ea, c, k)
                        } finally {
                            Qb("me1", O, p)
                        }
                    }
                    return 1
                };
            0 < f && (l = A.setTimeout(function() {
                m = !0;
                g()
            }, f));
            var y = ic(a, t);
            if (y.length) {
                y = ic(a, h);
                var v = C(L, "CP", []),
                    K = v.length;
                v[K] = function(O) {
                    if (!O) return 0;
                    Qb("ml1", y, p);
                    var ea = function(Ca) {
                            v[K] = null;
                            I(y, O) && Jb(function() {
                                d && d();
                                Ca()
                            })
                        },
                        fa = function() {
                            var Ca = v[K + 1];
                            Ca && Ca()
                        };
                    0 < K && v[K - 1] ? v[K] = function() {
                        ea(fa)
                    } : ea(fa)
                };
                if (y.length) {
                    var $a = "loaded_" + L.I++;
                    H[$a] = function(O) {
                        v[K](O);
                        H[$a] = null
                    };
                    a = ac(c, y, "gapi." +
                        $a, h, u);
                    h.push.apply(h, y);
                    Qb("ml0", y, p);
                    b.sync || A.___gapisync ? mc(a) : kc(a)
                } else v[K](ab)
            } else I(y) && d && d()
        },
        lc = ua("gapi#gapi");
    var oc = function(a, b) {
        if (L.hee && 0 < L.hel) try {
            return a()
        } catch (c) {
            b && b(c), L.hel--, rc("debug_error", function() {
                try {
                    window.___jsl.hefn(c)
                } catch (d) {
                    throw c;
                }
            })
        } else try {
            return a()
        } catch (c) {
            throw b && b(c), c;
        }
    };
    H.load = function(a, b) {
        return oc(function() {
            return rc(a, b)
        })
    };
    var sc = function(a) {
            var b = window.___jsl = window.___jsl || {};
            b[a] = b[a] || [];
            return b[a]
        },
        tc = function(a) {
            var b = window.___jsl = window.___jsl || {};
            b.cfg = !a && b.cfg || {};
            return b.cfg
        },
        uc = function(a) {
            return "object" === typeof a && /\[native code\]/.test(a.push)
        },
        P = function(a, b, c) {
            if (b && "object" === typeof b)
                for (var d in b) !Object.prototype.hasOwnProperty.call(b, d) || c && "___goc" === d && "undefined" === typeof b[d] || (a[d] && b[d] && "object" === typeof a[d] && "object" === typeof b[d] && !uc(a[d]) && !uc(b[d]) ? P(a[d], b[d]) : b[d] && "object" ===
                    typeof b[d] ? (a[d] = uc(b[d]) ? [] : {}, P(a[d], b[d])) : a[d] = b[d])
        },
        vc = function(a) {
            if (a && !/^\s+$/.test(a)) {
                for (; 0 == a.charCodeAt(a.length - 1);) a = a.substring(0, a.length - 1);
                try {
                    var b = window.JSON.parse(a)
                } catch (c) {}
                if ("object" === typeof b) return b;
                try {
                    b = (new Function("return (" + a + "\n)"))()
                } catch (c) {}
                if ("object" === typeof b) return b;
                try {
                    b = (new Function("return ({" + a + "\n})"))()
                } catch (c) {}
                return "object" === typeof b ? b : {}
            }
        },
        wc = function(a, b) {
            var c = {
                ___goc: void 0
            };
            a.length && a[a.length - 1] && Object.hasOwnProperty.call(a[a.length -
                1], "___goc") && "undefined" === typeof a[a.length - 1].___goc && (c = a.pop());
            P(c, b);
            a.push(c)
        },
        xc = function(a) {
            tc(!0);
            var b = window.___gcfg,
                c = sc("cu"),
                d = window.___gu;
            b && b !== d && (wc(c, b), window.___gu = b);
            b = sc("cu");
            var e = document.scripts || document.getElementsByTagName("script") || [];
            d = [];
            var f = [];
            f.push.apply(f, sc("us"));
            for (var g = 0; g < e.length; ++g)
                for (var h = e[g], k = 0; k < f.length; ++k) h.src && 0 == h.src.indexOf(f[k]) && d.push(h);
            0 == d.length && 0 < e.length && e[e.length - 1].src && d.push(e[e.length - 1]);
            for (e = 0; e < d.length; ++e) d[e].getAttribute("gapi_processed") ||
                (d[e].setAttribute("gapi_processed", !0), (f = d[e]) ? (g = f.nodeType, f = 3 == g || 4 == g ? f.nodeValue : f.textContent || "") : f = void 0, (f = vc(f)) && b.push(f));
            a && wc(c, a);
            d = sc("cd");
            a = 0;
            for (b = d.length; a < b; ++a) P(tc(), d[a], !0);
            d = sc("ci");
            a = 0;
            for (b = d.length; a < b; ++a) P(tc(), d[a], !0);
            a = 0;
            for (b = c.length; a < b; ++a) P(tc(), c[a], !0)
        },
        Q = function(a) {
            var b = tc();
            if (!a) return b;
            a = a.split("/");
            for (var c = 0, d = a.length; b && "object" === typeof b && c < d; ++c) b = b[a[c]];
            return c === a.length && void 0 !== b ? b : void 0
        },
        yc = function(a, b) {
            var c;
            if ("string" === typeof a) {
                var d =
                    c = {};
                a = a.split("/");
                for (var e = 0, f = a.length; e < f - 1; ++e) {
                    var g = {};
                    d = d[a[e]] = g
                }
                d[a[e]] = b
            } else c = a;
            xc(c)
        };
    var zc = function() {
        var a = window.__GOOGLEAPIS;
        a && (a.googleapis && !a["googleapis.config"] && (a["googleapis.config"] = a.googleapis), C(L, "ci", []).push(a), window.__GOOGLEAPIS = void 0)
    };
    var Ac = {
            callback: 1,
            clientid: 1,
            cookiepolicy: 1,
            openidrealm: -1,
            includegrantedscopes: -1,
            requestvisibleactions: 1,
            scope: 1
        },
        Bc = !1,
        Cc = D(),
        Dc = function() {
            if (!Bc) {
                for (var a = document.getElementsByTagName("meta"), b = 0; b < a.length; ++b) {
                    var c = a[b].name.toLowerCase();
                    if (0 == c.lastIndexOf("google-signin-", 0)) {
                        c = c.substring(14);
                        var d = a[b].content;
                        Ac[c] && d && (Cc[c] = d)
                    }
                }
                if (window.self !== window.top) {
                    a = document.location.toString();
                    for (var e in Ac) 0 < Ac[e] && (b = J(a, e, "")) && (Cc[e] = b)
                }
                Bc = !0
            }
            e = D();
            F(Cc, e);
            return e
        },
        Ec = function(a) {
            return !!(a.clientid &&
                a.scope && a.callback)
        };
    var Fc = function() {
        this.i = window.console
    };
    Fc.prototype.log = function(a) {
        this.i && this.i.log && this.i.log(a)
    };
    Fc.prototype.error = function(a) {
        this.i && (this.i.error ? this.i.error(a) : this.i.log && this.i.log(a))
    };
    Fc.prototype.warn = function(a) {
        this.i && (this.i.warn ? this.i.warn(a) : this.i.log && this.i.log(a))
    };
    Fc.prototype.debug = function() {};
    var Gc = new Fc;
    var Hc = function() {
            return !!L.oa
        },
        Ic = function() {};
    var R = C(L, "rw", D()),
        Jc = function(a) {
            for (var b in R) a(R[b])
        },
        Kc = function(a, b) {
            (a = R[a]) && a.state < b && (a.state = b)
        };
    var S = function(a) {
        var b = window.___jsl = window.___jsl || {};
        b.cfg = b.cfg || {};
        b = b.cfg;
        if (!a) return b;
        a = a.split("/");
        for (var c = 0, d = a.length; b && "object" === typeof b && c < d; ++c) b = b[a[c]];
        return c === a.length && void 0 !== b ? b : void 0
    };
    var Lc = /^https?:\/\/(?:\w|[\-\.])+\.google\.(?:\w|[\-:\.])+(?:\/[^\?#]*)?\/u\/(\d)\//,
        Mc = /^https?:\/\/(?:\w|[\-\.])+\.google\.(?:\w|[\-:\.])+(?:\/[^\?#]*)?\/b\/(\d{10,21})\//,
        Nc = function(a) {
            var b = S("googleapis.config/sessionIndex");
            "string" === typeof b && 254 < b.length && (b = null);
            null == b && (b = window.__X_GOOG_AUTHUSER);
            "string" === typeof b && 254 < b.length && (b = null);
            if (null == b) {
                var c = window.google;
                c && (b = c.authuser)
            }
            "string" === typeof b && 254 < b.length && (b = null);
            null == b && (a = a || window.location.href, b = J(a, "authuser") ||
                null, null == b && (b = (b = a.match(Lc)) ? b[1] : null));
            if (null == b) return null;
            b = String(b);
            254 < b.length && (b = null);
            return b
        },
        Oc = function(a) {
            var b = S("googleapis.config/sessionDelegate");
            "string" === typeof b && 21 < b.length && (b = null);
            null == b && (b = (a = (a || window.location.href).match(Mc)) ? a[1] : null);
            if (null == b) return null;
            b = String(b);
            21 < b.length && (b = null);
            return b
        };
    var Pc, T, U = void 0,
        V = function(a) {
            try {
                return q.JSON.parse.call(q.JSON, a)
            } catch (b) {
                return !1
            }
        },
        W = function(a) {
            return Object.prototype.toString.call(a)
        },
        Qc = W(0),
        Rc = W(new Date(0)),
        Sc = W(!0),
        Tc = W(""),
        Uc = W({}),
        Vc = W([]),
        X = function(a, b) {
            if (b)
                for (var c = 0, d = b.length; c < d; ++c)
                    if (a === b[c]) throw new TypeError("Converting circular structure to JSON");
            d = typeof a;
            if ("undefined" !== d) {
                c = Array.prototype.slice.call(b || [], 0);
                c[c.length] = a;
                b = [];
                var e = W(a);
                if (null != a && "function" === typeof a.toJSON && (Object.prototype.hasOwnProperty.call(a,
                        "toJSON") || (e !== Vc || a.constructor !== Array && a.constructor !== Object) && (e !== Uc || a.constructor !== Array && a.constructor !== Object) && e !== Tc && e !== Qc && e !== Sc && e !== Rc)) return X(a.toJSON.call(a), c);
                if (null == a) b[b.length] = "null";
                else if (e === Qc) a = Number(a), isNaN(a) || isNaN(a - a) ? a = "null" : -0 === a && 0 > 1 / a && (a = "-0"), b[b.length] = String(a);
                else if (e === Sc) b[b.length] = String(!!Number(a));
                else {
                    if (e === Rc) return X(a.toISOString.call(a), c);
                    if (e === Vc && W(a.length) === Qc) {
                        b[b.length] = "[";
                        var f = 0;
                        for (d = Number(a.length) >> 0; f < d; ++f) f &&
                            (b[b.length] = ","), b[b.length] = X(a[f], c) || "null";
                        b[b.length] = "]"
                    } else if (e == Tc && W(a.length) === Qc) {
                        b[b.length] = '"';
                        f = 0;
                        for (c = Number(a.length) >> 0; f < c; ++f) d = String.prototype.charAt.call(a, f), e = String.prototype.charCodeAt.call(a, f), b[b.length] = "\b" === d ? "\\b" : "\f" === d ? "\\f" : "\n" === d ? "\\n" : "\r" === d ? "\\r" : "\t" === d ? "\\t" : "\\" === d || '"' === d ? "\\" + d : 31 >= e ? "\\u" + (e + 65536).toString(16).substr(1) : 32 <= e && 65535 >= e ? d : "\ufffd";
                        b[b.length] = '"'
                    } else if ("object" === d) {
                        b[b.length] = "{";
                        d = 0;
                        for (f in a) Object.prototype.hasOwnProperty.call(a,
                            f) && (e = X(a[f], c), void 0 !== e && (d++ && (b[b.length] = ","), b[b.length] = X(f), b[b.length] = ":", b[b.length] = e));
                        b[b.length] = "}"
                    } else return
                }
                return b.join("")
            }
        },
        Wc = /[\0-\x07\x0b\x0e-\x1f]/,
        Xc = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*[\0-\x1f]/,
        Yc = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\[^\\\/"bfnrtu]/,
        Zc = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\u([0-9a-fA-F]{0,3}[^0-9a-fA-F])/,
        $c = /"([^\0-\x1f\\"]|\\[\\\/"bfnrt]|\\u[0-9a-fA-F]{4})*"/g,
        ad = /-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?/g,
        bd = /[ \t\n\r]+/g,
        cd = /[^"]:/,
        dd = /""/g,
        ed = /true|false|null/g,
        fd = /00/,
        gd = /[\{]([^0\}]|0[^:])/,
        hd = /(^|\[)[,:]|[,:](\]|\}|[,:]|$)/,
        id = /[^\[,:][\[\{]/,
        jd = /^(\{|\}|\[|\]|,|:|0)+/,
        kd = /\u2028/g,
        ld = /\u2029/g,
        md = function(a) {
            a = String(a);
            if (Wc.test(a) || Xc.test(a) || Yc.test(a) || Zc.test(a)) return !1;
            var b = a.replace($c, '""');
            b = b.replace(ad, "0");
            b = b.replace(bd, "");
            if (cd.test(b)) return !1;
            b = b.replace(dd, "0");
            b = b.replace(ed, "0");
            if (fd.test(b) || gd.test(b) || hd.test(b) || id.test(b) || !b || (b = b.replace(jd, ""))) return !1;
            a = a.replace(kd, "\\u2028").replace(ld,
                "\\u2029");
            b = void 0;
            try {
                b = U ? [V(a)] : eval("(function (var_args) {\n  return Array.prototype.slice.call(arguments, 0);\n})(\n" + a + "\n)")
            } catch (c) {
                return !1
            }
            return b && 1 === b.length ? b[0] : !1
        },
        nd = function() {
            var a = ((q.document || {}).scripts || []).length;
            if ((void 0 === Pc || void 0 === U || T !== a) && -1 !== T) {
                Pc = U = !1;
                T = -1;
                try {
                    try {
                        U = !!q.JSON && '{"a":[3,true,"1970-01-01T00:00:00.000Z"]}' === q.JSON.stringify.call(q.JSON, {
                            a: [3, !0, new Date(0)],
                            c: function() {}
                        }) && !0 === V("true") && 3 === V('[{"a":3}]')[0].a
                    } catch (b) {}
                    Pc = U && !V("[00]") &&
                        !V('"\u0007"') && !V('"\\0"') && !V('"\\v"')
                } finally {
                    T = a
                }
            }
        },
        od = function(a) {
            if (-1 === T) return !1;
            nd();
            return (Pc ? V : md)(a)
        },
        pd = function(a) {
            if (-1 !== T) return nd(), U ? q.JSON.stringify.call(q.JSON, a) : X(a)
        },
        qd = !Date.prototype.toISOString || "function" !== typeof Date.prototype.toISOString || "1970-01-01T00:00:00.000Z" !== (new Date(0)).toISOString(),
        rd = function() {
            var a = Date.prototype.getUTCFullYear.call(this);
            return [0 > a ? "-" + String(1E6 - a).substr(1) : 9999 >= a ? String(1E4 + a).substr(1) : "+" + String(1E6 + a).substr(1), "-", String(101 +
                Date.prototype.getUTCMonth.call(this)).substr(1), "-", String(100 + Date.prototype.getUTCDate.call(this)).substr(1), "T", String(100 + Date.prototype.getUTCHours.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCMinutes.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCSeconds.call(this)).substr(1), ".", String(1E3 + Date.prototype.getUTCMilliseconds.call(this)).substr(1), "Z"].join("")
        };
    Date.prototype.toISOString = qd ? rd : Date.prototype.toISOString;
    var sd = function() {
        this.blockSize = -1
    };
    var td = function() {
        this.blockSize = -1;
        this.blockSize = 64;
        this.g = [];
        this.L = [];
        this.ea = [];
        this.H = [];
        this.H[0] = 128;
        for (var a = 1; a < this.blockSize; ++a) this.H[a] = 0;
        this.J = this.v = 0;
        this.reset()
    };
    sa(td, sd);
    td.prototype.reset = function() {
        this.g[0] = 1732584193;
        this.g[1] = 4023233417;
        this.g[2] = 2562383102;
        this.g[3] = 271733878;
        this.g[4] = 3285377520;
        this.J = this.v = 0
    };
    var ud = function(a, b, c) {
        c || (c = 0);
        var d = a.ea;
        if ("string" === typeof b)
            for (var e = 0; 16 > e; e++) d[e] = b.charCodeAt(c) << 24 | b.charCodeAt(c + 1) << 16 | b.charCodeAt(c + 2) << 8 | b.charCodeAt(c + 3), c += 4;
        else
            for (e = 0; 16 > e; e++) d[e] = b[c] << 24 | b[c + 1] << 16 | b[c + 2] << 8 | b[c + 3], c += 4;
        for (e = 16; 80 > e; e++) {
            var f = d[e - 3] ^ d[e - 8] ^ d[e - 14] ^ d[e - 16];
            d[e] = (f << 1 | f >>> 31) & 4294967295
        }
        b = a.g[0];
        c = a.g[1];
        var g = a.g[2],
            h = a.g[3],
            k = a.g[4];
        for (e = 0; 80 > e; e++) {
            if (40 > e)
                if (20 > e) {
                    f = h ^ c & (g ^ h);
                    var l = 1518500249
                } else f = c ^ g ^ h, l = 1859775393;
            else 60 > e ? (f = c & g | h & (c | g), l = 2400959708) :
                (f = c ^ g ^ h, l = 3395469782);
            f = (b << 5 | b >>> 27) + f + k + l + d[e] & 4294967295;
            k = h;
            h = g;
            g = (c << 30 | c >>> 2) & 4294967295;
            c = b;
            b = f
        }
        a.g[0] = a.g[0] + b & 4294967295;
        a.g[1] = a.g[1] + c & 4294967295;
        a.g[2] = a.g[2] + g & 4294967295;
        a.g[3] = a.g[3] + h & 4294967295;
        a.g[4] = a.g[4] + k & 4294967295
    };
    td.prototype.update = function(a, b) {
        if (null != a) {
            void 0 === b && (b = a.length);
            for (var c = b - this.blockSize, d = 0, e = this.L, f = this.v; d < b;) {
                if (0 == f)
                    for (; d <= c;) ud(this, a, d), d += this.blockSize;
                if ("string" === typeof a)
                    for (; d < b;) {
                        if (e[f] = a.charCodeAt(d), ++f, ++d, f == this.blockSize) {
                            ud(this, e);
                            f = 0;
                            break
                        }
                    } else
                        for (; d < b;)
                            if (e[f] = a[d], ++f, ++d, f == this.blockSize) {
                                ud(this, e);
                                f = 0;
                                break
                            }
            }
            this.v = f;
            this.J += b
        }
    };
    td.prototype.digest = function() {
        var a = [],
            b = 8 * this.J;
        56 > this.v ? this.update(this.H, 56 - this.v) : this.update(this.H, this.blockSize - (this.v - 56));
        for (var c = this.blockSize - 1; 56 <= c; c--) this.L[c] = b & 255, b /= 256;
        ud(this, this.L);
        for (c = b = 0; 5 > c; c++)
            for (var d = 24; 0 <= d; d -= 8) a[b] = this.g[c] >> d & 255, ++b;
        return a
    };
    var vd = function() {
        this.R = new td
    };
    vd.prototype.reset = function() {
        this.R.reset()
    };
    var wd = A.crypto,
        xd = !1,
        yd = 0,
        zd = 0,
        Ad = 1,
        Bd = 0,
        Cd = "",
        Dd = function(a) {
            a = a || A.event;
            var b = a.screenX + a.clientX << 16;
            b += a.screenY + a.clientY;
            b *= (new Date).getTime() % 1E6;
            Ad = Ad * b % Bd;
            0 < yd && ++zd == yd && zb("mousemove", Dd, "remove", "de")
        },
        Ed = function(a) {
            var b = new vd;
            a = unescape(encodeURIComponent(a));
            for (var c = [], d = 0, e = a.length; d < e; ++d) c.push(a.charCodeAt(d));
            b.R.update(c);
            b = b.R.digest();
            a = "";
            for (c = 0; c < b.length; c++) a += "0123456789ABCDEF".charAt(Math.floor(b[c] / 16)) + "0123456789ABCDEF".charAt(b[c] % 16);
            return a
        };
    xd = !!wd && "function" == typeof wd.getRandomValues;
    xd || (Bd = 1E6 * (screen.width * screen.width + screen.height), Cd = Ed(B.cookie + "|" + B.location + "|" + (new Date).getTime() + "|" + Math.random()), yd = S("random/maxObserveMousemove") || 0, 0 != yd && zb("mousemove", Dd, "add", "at"));
    var Fd = function() {
            var a = L.onl;
            if (!a) {
                a = D();
                L.onl = a;
                var b = D();
                a.e = function(c) {
                    var d = b[c];
                    d && (delete b[c], d())
                };
                a.a = function(c, d) {
                    b[c] = d
                };
                a.r = function(c) {
                    delete b[c]
                }
            }
            return a
        },
        Gd = function(a, b) {
            b = b.onload;
            return "function" === typeof b ? (Fd().a(a, b), b) : null
        },
        Hd = function(a) {
            G(/^\w+$/.test(a), "Unsupported id - " + a);
            return 'onload="window.___jsl.onl.e(&#34;' + a + '&#34;)"'
        },
        Id = function(a) {
            Fd().r(a)
        };
    var Jd = {
            allowtransparency: "true",
            frameborder: "0",
            hspace: "0",
            marginheight: "0",
            marginwidth: "0",
            scrolling: "no",
            style: "",
            tabindex: "0",
            vspace: "0",
            width: "100%"
        },
        Kd = {
            allowtransparency: !0,
            onload: !0
        },
        Ld = 0,
        Md = function(a) {
            G(!a || xb.test(a), "Illegal url for new iframe - " + a)
        },
        Nd = function(a, b, c, d, e) {
            Md(c.src);
            var f, g = Gd(d, c),
                h = g ? Hd(d) : "";
            try {
                document.all && (f = a.createElement('<iframe frameborder="' + jb(String(c.frameborder)) + '" scrolling="' + jb(String(c.scrolling)) + '" ' + h + ' name="' + jb(String(c.name)) + '"/>'))
            } catch (l) {} finally {
                f ||
                    (f = (a ? new Ya(Xa(a)) : va || (va = new Ya)).ga("IFRAME"), g && (f.onload = function() {
                        f.onload = null;
                        g.call(this)
                    }, Id(d)))
            }
            f.setAttribute("ng-non-bindable", "");
            for (var k in c) a = c[k], "style" === k && "object" === typeof a ? F(a, f.style) : Kd[k] || f.setAttribute(k, String(a));
            (k = e && e.beforeNode || null) || e && e.dontclear || Eb(b);
            b.insertBefore(f, k);
            f = k ? k.previousSibling : b.lastChild;
            c.allowtransparency && (f.allowTransparency = !0);
            return f
        };
    var Od = /^:[\w]+$/,
        Pd = /:([a-zA-Z_]+):/g,
        Qd = function() {
            var a = Nc() || "0",
                b = Oc();
            var c = Nc(void 0) || a;
            var d = Oc(void 0),
                e = "";
            c && (e += "u/" + encodeURIComponent(String(c)) + "/");
            d && (e += "b/" + encodeURIComponent(String(d)) + "/");
            c = e || null;
            (e = (d = !1 === S("isLoggedIn")) ? "_/im/" : "") && (c = "");
            var f = S("iframes/:socialhost:"),
                g = S("iframes/:im_socialhost:");
            return yb = {
                socialhost: f,
                ctx_socialhost: d ? g : f,
                session_index: a,
                session_delegate: b,
                session_prefix: c,
                im_prefix: e
            }
        },
        Rd = function(a, b) {
            return Qd()[b] || ""
        },
        Sd = function(a) {
            return function(b,
                c) {
                return a ? Qd()[c] || a[c] || "" : Qd()[c] || ""
            }
        };
    var Td = function(a) {
            var b;
            a.match(/^https?%3A/i) && (b = decodeURIComponent(a));
            return wb(document, b ? b : a)
        },
        Ud = function(a) {
            a = a || "canonical";
            for (var b = document.getElementsByTagName("link"), c = 0, d = b.length; c < d; c++) {
                var e = b[c],
                    f = e.getAttribute("rel");
                if (f && f.toLowerCase() == a && (e = e.getAttribute("href")) && (e = Td(e)) && null != e.match(/^https?:\/\/[\w\-_\.]+/i)) return e
            }
            return window.location.href
        };
    var Vd = {
            se: "0"
        },
        Wd = {
            post: !0
        },
        Xd = {
            style: "position:absolute;top:-10000px;width:450px;margin:0px;border-style:none"
        },
        Yd = "onPlusOne _ready _close _open _resizeMe _renderstart oncircled drefresh erefresh".split(" "),
        Zd = C(L, "WI", D()),
        $d = function(a, b, c) {
            var d;
            var e = {};
            var f = d = a;
            "plus" == a && b.action && (d = a + "_" + b.action, f = a + "/" + b.action);
            (d = Q("iframes/" + d + "/url")) || (d = ":im_socialhost:/:session_prefix::im_prefix:_/widget/render/" + f + "?usegapi=1");
            for (var g in Vd) e[g] = g + "/" + (b[g] || Vd[g]) + "/";
            e = wb(B, d.replace(Pd,
                Sd(e)));
            g = "iframes/" + a + "/params/";
            f = {};
            F(b, f);
            (d = Q("lang") || Q("gwidget/lang")) && (f.hl = d);
            Wd[a] || (f.origin = window.location.origin || window.location.protocol + "//" + window.location.host);
            f.exp = Q(g + "exp");
            if (g = Q(g + "location"))
                for (d = 0; d < g.length; d++) {
                    var h = g[d];
                    f[h] = A.location[h]
                }
            switch (a) {
                case "plus":
                case "follow":
                    g = f.href;
                    d = b.action ? void 0 : "publisher";
                    g = (g = "string" == typeof g ? g : void 0) ? Td(g) : Ud(d);
                    f.url = g;
                    delete f.href;
                    break;
                case "plusone":
                    g = (g = b.href) ? Td(g) : Ud();
                    f.url = g;
                    g = b.db;
                    d = Q();
                    null == g && d && (g = d.db,
                        null == g && (g = d.gwidget && d.gwidget.db));
                    f.db = g || void 0;
                    g = b.ecp;
                    d = Q();
                    null == g && d && (g = d.ecp, null == g && (g = d.gwidget && d.gwidget.ecp));
                    f.ecp = g || void 0;
                    delete f.href;
                    break;
                case "signin":
                    f.url = Ud()
            }
            L.ILI && (f.iloader = "1");
            delete f["data-onload"];
            delete f.rd;
            for (var k in Vd) f[k] && delete f[k];
            f.gsrc = Q("iframes/:source:");
            k = Q("inline/css");
            "undefined" !== typeof k && 0 < c && k >= c && (f.ic = "1");
            k = /^#|^fr-/;
            c = {};
            for (var l in f) E(f, l) && k.test(l) && (c[l.replace(k, "")] = f[l], delete f[l]);
            l = "q" == Q("iframes/" + a + "/params/si") ? f :
                c;
            k = Dc();
            for (var m in k) !E(k, m) || E(f, m) || E(c, m) || (l[m] = k[m]);
            m = [].concat(Yd);
            (l = Q("iframes/" + a + "/methods")) && "object" === typeof l && bb.test(l.push) && (m = m.concat(l));
            for (var t in b) E(b, t) && /^on/.test(t) && ("plus" != a || "onconnect" != t) && (m.push(t), delete f[t]);
            delete f.callback;
            c._methods = m.join(",");
            return ub(e, f, c)
        },
        ae = ["style", "data-gapiscan"],
        ce = function(a) {
            for (var b = D(), c = 0 != a.nodeName.toLowerCase().indexOf("g:"), d = 0, e = a.attributes.length; d < e; d++) {
                var f = a.attributes[d],
                    g = f.name,
                    h = f.value;
                0 <= cb.call(ae,
                    g) || c && 0 != g.indexOf("data-") || "null" === h || "specified" in f && !f.specified || (c && (g = g.substr(5)), b[g.toLowerCase()] = h)
            }
            a = a.style;
            (c = be(a && a.height)) && (b.height = String(c));
            (a = be(a && a.width)) && (b.width = String(a));
            return b
        },
        be = function(a) {
            var b = void 0;
            "number" === typeof a ? b = a : "string" === typeof a && (b = parseInt(a, 10));
            return b
        },
        fe = function() {
            var a = L.drw;
            Jc(function(b) {
                if (a !== b.id && 4 != b.state && "share" != b.type) {
                    var c = b.id,
                        d = b.type,
                        e = b.url;
                    b = b.userParams;
                    var f = B.getElementById(c);
                    if (f) {
                        var g = $d(d, b, 0);
                        g ? (f = f.parentNode,
                            de(e) !== de(g) && (b.dontclear = !0, b.rd = !0, b.ri = !0, b.type = d, ee(f, b), (d = R[f.lastChild.id]) && (d.oid = c), Kc(c, 4))) : delete R[c]
                    } else delete R[c]
                }
            })
        },
        de = function(a) {
            var b = RegExp("(\\?|&)ic=1");
            return a.replace(/#.*/, "").replace(b, "")
        };
    var ge, he, Y, ie, je, ke = /(?:^|\s)g-((\S)*)(?:$|\s)/,
        le = {
            plusone: !0,
            autocomplete: !0,
            profile: !0,
            signin: !0,
            signin2: !0
        };
    ge = C(L, "SW", D());
    he = C(L, "SA", D());
    Y = C(L, "SM", D());
    ie = C(L, "FW", []);
    je = null;
    var ne = function(a, b) {
            me(void 0, !1, a, b)
        },
        me = function(a, b, c, d) {
            M("ps0", !0);
            c = ("string" === typeof c ? document.getElementById(c) : c) || B;
            var e = B.documentMode;
            if (c.querySelectorAll && (!e || 8 < e)) {
                e = d ? [d] : kb(ge).concat(kb(he)).concat(kb(Y));
                for (var f = [], g = 0; g < e.length; g++) {
                    var h = e[g];
                    f.push(".g-" + h, "g\\:" + h)
                }
                e = c.querySelectorAll(f.join(","))
            } else e = c.getElementsByTagName("*");
            c = D();
            for (f = 0; f < e.length; f++) {
                g = e[f];
                var k = g;
                h = d;
                var l = k.nodeName.toLowerCase(),
                    m = void 0;
                if (k.getAttribute("data-gapiscan")) h = null;
                else {
                    var t =
                        l.indexOf("g:");
                    0 == t ? m = l.substr(2) : (t = (t = String(k.className || k.getAttribute("class"))) && ke.exec(t)) && (m = t[1]);
                    h = !m || !(ge[m] || he[m] || Y[m]) || h && m !== h ? null : m
                }
                h && (le[h] || 0 == g.nodeName.toLowerCase().indexOf("g:") || 0 != kb(ce(g)).length) && (g.setAttribute("data-gapiscan", !0), C(c, h, []).push(g))
            }
            if (b)
                for (var u in c)
                    for (b = c[u], d = 0; d < b.length; d++) b[d].setAttribute("data-onload", !0);
            for (var p in c) ie.push(p);
            M("ps1", !0);
            if ((u = ie.join(":")) || a) try {
                H.load(u, a)
            } catch (y) {
                Gc.log(y);
                return
            }
            if (oe(je || {}))
                for (var I in c) {
                    a =
                        c[I];
                    p = 0;
                    for (b = a.length; p < b; p++) a[p].removeAttribute("data-gapiscan");
                    pe(I)
                } else {
                    d = [];
                    for (I in c)
                        for (a = c[I], p = 0, b = a.length; p < b; p++) e = a[p], qe(I, e, ce(e), d, b);
                    re(u, d)
                }
        },
        se = function(a) {
            var b = C(H, a, {});
            b.go || (b.go = function(c) {
                return ne(c, a)
            }, b.render = function(c, d) {
                d = d || {};
                d.type = a;
                return ee(c, d)
            })
        },
        te = function(a) {
            ge[a] = !0
        },
        ue = function(a) {
            he[a] = !0
        },
        ve = function(a) {
            Y[a] = !0
        };
    var pe = function(a, b) {
            var c = Ib(a);
            b && c ? (c(b), (c = b.iframeNode) && c.setAttribute("data-gapiattached", !0)) : H.load(a, function() {
                var d = Ib(a),
                    e = b && b.iframeNode,
                    f = b && b.userParams;
                e && d ? (d(b), e.setAttribute("data-gapiattached", !0)) : (d = H[a].go, "signin2" == a ? d(e, f) : d(e && e.parentNode, f))
            })
        },
        oe = function() {
            return !1
        },
        re = function() {},
        qe = function(a, b, c, d, e, f, g) {
            switch (we(b, a, f)) {
                case 0:
                    a = Y[a] ? a + "_annotation" : a;
                    d = {};
                    d.iframeNode = b;
                    d.userParams = c;
                    pe(a, d);
                    break;
                case 1:
                    if (b.parentNode) {
                        for (var h in c) {
                            if (f = E(c, h)) f = c[h],
                                f = !!f && "object" === typeof f && (!f.toString || f.toString === Object.prototype.toString || f.toString === Array.prototype.toString);
                            if (f) try {
                                c[h] = pd(c[h])
                            } catch (K) {
                                delete c[h]
                            }
                        }
                        f = !0;
                        c.dontclear && (f = !1);
                        delete c.dontclear;
                        Ic();
                        h = $d(a, c, e);
                        e = g || {};
                        e.allowPost = 1;
                        e.attributes = Xd;
                        e.dontclear = !f;
                        g = {};
                        g.userParams = c;
                        g.url = h;
                        g.type = a;
                        if (c.rd) var k = b;
                        else k = document.createElement("div"), b.setAttribute("data-gapistub", !0), k.style.cssText = "position:absolute;width:450px;left:-10000px;", b.parentNode.insertBefore(k, b);
                        g.siteElement =
                            k;
                        k.id || (b = k, C(Zd, a, 0), f = "___" + a + "_" + Zd[a]++, b.id = f);
                        b = D();
                        b[">type"] = a;
                        F(c, b);
                        f = h;
                        c = k;
                        h = e || {};
                        b = h.attributes || {};
                        G(!(h.allowPost || h.forcePost) || !b.onload, "onload is not supported by post iframe (allowPost or forcePost)");
                        e = b = f;
                        Od.test(b) && (e = S("iframes/" + e.substring(1) + "/url"), G(!!e, "Unknown iframe url config for - " + b));
                        f = wb(B, e.replace(Pd, Rd));
                        b = c.ownerDocument || B;
                        e = h;
                        var l = 0;
                        do k = e.id || ["I", Ld++, "_", (new Date).getTime()].join(""); while (b.getElementById(k) && 5 > ++l);
                        G(5 > l, "Error creating iframe id");
                        e = k;
                        k = h;
                        l = {};
                        var m = {};
                        b.documentMode && 9 > b.documentMode && (l.hostiemode = b.documentMode);
                        F(k.queryParams || {}, l);
                        F(k.fragmentParams || {}, m);
                        var t = k.pfname;
                        var u = D();
                        S("iframes/dropLegacyIdParam") || (u.id = e);
                        u._gfid = e;
                        u.parent = b.location.protocol + "//" + b.location.host;
                        var p = J(b.location.href, "parent");
                        t = t || "";
                        !t && p && (p = J(b.location.href, "_gfid", "") || J(b.location.href, "id", ""), t = J(b.location.href, "pfname", ""), t = p ? t + "/" + p : "");
                        t || (p = od(J(b.location.href, "jcp", ""))) && "object" == typeof p && (t = (t = p.id) ? p.pfname +
                            "/" + t : "");
                        u.pfname = t;
                        k.connectWithJsonParam && (p = {}, p.jcp = pd(u), u = p);
                        p = J(f, "rpctoken") || l.rpctoken || m.rpctoken;
                        if (!p) {
                            if (!(p = k.rpctoken)) {
                                p = String;
                                t = Math;
                                var I = t.round;
                                if (xd) {
                                    var y = new A.Uint32Array(1);
                                    wd.getRandomValues(y);
                                    y = Number("0." + y[0])
                                } else y = Ad, y += parseInt(Cd.substr(0, 20), 16), Cd = Ed(Cd), y /= Bd + Math.pow(16, 20);
                                p = p(I.call(t, 1E8 * y))
                            }
                            u.rpctoken = p
                        }
                        k.rpctoken = p;
                        F(u, k.connectWithQueryParams ? l : m);
                        p = b.location.href;
                        u = D();
                        (t = J(p, "_bsh", L.bsh)) && (u._bsh = t);
                        (p = Gb(p)) && (u.jsh = p);
                        k.hintInFragment ? F(u, m) :
                            F(u, l);
                        l = ub(f, l, m, k.paramsSerializer);
                        f = h;
                        m = D();
                        F(Jd, m);
                        F(f.attributes, m);
                        m.name = m.id = e;
                        m.src = l;
                        h.eurl = l;
                        h = (k = h) || {};
                        f = !!h.allowPost;
                        if (h.forcePost || f && 2E3 < l.length) {
                            f = rb(l);
                            m.src = "";
                            k.dropDataPostorigin || (m["data-postorigin"] = l);
                            h = Nd(b, c, m, e);
                            if (-1 != navigator.userAgent.indexOf("WebKit")) {
                                var v = h.contentWindow.document;
                                v.open();
                                l = v.createElement("div");
                                m = {};
                                u = e + "_inner";
                                m.name = u;
                                m.src = "";
                                m.style = "display:none";
                                Nd(b, l, m, u, k)
                            }
                            l = (k = f.query[0]) ? k.split("&") : [];
                            k = [];
                            for (m = 0; m < l.length; m++) u = l[m].split("=",
                                2), k.push([decodeURIComponent(u[0]), decodeURIComponent(u[1])]);
                            f.query = [];
                            l = sb(f);
                            G(xb.test(l), "Invalid URL: " + l);
                            f = b.createElement("form");
                            f.method = "POST";
                            f.target = e;
                            f.style.display = "none";
                            e = l instanceof x ? l : Ma(l);
                            Qa(f, "HTMLFormElement").action = Ka(e);
                            for (e = 0; e < k.length; e++) l = b.createElement("input"), l.type = "hidden", l.name = k[e][0], l.value = k[e][1], f.appendChild(l);
                            c.appendChild(f);
                            f.submit();
                            f.parentNode.removeChild(f);
                            v && v.close();
                            v = h
                        } else v = Nd(b, c, m, e, k);
                        g.iframeNode = v;
                        g.id = v.getAttribute("id");
                        v = g.id;
                        c = D();
                        c.id = v;
                        c.userParams = g.userParams;
                        c.url = g.url;
                        c.type = g.type;
                        c.state = 1;
                        R[v] = c;
                        v = g
                    } else v = null;
                    v && ((g = v.id) && d.push(g), pe(a, v))
            }
        },
        we = function(a, b, c) {
            if (a && 1 === a.nodeType && b) {
                if (c) return 1;
                if (Y[b]) {
                    if (Fb[a.nodeName.toLowerCase()]) return (a = a.innerHTML) && a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "") ? 0 : 1
                } else {
                    if (he[b]) return 0;
                    if (ge[b]) return 1
                }
            }
            return null
        },
        ee = function(a, b) {
            var c = b.type;
            delete b.type;
            var d = ("string" === typeof a ? document.getElementById(a) : a) || void 0;
            if (d) {
                a = {};
                for (var e in b) E(b, e) &&
                    (a[e.toLowerCase()] = b[e]);
                a.rd = 1;
                (b = !!a.ri) && delete a.ri;
                e = [];
                qe(c, d, a, e, 0, b, void 0);
                re(c, e)
            } else Gc.log("string" === "gapi." + c + ".render: missing element " + typeof a ? a : "")
        };
    C(H, "platform", {}).go = ne;
    oe = function(a) {
        for (var b = ["_c", "jsl", "h"], c = 0; c < b.length && a; c++) a = a[b[c]];
        b = Gb(Za.href);
        return !a || 0 != a.indexOf("n;") && 0 != b.indexOf("n;") && a !== b
    };
    re = function(a, b) {
        xe(a, b)
    };
    var Bb = function(a) {
            me(a, !0)
        },
        ye = function(a, b) {
            b = b || [];
            for (var c = 0; c < b.length; ++c) a(b[c]);
            for (a = 0; a < b.length; a++) se(b[a])
        };
    Sb.push(["platform", function(a, b, c) {
        je = c;
        b && ie.push(b);
        ye(te, a);
        ye(ue, c._c.annotation);
        ye(ve, c._c.bimodal);
        zc();
        xc();
        if ("explicit" != Q("parsetags")) {
            Hb(a);
            Ec(Dc()) && !Q("disableRealtimeCallback") && Ic();
            if (c && (a = c.callback)) {
                var d = lb(a);
                delete c.callback
            }
            Db(function() {
                Bb(d)
            })
        }
    }]);
    H._pl = !0;
    var ze = function(a) {
        a = (a = R[a]) ? a.oid : void 0;
        if (a) {
            var b = B.getElementById(a);
            b && b.parentNode.removeChild(b);
            delete R[a];
            ze(a)
        }
    };
    var Ae = /^\{h:'/,
        Be = /^!_/,
        Ce = "",
        xe = function(a, b) {
            function c() {
                zb("message", d, "remove", "de")
            }

            function d(f) {
                var g = f.data,
                    h = f.origin;
                if (De(g, b)) {
                    var k = e;
                    e = !1;
                    k && M("rqe");
                    Ee(a, function() {
                        k && M("rqd");
                        c();
                        for (var l = C(L, "RPMQ", []), m = 0; m < l.length; m++) l[m]({
                            data: g,
                            origin: h
                        })
                    })
                }
            }
            if (0 !== b.length) {
                Ce = J(Za.href, "pfname", "");
                var e = !0;
                zb("message", d, "add", "at");
                rc(a, c)
            }
        },
        De = function(a, b) {
            a = String(a);
            if (Ae.test(a)) return !0;
            var c = !1;
            Be.test(a) && (c = !0, a = a.substr(2));
            if (!/^\{/.test(a)) return !1;
            var d = od(a);
            if (!d) return !1;
            a = d.f;
            if (d.s && a && -1 != cb.call(b, a)) {
                if ("_renderstart" === d.s || d.s === Ce + "/" + a + "::_renderstart")
                    if (d = d.a && d.a[c ? 0 : 1], b = B.getElementById(a), Kc(a, 2), d && b && d.width && d.height) {
                        a: {
                            c = b.parentNode;a = d || {};
                            if (Hc()) {
                                var e = b.id;
                                if (e) {
                                    d = (d = R[e]) ? d.state : void 0;
                                    if (1 === d || 4 === d) break a;
                                    ze(e)
                                }
                            }(d = c.nextSibling) && d.getAttribute && d.getAttribute("data-gapistub") && (c.parentNode.removeChild(d), c.style.cssText = "");d = a.width;
                            var f = a.height,
                                g = c.style;g.textIndent = "0";g.margin = "0";g.padding = "0";g.background = "transparent";g.borderStyle =
                            "none";g.cssFloat = "none";g.styleFloat = "none";g.lineHeight = "normal";g.fontSize = "1px";g.verticalAlign = "baseline";c = c.style;c.display = "inline-block";g = b.style;g.position = "static";g.left = "0";g.top = "0";g.visibility = "visible";d && (c.width = g.width = d + "px");f && (c.height = g.height = f + "px");a.verticalAlign && (c.verticalAlign = a.verticalAlign);e && Kc(e, 3)
                        }
                        b["data-csi-wdt"] = (new Date).getTime()
                    }
                return !0
            }
            return !1
        },
        Ee = function(a, b) {
            rc(a, b)
        };
    var Fe = function(a, b) {
        this.N = a;
        a = b || {};
        this.ha = Number(a.maxAge) || 0;
        this.W = a.domain;
        this.Y = a.path;
        this.ia = !!a.secure
    };
    Fe.prototype.read = function() {
        for (var a = this.N + "=", b = document.cookie.split(/;\s*/), c = 0; c < b.length; ++c) {
            var d = b[c];
            if (0 == d.indexOf(a)) return d.substr(a.length)
        }
    };
    Fe.prototype.write = function(a, b) {
        if (!Ge.test(this.N)) throw "Invalid cookie name";
        if (!He.test(a)) throw "Invalid cookie value";
        a = this.N + "=" + a;
        this.W && (a += ";domain=" + this.W);
        this.Y && (a += ";path=" + this.Y);
        b = "number" === typeof b ? b : this.ha;
        if (0 <= b) {
            var c = new Date;
            c.setSeconds(c.getSeconds() + b);
            a += ";expires=" + c.toUTCString()
        }
        this.ia && (a += ";secure");
        document.cookie = a;
        return !0
    };
    Fe.prototype.clear = function() {
        this.write("", 0)
    };
    var He = /^[-+/_=.:|%&a-zA-Z0-9@]*$/,
        Ge = /^[A-Z_][A-Z0-9_]{0,63}$/;
    Fe.iterate = function(a) {
        for (var b = document.cookie.split(/;\s*/), c = 0; c < b.length; ++c) {
            var d = b[c].split("="),
                e = d.shift();
            a(e, d.join("="))
        }
    };
    var Ie = function(a) {
        this.G = a
    };
    Ie.prototype.read = function() {
        if (Z.hasOwnProperty(this.G)) return Z[this.G]
    };
    Ie.prototype.write = function(a) {
        Z[this.G] = a;
        return !0
    };
    Ie.prototype.clear = function() {
        delete Z[this.G]
    };
    var Z = {};
    Ie.iterate = function(a) {
        for (var b in Z) Z.hasOwnProperty(b) && a(b, Z[b])
    };
    var Je = "https:" === window.location.protocol,
        Ke = Je || "http:" === window.location.protocol ? Fe : Ie,
        Le = function(a) {
            var b = a.substr(1),
                c = "",
                d = window.location.hostname;
            if ("" !== b) {
                c = parseInt(b, 10);
                if (isNaN(c)) return null;
                b = d.split(".");
                if (b.length < c - 1) return null;
                b.length == c - 1 && (d = "." + d)
            } else d = "";
            return {
                l: "S" == a.charAt(0),
                domain: d,
                o: c
            }
        },
        Me = function() {
            var a, b = null;
            Ke.iterate(function(c, d) {
                0 === c.indexOf("G_AUTHUSER_") && (c = Le(c.substring(11)), !a || c.l && !a.l || c.l == a.l && c.o > a.o) && (a = c, b = d)
            });
            return {
                fa: a,
                K: b
            }
        };

    function Ne(a) {
        if (0 !== a.indexOf("GCSC")) return null;
        var b = {
            X: !1
        };
        a = a.substr(4);
        if (!a) return b;
        var c = a.charAt(0);
        a = a.substr(1);
        var d = a.lastIndexOf("_");
        if (-1 == d) return b;
        var e = Le(a.substr(d + 1));
        if (null == e) return b;
        a = a.substring(0, d);
        if ("_" !== a.charAt(0)) return b;
        d = "E" === c && e.l;
        return !d && ("U" !== c || e.l) || d && !Je ? b : {
            X: !0,
            l: d,
            la: a.substr(1),
            domain: e.domain,
            o: e.o
        }
    }
    var Oe = function(a) {
            if (!a) return [];
            a = a.split("=");
            return a[1] ? a[1].split("|") : []
        },
        Pe = function(a) {
            a = a.split(":");
            return {
                clientId: a[0].split("=")[1],
                ka: Oe(a[1]),
                na: Oe(a[2]),
                ma: Oe(a[3])
            }
        },
        Qe = function() {
            var a = Me(),
                b = a.fa;
            a = a.K;
            if (null !== a) {
                var c;
                Ke.iterate(function(f, g) {
                    (f = Ne(f)) && f.X && f.l == b.l && f.o == b.o && (c = g)
                });
                if (c) {
                    var d = Pe(c),
                        e = d && d.ka[Number(a)];
                    d = d && d.clientId;
                    if (e) return {
                        K: a,
                        ja: e,
                        clientId: d
                    }
                }
            }
            return null
        };
    var Se = function() {
        this.V = Re
    };
    n = Se.prototype;
    n.aa = function() {
        this.M || (this.A = 0, this.M = !0, this.Z())
    };
    n.Z = function() {
        this.M && (this.V() ? this.A = this.T : this.A = Math.min(2 * (this.A || this.T), 120), window.setTimeout(ra(this.Z, this), 1E3 * this.A))
    };
    n.A = 0;
    n.T = 2;
    n.V = null;
    n.M = !1;
    for (var Te = 0; 64 > Te; ++Te);
    var Ue = null;
    Hc = function() {
        return L.oa = !0
    };
    Ic = function() {
        L.oa = !0;
        var a = Qe();
        (a = a && a.K) && yc("googleapis.config/sessionIndex", a);
        Ue || (Ue = C(L, "ss", new Se));
        a = Ue;
        a.aa && a.aa()
    };
    var Re = function() {
        var a = Qe(),
            b = a && a.ja || null,
            c = a && a.clientId;
        rc("auth", {
            callback: function() {
                var d = A.gapi.auth,
                    e = {
                        client_id: c,
                        session_state: b
                    };
                d.checkSessionState(e, function(f) {
                    var g = e.session_state,
                        h = !!Q("isLoggedIn");
                    f = Q("debug/forceIm") ? !1 : g && f || !g && !f;
                    if (h = h !== f) yc("isLoggedIn", f), Ic(), fe(), f || ((f = d.signOut) ? f() : (f = d.setToken) && f(null));
                    f = Dc();
                    var k = Q("savedUserState");
                    g = d._guss(f.cookiepolicy);
                    k = k != g && "undefined" != typeof k;
                    yc("savedUserState", g);
                    (h || k) && Ec(f) && !Q("disableRealtimeCallback") && d._pimf(f, !0)
                })
            }
        });
        return !0
    };
    M("bs0", !0, window.gapi._bs);
    M("bs1", !0);
    delete window.gapi._bs;
}).call(this);
gapi.load("", {
    callback: window["gapi_onload"],
    _c: {
        "jsl": {
            "ci": {
                "deviceType": "desktop",
                "oauth-flow": {
                    "authUrl": "https://accounts.google.com/o/oauth2/auth",
                    "proxyUrl": "https://accounts.google.com/o/oauth2/postmessageRelay",
                    "disableOpt": true,
                    "idpIframeUrl": "https://accounts.google.com/o/oauth2/iframe",
                    "usegapi": false
                },
                "debug": {
                    "reportExceptionRate": 0.05,
                    "forceIm": false,
                    "rethrowException": false,
                    "host": "https://apis.google.com"
                },
                "enableMultilogin": true,
                "googleapis.config": {
                    "auth": {
                        "useFirstPartyAuthV2": false
                    }
                },
                "inline": {
                    "css": 1
                },
                "disableRealtimeCallback": false,
                "drive_share": {
                    "skipInitCommand": true
                },
                "csi": {
                    "rate": 0.01
                },
                "client": {
                    "cors": false
                },
                "signInDeprecation": {
                    "rate": 0.0
                },
                "include_granted_scopes": true,
                "llang": "en",
                "iframes": {
                    "youtube": {
                        "params": {
                            "location": ["search", "hash"]
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/youtube?usegapi\u003d1",
                        "methods": ["scroll", "openwindow"]
                    },
                    "ytsubscribe": {
                        "url": "https://www.youtube.com/subscribe_embed?usegapi\u003d1"
                    },
                    "plus_circle": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix::se:_/widget/plus/circle?usegapi\u003d1"
                    },
                    "plus_share": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix::se:_/+1/sharebutton?plusShare\u003dtrue\u0026usegapi\u003d1"
                    },
                    "rbr_s": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix::se:_/widget/render/recobarsimplescroller"
                    },
                    ":source:": "3p",
                    "playemm": {
                        "url": "https://play.google.com/work/embedded/search?usegapi\u003d1\u0026usegapi\u003d1"
                    },
                    "savetoandroidpay": {
                        "url": "https://pay.google.com/gp/v/widget/save"
                    },
                    "blogger": {
                        "params": {
                            "location": ["search", "hash"]
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/blogger?usegapi\u003d1",
                        "methods": ["scroll", "openwindow"]
                    },
                    "evwidget": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix:_/events/widget?usegapi\u003d1"
                    },
                    "partnersbadge": {
                        "url": "https://www.gstatic.com/partners/badge/templates/badge.html?usegapi\u003d1"
                    },
                    "dataconnector": {
                        "url": "https://dataconnector.corp.google.com/:session_prefix:ui/widgetview?usegapi\u003d1"
                    },
                    "surveyoptin": {
                        "url": "https://www.google.com/shopping/customerreviews/optin?usegapi\u003d1"
                    },
                    ":socialhost:": "https://apis.google.com",
                    "shortlists": {
                        "url": ""
                    },
                    "hangout": {
                        "url": "https://talkgadget.google.com/:session_prefix:talkgadget/_/widget"
                    },
                    "plus_followers": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/_/im/_/widget/render/plus/followers?usegapi\u003d1"
                    },
                    "post": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix::im_prefix:_/widget/render/post?usegapi\u003d1"
                    },
                    ":gplus_url:": "https://plus.google.com",
                    "signin": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/signin?usegapi\u003d1",
                        "methods": ["onauth"]
                    },
                    "rbr_i": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix::se:_/widget/render/recobarinvitation"
                    },
                    "share": {
                        "url": ":socialhost:/:session_prefix::im_prefix:_/widget/render/share?usegapi\u003d1"
                    },
                    "plusone": {
                        "params": {
                            "count": "",
                            "size": "",
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix::se:_/+1/fastbutton?usegapi\u003d1"
                    },
                    "comments": {
                        "params": {
                            "location": ["search", "hash"]
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/comments?usegapi\u003d1",
                        "methods": ["scroll", "openwindow"]
                    },
                    ":im_socialhost:": "https://plus.googleapis.com",
                    "backdrop": {
                        "url": "https://clients3.google.com/cast/chromecast/home/widget/backdrop?usegapi\u003d1"
                    },
                    "visibility": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/visibility?usegapi\u003d1"
                    },
                    "autocomplete": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/autocomplete"
                    },
                    "additnow": {
                        "url": "https://apis.google.com/marketplace/button?usegapi\u003d1",
                        "methods": ["launchurl"]
                    },
                    ":signuphost:": "https://plus.google.com",
                    "ratingbadge": {
                        "url": "https://www.google.com/shopping/customerreviews/badge?usegapi\u003d1"
                    },
                    "appcirclepicker": {
                        "url": ":socialhost:/:session_prefix:_/widget/render/appcirclepicker"
                    },
                    "follow": {
                        "url": ":socialhost:/:session_prefix:_/widget/render/follow?usegapi\u003d1"
                    },
                    "community": {
                        "url": ":ctx_socialhost:/:session_prefix::im_prefix:_/widget/render/community?usegapi\u003d1"
                    },
                    "sharetoclassroom": {
                        "url": "https://classroom.google.com/sharewidget?usegapi\u003d1"
                    },
                    "ytshare": {
                        "params": {
                            "url": ""
                        },
                        "url": ":socialhost:/:session_prefix:_/widget/render/ytshare?usegapi\u003d1"
                    },
                    "plus": {
                        "url": ":socialhost:/:session_prefix:_/widget/render/badge?usegapi\u003d1"
                    },
                    "family_creation": {
                        "params": {
                            "url": ""
                        },
                        "url": "https://families.google.com/webcreation?usegapi\u003d1\u0026usegapi\u003d1"
                    },
                    "commentcount": {
                        "url": ":socialhost:/:session_prefix:_/widget/render/commentcount?usegapi\u003d1"
                    },
                    "configurator": {
                        "url": ":socialhost:/:session_prefix:_/plusbuttonconfigurator?usegapi\u003d1"
                    },
                    "zoomableimage": {
                        "url": "https://ssl.gstatic.com/microscope/embed/"
                    },
                    "appfinder": {
                        "url": "https://workspace.google.com/:session_prefix:marketplace/appfinder?usegapi\u003d1"
                    },
                    "savetowallet": {
                        "url": "https://pay.google.com/gp/v/widget/save"
                    },
                    "person": {
                        "url": ":socialhost:/:session_prefix:_/widget/render/person?usegapi\u003d1"
                    },
                    "savetodrive": {
                        "url": "https://drive.google.com/savetodrivebutton?usegapi\u003d1",
                        "methods": ["save"]
                    },
                    "page": {
                        "url": ":socialhost:/:session_prefix:_/widget/render/page?usegapi\u003d1"
                    },
                    "card": {
                        "url": ":socialhost:/:session_prefix:_/hovercard/card"
                    }
                }
            },
            "h": "m;/_/scs/apps-static/_/js/k\u003doz.gapi.en_US.2lM46t9-YIo.O/am\u003dAQ/d\u003d1/rs\u003dAGLTcCOhwmvF7Fsri7fVyVVvLH1eaFC1jg/m\u003d__features__",
            "u": "https://apis.google.com/js/platform.js",
            "hee": true,
            "dpo": false,
            "le": []
        },
        "platform": ["additnow", "backdrop", "blogger", "comments", "commentcount", "community", "donation", "family_creation", "follow", "hangout", "health", "page", "partnersbadge", "person", "playemm", "playreview", "plus", "plusone", "post", "ratingbadge", "savetoandroidpay", "savetodrive", "savetowallet", "sharetoclassroom", "shortlists", "signin2", "surveyoptin", "visibility", "youtube", "ytsubscribe", "zoomableimage"],
        "annotation": ["interactivepost", "recobar", "signin2", "autocomplete", "profile"]
    }
});