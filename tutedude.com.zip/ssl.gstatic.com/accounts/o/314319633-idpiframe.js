/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
var m, aa = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    },
    ba = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    },
    ca = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    },
    da = ca(this),
    n = function(a, b) {
        if (b) a: {
            var c = da;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && null != b && ba(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    };
n("Symbol", function(a) {
    if (a) return a;
    var b = function(f, g) {
        this.te = f;
        ba(this, "description", {
            configurable: !0,
            writable: !0,
            value: g
        })
    };
    b.prototype.toString = function() {
        return this.te
    };
    var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
        d = 0,
        e = function(f) {
            if (this instanceof e) throw new TypeError("Symbol is not a constructor");
            return new b(c + (f || "") + "_" + d++, f)
        };
    return e
});
n("Symbol.iterator", function(a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
        var d = da[b[c]];
        "function" === typeof d && "function" != typeof d.prototype[a] && ba(d.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return ea(aa(this))
            }
        })
    }
    return a
});
var ea = function(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    },
    t = function(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        return b ? b.call(a) : {
            next: aa(a)
        }
    },
    fa = function(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    },
    ha = "function" == typeof Object.create ? Object.create : function(a) {
        var b = function() {};
        b.prototype = a;
        return new b
    },
    ia;
if ("function" == typeof Object.setPrototypeOf) ia = Object.setPrototypeOf;
else {
    var ja;
    a: {
        var ka = {
                a: !0
            },
            la = {};
        try {
            la.__proto__ = ka;
            ja = la.a;
            break a
        } catch (a) {}
        ja = !1
    }
    ia = ja ? function(a, b) {
        a.__proto__ = b;
        if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
        return a
    } : null
}
var ma = ia,
    u = function(a, b) {
        a.prototype = ha(b.prototype);
        a.prototype.constructor = a;
        if (ma) ma(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.sa = b.prototype
    },
    na = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
n("WeakMap", function(a) {
    function b() {}

    function c(k) {
        var l = typeof k;
        return "object" === l && null !== k || "function" === l
    }

    function d(k) {
        if (!na(k, f)) {
            var l = new b;
            ba(k, f, {
                value: l
            })
        }
    }

    function e(k) {
        var l = Object[k];
        l && (Object[k] = function(p) {
            if (p instanceof b) return p;
            Object.isExtensible(p) && d(p);
            return l(p)
        })
    }
    if (function() {
            if (!a || !Object.seal) return !1;
            try {
                var k = Object.seal({}),
                    l = Object.seal({}),
                    p = new a([
                        [k, 2],
                        [l, 3]
                    ]);
                if (2 != p.get(k) || 3 != p.get(l)) return !1;
                p.delete(k);
                p.set(l, 4);
                return !p.has(k) && 4 == p.get(l)
            } catch (q) {
                return !1
            }
        }()) return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
        h = function(k) {
            this.Ya = (g += Math.random() + 1).toString();
            if (k) {
                k = t(k);
                for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
            }
        };
    h.prototype.set = function(k, l) {
        if (!c(k)) throw Error("Invalid WeakMap key");
        d(k);
        if (!na(k, f)) throw Error("WeakMap key fail: " + k);
        k[f][this.Ya] = l;
        return this
    };
    h.prototype.get = function(k) {
        return c(k) && na(k, f) ? k[f][this.Ya] : void 0
    };
    h.prototype.has = function(k) {
        return c(k) && na(k, f) && na(k[f],
            this.Ya)
    };
    h.prototype.delete = function(k) {
        return c(k) && na(k, f) && na(k[f], this.Ya) ? delete k[f][this.Ya] : !1
    };
    return h
});
n("Map", function(a) {
    if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
            try {
                var h = Object.seal({
                        x: 4
                    }),
                    k = new a(t([
                        [h, "s"]
                    ]));
                if ("s" != k.get(h) || 1 != k.size || k.get({
                        x: 4
                    }) || k.set({
                        x: 4
                    }, "t") != k || 2 != k.size) return !1;
                var l = k.entries(),
                    p = l.next();
                if (p.done || p.value[0] != h || "s" != p.value[1]) return !1;
                p = l.next();
                return p.done || 4 != p.value[0].x || "t" != p.value[1] || !l.next().done ? !1 : !0
            } catch (q) {
                return !1
            }
        }()) return a;
    var b = new WeakMap,
        c = function(h) {
            this.Ta = {};
            this.ea =
                f();
            this.size = 0;
            if (h) {
                h = t(h);
                for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
            }
        };
    c.prototype.set = function(h, k) {
        h = 0 === h ? 0 : h;
        var l = d(this, h);
        l.list || (l.list = this.Ta[l.id] = []);
        l.C ? l.C.value = k : (l.C = {
            next: this.ea,
            ga: this.ea.ga,
            head: this.ea,
            key: h,
            value: k
        }, l.list.push(l.C), this.ea.ga.next = l.C, this.ea.ga = l.C, this.size++);
        return this
    };
    c.prototype.delete = function(h) {
        h = d(this, h);
        return h.C && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.Ta[h.id], h.C.ga.next = h.C.next, h.C.next.ga = h.C.ga,
            h.C.head = null, this.size--, !0) : !1
    };
    c.prototype.clear = function() {
        this.Ta = {};
        this.ea = this.ea.ga = f();
        this.size = 0
    };
    c.prototype.has = function(h) {
        return !!d(this, h).C
    };
    c.prototype.get = function(h) {
        return (h = d(this, h).C) && h.value
    };
    c.prototype.entries = function() {
        return e(this, function(h) {
            return [h.key, h.value]
        })
    };
    c.prototype.keys = function() {
        return e(this, function(h) {
            return h.key
        })
    };
    c.prototype.values = function() {
        return e(this, function(h) {
            return h.value
        })
    };
    c.prototype.forEach = function(h, k) {
        for (var l = this.entries(),
                p; !(p = l.next()).done;) p = p.value, h.call(k, p[1], p[0], this)
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function(h, k) {
            var l = k && typeof k;
            "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
            var p = h.Ta[l];
            if (p && na(h.Ta, l))
                for (h = 0; h < p.length; h++) {
                    var q = p[h];
                    if (k !== k && q.key !== q.key || k === q.key) return {
                        id: l,
                        list: p,
                        index: h,
                        C: q
                    }
                }
            return {
                id: l,
                list: p,
                index: -1,
                C: void 0
            }
        },
        e = function(h, k) {
            var l = h.ea;
            return ea(function() {
                if (l) {
                    for (; l.head != h.ea;) l = l.ga;
                    for (; l.next != l.head;) return l =
                        l.next, {
                            done: !1,
                            value: k(l)
                        };
                    l = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        },
        f = function() {
            var h = {};
            return h.ga = h.next = h.head = h
        },
        g = 0;
    return c
});
n("Array.prototype.find", function(a) {
    return a ? a : function(b, c) {
        a: {
            var d = this;d instanceof String && (d = String(d));
            for (var e = d.length, f = 0; f < e; f++) {
                var g = d[f];
                if (b.call(c, g, f, d)) {
                    b = g;
                    break a
                }
            }
            b = void 0
        }
        return b
    }
});
n("Promise", function(a) {
    function b() {
        this.ia = null
    }

    function c(g) {
        return g instanceof e ? g : new e(function(h) {
            h(g)
        })
    }
    if (a) return a;
    b.prototype.bd = function(g) {
        if (null == this.ia) {
            this.ia = [];
            var h = this;
            this.cd(function() {
                h.cf()
            })
        }
        this.ia.push(g)
    };
    var d = da.setTimeout;
    b.prototype.cd = function(g) {
        d(g, 0)
    };
    b.prototype.cf = function() {
        for (; this.ia && this.ia.length;) {
            var g = this.ia;
            this.ia = [];
            for (var h = 0; h < g.length; ++h) {
                var k = g[h];
                g[h] = null;
                try {
                    k()
                } catch (l) {
                    this.Fe(l)
                }
            }
        }
        this.ia = null
    };
    b.prototype.Fe = function(g) {
        this.cd(function() {
            throw g;
        })
    };
    var e = function(g) {
        this.Ka = 0;
        this.ib = void 0;
        this.Fa = [];
        this.Kd = !1;
        var h = this.ec();
        try {
            g(h.resolve, h.reject)
        } catch (k) {
            h.reject(k)
        }
    };
    e.prototype.ec = function() {
        function g(l) {
            return function(p) {
                k || (k = !0, l.call(h, p))
            }
        }
        var h = this,
            k = !1;
        return {
            resolve: g(this.Xf),
            reject: g(this.Dc)
        }
    };
    e.prototype.Xf = function(g) {
        if (g === this) this.Dc(new TypeError("A Promise cannot resolve to itself"));
        else if (g instanceof e) this.jg(g);
        else {
            a: switch (typeof g) {
                case "object":
                    var h = null != g;
                    break a;
                case "function":
                    h = !0;
                    break a;
                default:
                    h = !1
            }
            h ? this.Wf(g) : this.vd(g)
        }
    };
    e.prototype.Wf = function(g) {
        var h = void 0;
        try {
            h = g.then
        } catch (k) {
            this.Dc(k);
            return
        }
        "function" == typeof h ? this.kg(h, g) : this.vd(g)
    };
    e.prototype.Dc = function(g) {
        this.pe(2, g)
    };
    e.prototype.vd = function(g) {
        this.pe(1, g)
    };
    e.prototype.pe = function(g, h) {
        if (0 != this.Ka) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.Ka);
        this.Ka = g;
        this.ib = h;
        2 === this.Ka && this.$f();
        this.df()
    };
    e.prototype.$f = function() {
        var g = this;
        d(function() {
            if (g.Mf()) {
                var h = da.console;
                "undefined" !== typeof h && h.error(g.ib)
            }
        }, 1)
    };
    e.prototype.Mf = function() {
        if (this.Kd) return !1;
        var g = da.CustomEvent,
            h = da.Event,
            k = da.dispatchEvent;
        if ("undefined" === typeof k) return !0;
        "function" === typeof g ? g = new g("unhandledrejection", {
            cancelable: !0
        }) : "function" === typeof h ? g = new h("unhandledrejection", {
            cancelable: !0
        }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
        g.promise = this;
        g.reason = this.ib;
        return k(g)
    };
    e.prototype.df = function() {
        if (null != this.Fa) {
            for (var g =
                    0; g < this.Fa.length; ++g) f.bd(this.Fa[g]);
            this.Fa = null
        }
    };
    var f = new b;
    e.prototype.jg = function(g) {
        var h = this.ec();
        g.rb(h.resolve, h.reject)
    };
    e.prototype.kg = function(g, h) {
        var k = this.ec();
        try {
            g.call(h, k.resolve, k.reject)
        } catch (l) {
            k.reject(l)
        }
    };
    e.prototype.then = function(g, h) {
        function k(w, r) {
            return "function" == typeof w ? function(v) {
                try {
                    l(w(v))
                } catch (y) {
                    p(y)
                }
            } : r
        }
        var l, p, q = new e(function(w, r) {
            l = w;
            p = r
        });
        this.rb(k(g, l), k(h, p));
        return q
    };
    e.prototype.catch = function(g) {
        return this.then(void 0, g)
    };
    e.prototype.rb = function(g,
        h) {
        function k() {
            switch (l.Ka) {
                case 1:
                    g(l.ib);
                    break;
                case 2:
                    h(l.ib);
                    break;
                default:
                    throw Error("Unexpected state: " + l.Ka);
            }
        }
        var l = this;
        null == this.Fa ? f.bd(k) : this.Fa.push(k);
        this.Kd = !0
    };
    e.resolve = c;
    e.reject = function(g) {
        return new e(function(h, k) {
            k(g)
        })
    };
    e.race = function(g) {
        return new e(function(h, k) {
            for (var l = t(g), p = l.next(); !p.done; p = l.next()) c(p.value).rb(h, k)
        })
    };
    e.all = function(g) {
        var h = t(g),
            k = h.next();
        return k.done ? c([]) : new e(function(l, p) {
            function q(v) {
                return function(y) {
                    w[v] = y;
                    r--;
                    0 == r && l(w)
                }
            }
            var w = [],
                r = 0;
            do w.push(void 0), r++, c(k.value).rb(q(w.length - 1), p), k = h.next(); while (!k.done)
        })
    };
    return e
});
n("Set", function(a) {
    if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
            try {
                var c = Object.seal({
                        x: 4
                    }),
                    d = new a(t([c]));
                if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                        x: 4
                    }) != d || 2 != d.size) return !1;
                var e = d.entries(),
                    f = e.next();
                if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                f = e.next();
                return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
            } catch (g) {
                return !1
            }
        }()) return a;
    var b = function(c) {
        this.$ = new Map;
        if (c) {
            c =
                t(c);
            for (var d; !(d = c.next()).done;) this.add(d.value)
        }
        this.size = this.$.size
    };
    b.prototype.add = function(c) {
        c = 0 === c ? 0 : c;
        this.$.set(c, c);
        this.size = this.$.size;
        return this
    };
    b.prototype.delete = function(c) {
        c = this.$.delete(c);
        this.size = this.$.size;
        return c
    };
    b.prototype.clear = function() {
        this.$.clear();
        this.size = 0
    };
    b.prototype.has = function(c) {
        return this.$.has(c)
    };
    b.prototype.entries = function() {
        return this.$.entries()
    };
    b.prototype.values = function() {
        return this.$.values()
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function(c, d) {
        var e = this;
        this.$.forEach(function(f) {
            return c.call(d, f, f, e)
        })
    };
    return b
});
var oa = function(a, b) {
    a instanceof String && (a += "");
    var c = 0,
        d = !1,
        e = {
            next: function() {
                if (!d && c < a.length) {
                    var f = c++;
                    return {
                        value: b(f, a[f]),
                        done: !1
                    }
                }
                d = !0;
                return {
                    done: !0,
                    value: void 0
                }
            }
        };
    e[Symbol.iterator] = function() {
        return e
    };
    return e
};
n("Array.prototype.values", function(a) {
    return a ? a : function() {
        return oa(this, function(b, c) {
            return c
        })
    }
});
n("Array.prototype.keys", function(a) {
    return a ? a : function() {
        return oa(this, function(b) {
            return b
        })
    }
});
n("Array.from", function(a) {
    return a ? a : function(b, c, d) {
        c = null != c ? c : function(h) {
            return h
        };
        var e = [],
            f = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
        if ("function" == typeof f) {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
        } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
        return e
    }
});
n("Array.prototype.entries", function(a) {
    return a ? a : function() {
        return oa(this, function(b, c) {
            return [b, c]
        })
    }
});
var pa = pa || {},
    x = this || self,
    qa = function() {},
    ra = function(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    },
    sa = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    },
    ta = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    },
    va = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b,
                arguments)
        }
    },
    wa = function(a, b, c) {
        wa = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ta : va;
        return wa.apply(null, arguments)
    },
    xa = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    },
    z = function(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.sa = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.wg = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h -
                2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    },
    ya = function(a) {
        return a
    };

function za(a) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, za);
    else {
        var b = Error().stack;
        b && (this.stack = b)
    }
    a && (this.message = String(a))
}
z(za, Error);
za.prototype.name = "CustomError";
var Aa = function(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
    za.call(this, c + a[d])
};
z(Aa, za);
Aa.prototype.name = "AssertionError";
var Ba = function(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Aa("" + e, f || []);
    },
    A = function(a, b, c) {
        a || Ba("", null, b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    Ca = function(a, b) {
        throw new Aa("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
    },
    Da = function(a, b, c) {
        "string" !== typeof a && Ba("Expected string but got %s: %s.", [ra(a), a], b, Array.prototype.slice.call(arguments, 2))
    },
    Ea = function(a, b, c) {
        Array.isArray(a) || Ba("Expected array but got %s: %s.", [ra(a), a], b, Array.prototype.slice.call(arguments, 2))
    },
    Ga = function(a, b, c, d) {
        a instanceof b || Ba("Expected instanceof %s but got %s.", [Fa(b), Fa(a)], c, Array.prototype.slice.call(arguments, 3));
        return a
    },
    Fa = function(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : null === a ? "null" : typeof a
    };
var Ha = function(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
        var e = a.charCodeAt(d);
        255 < e && (b[c++] = e & 255, e >>= 8);
        b[c++] = e
    }
    return b
};
var Ia = Array.prototype.indexOf ? function(a, b) {
        A(null != a.length);
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    },
    Ja = Array.prototype.forEach ? function(a, b) {
        A(null != a.length);
        Array.prototype.forEach.call(a, b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    };

function Ka(a, b) {
    b = Ia(a, b);
    var c;
    if (c = 0 <= b) A(null != a.length), Array.prototype.splice.call(a, b, 1);
    return c
};
var La = String.prototype.trim ? function(a) {
        return a.trim()
    } : function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    },
    Ma = /&/g,
    Na = /</g,
    Oa = />/g,
    Pa = /"/g,
    Qa = /'/g,
    Ra = /\x00/g,
    Sa = /[\x00&<>"']/,
    Ua = function(a, b) {
        var c = 0;
        a = La(String(a)).split(".");
        b = La(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
            var f = a[e] || "",
                g = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                if (0 == f[0].length && 0 == g[0].length) break;
                c = Ta(0 == f[1].length ? 0 : parseInt(f[1],
                    10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Ta(0 == f[2].length, 0 == g[2].length) || Ta(f[2], g[2]);
                f = f[3];
                g = g[3]
            } while (0 == c)
        }
        return c
    },
    Ta = function(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
var Va;
a: {
    var Wa = x.navigator;
    if (Wa) {
        var Xa = Wa.userAgent;
        if (Xa) {
            Va = Xa;
            break a
        }
    }
    Va = ""
}

function B(a) {
    return -1 != Va.indexOf(a)
}

function Ya(a) {
    for (var b = RegExp("(\\w[\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"), c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
    return c
};

function Za(a, b) {
    for (var c in a)
        if (b.call(void 0, a[c], c, a)) return !0;
    return !1
}

function $a(a, b) {
    return null !== a && b in a
}
var ab = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

function bb(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
        d = arguments[e];
        for (c in d) a[c] = d[c];
        for (var f = 0; f < ab.length; f++) c = ab[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
    }
};

function cb() {
    return B("Opera")
}

function db() {
    return B("Trident") || B("MSIE")
}

function eb() {
    return B("Firefox") || B("FxiOS")
}

function fb() {
    return B("Safari") && !(gb() || B("Coast") || cb() || B("Edge") || B("Edg/") || B("OPR") || eb() || B("Silk") || B("Android"))
}

function gb() {
    return (B("Chrome") || B("CriOS")) && !B("Edge")
}

function hb() {
    return B("Android") && !(gb() || eb() || cb() || B("Silk"))
}

function ib() {
    function a(e) {
        a: {
            var f = e.length;
            for (var g = "string" === typeof e ? e.split("") : e, h = 0; h < f; h++)
                if (h in g && d.call(void 0, g[h], h, e)) {
                    f = h;
                    break a
                }
            f = -1
        }
        return c[0 > f ? null : "string" === typeof e ? e.charAt(f) : e[f]] || ""
    }
    var b = Va;
    if (db()) return jb(b);
    b = Ya(b);
    var c = {};
    b.forEach(function(e) {
        c[e[0]] = e[1]
    });
    var d = xa($a, c);
    return cb() ? a(["Version", "Opera"]) : B("Edge") ? a(["Edge"]) : B("Edg/") ? a(["Edg"]) : gb() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (b = b[2]) && b[1] || ""
}

function jb(a) {
    var b = /rv: *([\d\.]*)/.exec(a);
    if (b && b[1]) return b[1];
    b = "";
    var c = /MSIE +([\d\.]+)/.exec(a);
    if (c && c[1])
        if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
            if (a && a[1]) switch (a[1]) {
                case "4.0":
                    b = "8.0";
                    break;
                case "5.0":
                    b = "9.0";
                    break;
                case "6.0":
                    b = "10.0";
                    break;
                case "7.0":
                    b = "11.0"
            } else b = "7.0";
            else b = c[1];
    return b
};

function kb() {
    return B("iPhone") && !B("iPod") && !B("iPad")
}

function lb() {
    var a = Va,
        b = "";
    B("Windows") ? (b = /Windows (?:NT|Phone) ([0-9.]+)/, b = (a = b.exec(a)) ? a[1] : "0.0") : kb() || B("iPad") || B("iPod") ? (b = /(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/, b = (a = b.exec(a)) && a[1].replace(/_/g, ".")) : B("Macintosh") ? (b = /Mac OS X ([0-9_.]+)/, b = (a = b.exec(a)) ? a[1].replace(/_/g, ".") : "10") : -1 != Va.toLowerCase().indexOf("kaios") ? (b = /(?:KaiOS)\/(\S+)/i, b = (a = b.exec(a)) && a[1]) : B("Android") ? (b = /Android\s+([^\);]+)(\)|;)/, b = (a = b.exec(a)) && a[1]) : B("CrOS") && (b = /(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/,
        b = (a = b.exec(a)) && a[1]);
    return 0 <= Ua(b || "", 12)
};
var mb = function(a) {
    mb[" "](a);
    return a
};
mb[" "] = qa;
var ob = function(a, b) {
    var c = nb;
    return Object.prototype.hasOwnProperty.call(c, a) ? c[a] : c[a] = b(a)
};
var pb = cb(),
    qb = db(),
    rb = B("Edge"),
    sb = B("Gecko") && !(-1 != Va.toLowerCase().indexOf("webkit") && !B("Edge")) && !(B("Trident") || B("MSIE")) && !B("Edge"),
    tb = -1 != Va.toLowerCase().indexOf("webkit") && !B("Edge"),
    ub;
a: {
    var vb = "",
        wb = function() {
            var a = Va;
            if (sb) return /rv:([^\);]+)(\)|;)/.exec(a);
            if (rb) return /Edge\/([\d\.]+)/.exec(a);
            if (qb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
            if (tb) return /WebKit\/(\S+)/.exec(a);
            if (pb) return /(?:Version)[ \/]?(\S+)/.exec(a)
        }();wb && (vb = wb ? wb[1] : "");
    if (qb) {
        var xb, yb = x.document;
        xb = yb ? yb.documentMode : void 0;
        if (null != xb && xb > parseFloat(vb)) {
            ub = String(xb);
            break a
        }
    }
    ub = vb
}
var zb = ub,
    nb = {},
    Ab = function(a) {
        return ob(a, function() {
            return 0 <= Ua(zb, a)
        })
    };
var Bb = eb();
hb();
var Cb = gb(),
    Db = fb() && !(kb() || B("iPad") || B("iPod"));
var Eb = {},
    Fb = null,
    Gb = function(a, b) {
        var c = ra(a);
        A("array" == c || "object" == c && "number" == typeof a.length, "encodeByteArray takes an array as a parameter");
        void 0 === b && (b = 0);
        if (!Fb) {
            Fb = {};
            c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split("");
            for (var d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; 5 > e; e++) {
                var f = c.concat(d[e].split(""));
                Eb[e] = f;
                for (var g = 0; g < f.length; g++) {
                    var h = f[g],
                        k = Fb[h];
                    void 0 === k ? Fb[h] = g : A(k === g)
                }
            }
        }
        b = Eb[b];
        c = Array(Math.floor(a.length / 3));
        d = b[64] || "";
        for (e = f = 0; f < a.length - 2; f +=
            3) {
            k = a[f];
            var l = a[f + 1];
            h = a[f + 2];
            g = b[k >> 2];
            k = b[(k & 3) << 4 | l >> 4];
            l = b[(l & 15) << 2 | h >> 6];
            h = b[h & 63];
            c[e++] = "" + g + k + l + h
        }
        g = 0;
        h = d;
        switch (a.length - f) {
            case 2:
                g = a[f + 1], h = b[(g & 15) << 2] || d;
            case 1:
                a = a[f], c[e] = "" + b[a >> 2] + b[(a & 3) << 4 | g >> 4] + h + d
        }
        return c.join("")
    };
var Hb = function() {
    this.blockSize = -1
};
var Ib = function(a, b, c) {
    this.blockSize = -1;
    this.N = a;
    this.blockSize = c || a.blockSize || 16;
    this.Od = Array(this.blockSize);
    this.xc = Array(this.blockSize);
    a = b;
    a.length > this.blockSize && (this.N.update(a), a = this.N.digest(), this.N.reset());
    for (c = 0; c < this.blockSize; c++) b = c < a.length ? a[c] : 0, this.Od[c] = b ^ 92, this.xc[c] = b ^ 54;
    this.N.update(this.xc)
};
z(Ib, Hb);
Ib.prototype.reset = function() {
    this.N.reset();
    this.N.update(this.xc)
};
Ib.prototype.update = function(a, b) {
    this.N.update(a, b)
};
Ib.prototype.digest = function() {
    var a = this.N.digest();
    this.N.reset();
    this.N.update(this.Od);
    this.N.update(a);
    return this.N.digest()
};
var Jb = function() {
    this.blockSize = -1;
    this.blockSize = 64;
    this.A = Array(4);
    this.Ie = Array(this.blockSize);
    this.Nb = this.Ra = 0;
    this.reset()
};
z(Jb, Hb);
Jb.prototype.reset = function() {
    this.A[0] = 1732584193;
    this.A[1] = 4023233417;
    this.A[2] = 2562383102;
    this.A[3] = 271733878;
    this.Nb = this.Ra = 0
};
var Kb = function(a, b, c) {
    c || (c = 0);
    var d = Array(16);
    if ("string" === typeof b)
        for (var e = 0; 16 > e; ++e) d[e] = b.charCodeAt(c++) | b.charCodeAt(c++) << 8 | b.charCodeAt(c++) << 16 | b.charCodeAt(c++) << 24;
    else
        for (e = 0; 16 > e; ++e) d[e] = b[c++] | b[c++] << 8 | b[c++] << 16 | b[c++] << 24;
    b = a.A[0];
    c = a.A[1];
    e = a.A[2];
    var f = a.A[3];
    var g = b + (f ^ c & (e ^ f)) + d[0] + 3614090360 & 4294967295;
    b = c + (g << 7 & 4294967295 | g >>> 25);
    g = f + (e ^ b & (c ^ e)) + d[1] + 3905402710 & 4294967295;
    f = b + (g << 12 & 4294967295 | g >>> 20);
    g = e + (c ^ f & (b ^ c)) + d[2] + 606105819 & 4294967295;
    e = f + (g << 17 & 4294967295 | g >>>
        15);
    g = c + (b ^ e & (f ^ b)) + d[3] + 3250441966 & 4294967295;
    c = e + (g << 22 & 4294967295 | g >>> 10);
    g = b + (f ^ c & (e ^ f)) + d[4] + 4118548399 & 4294967295;
    b = c + (g << 7 & 4294967295 | g >>> 25);
    g = f + (e ^ b & (c ^ e)) + d[5] + 1200080426 & 4294967295;
    f = b + (g << 12 & 4294967295 | g >>> 20);
    g = e + (c ^ f & (b ^ c)) + d[6] + 2821735955 & 4294967295;
    e = f + (g << 17 & 4294967295 | g >>> 15);
    g = c + (b ^ e & (f ^ b)) + d[7] + 4249261313 & 4294967295;
    c = e + (g << 22 & 4294967295 | g >>> 10);
    g = b + (f ^ c & (e ^ f)) + d[8] + 1770035416 & 4294967295;
    b = c + (g << 7 & 4294967295 | g >>> 25);
    g = f + (e ^ b & (c ^ e)) + d[9] + 2336552879 & 4294967295;
    f = b + (g << 12 & 4294967295 |
        g >>> 20);
    g = e + (c ^ f & (b ^ c)) + d[10] + 4294925233 & 4294967295;
    e = f + (g << 17 & 4294967295 | g >>> 15);
    g = c + (b ^ e & (f ^ b)) + d[11] + 2304563134 & 4294967295;
    c = e + (g << 22 & 4294967295 | g >>> 10);
    g = b + (f ^ c & (e ^ f)) + d[12] + 1804603682 & 4294967295;
    b = c + (g << 7 & 4294967295 | g >>> 25);
    g = f + (e ^ b & (c ^ e)) + d[13] + 4254626195 & 4294967295;
    f = b + (g << 12 & 4294967295 | g >>> 20);
    g = e + (c ^ f & (b ^ c)) + d[14] + 2792965006 & 4294967295;
    e = f + (g << 17 & 4294967295 | g >>> 15);
    g = c + (b ^ e & (f ^ b)) + d[15] + 1236535329 & 4294967295;
    c = e + (g << 22 & 4294967295 | g >>> 10);
    g = b + (e ^ f & (c ^ e)) + d[1] + 4129170786 & 4294967295;
    b = c + (g <<
        5 & 4294967295 | g >>> 27);
    g = f + (c ^ e & (b ^ c)) + d[6] + 3225465664 & 4294967295;
    f = b + (g << 9 & 4294967295 | g >>> 23);
    g = e + (b ^ c & (f ^ b)) + d[11] + 643717713 & 4294967295;
    e = f + (g << 14 & 4294967295 | g >>> 18);
    g = c + (f ^ b & (e ^ f)) + d[0] + 3921069994 & 4294967295;
    c = e + (g << 20 & 4294967295 | g >>> 12);
    g = b + (e ^ f & (c ^ e)) + d[5] + 3593408605 & 4294967295;
    b = c + (g << 5 & 4294967295 | g >>> 27);
    g = f + (c ^ e & (b ^ c)) + d[10] + 38016083 & 4294967295;
    f = b + (g << 9 & 4294967295 | g >>> 23);
    g = e + (b ^ c & (f ^ b)) + d[15] + 3634488961 & 4294967295;
    e = f + (g << 14 & 4294967295 | g >>> 18);
    g = c + (f ^ b & (e ^ f)) + d[4] + 3889429448 & 4294967295;
    c =
        e + (g << 20 & 4294967295 | g >>> 12);
    g = b + (e ^ f & (c ^ e)) + d[9] + 568446438 & 4294967295;
    b = c + (g << 5 & 4294967295 | g >>> 27);
    g = f + (c ^ e & (b ^ c)) + d[14] + 3275163606 & 4294967295;
    f = b + (g << 9 & 4294967295 | g >>> 23);
    g = e + (b ^ c & (f ^ b)) + d[3] + 4107603335 & 4294967295;
    e = f + (g << 14 & 4294967295 | g >>> 18);
    g = c + (f ^ b & (e ^ f)) + d[8] + 1163531501 & 4294967295;
    c = e + (g << 20 & 4294967295 | g >>> 12);
    g = b + (e ^ f & (c ^ e)) + d[13] + 2850285829 & 4294967295;
    b = c + (g << 5 & 4294967295 | g >>> 27);
    g = f + (c ^ e & (b ^ c)) + d[2] + 4243563512 & 4294967295;
    f = b + (g << 9 & 4294967295 | g >>> 23);
    g = e + (b ^ c & (f ^ b)) + d[7] + 1735328473 & 4294967295;
    e = f + (g << 14 & 4294967295 | g >>> 18);
    g = c + (f ^ b & (e ^ f)) + d[12] + 2368359562 & 4294967295;
    c = e + (g << 20 & 4294967295 | g >>> 12);
    g = b + (c ^ e ^ f) + d[5] + 4294588738 & 4294967295;
    b = c + (g << 4 & 4294967295 | g >>> 28);
    g = f + (b ^ c ^ e) + d[8] + 2272392833 & 4294967295;
    f = b + (g << 11 & 4294967295 | g >>> 21);
    g = e + (f ^ b ^ c) + d[11] + 1839030562 & 4294967295;
    e = f + (g << 16 & 4294967295 | g >>> 16);
    g = c + (e ^ f ^ b) + d[14] + 4259657740 & 4294967295;
    c = e + (g << 23 & 4294967295 | g >>> 9);
    g = b + (c ^ e ^ f) + d[1] + 2763975236 & 4294967295;
    b = c + (g << 4 & 4294967295 | g >>> 28);
    g = f + (b ^ c ^ e) + d[4] + 1272893353 & 4294967295;
    f = b + (g << 11 & 4294967295 |
        g >>> 21);
    g = e + (f ^ b ^ c) + d[7] + 4139469664 & 4294967295;
    e = f + (g << 16 & 4294967295 | g >>> 16);
    g = c + (e ^ f ^ b) + d[10] + 3200236656 & 4294967295;
    c = e + (g << 23 & 4294967295 | g >>> 9);
    g = b + (c ^ e ^ f) + d[13] + 681279174 & 4294967295;
    b = c + (g << 4 & 4294967295 | g >>> 28);
    g = f + (b ^ c ^ e) + d[0] + 3936430074 & 4294967295;
    f = b + (g << 11 & 4294967295 | g >>> 21);
    g = e + (f ^ b ^ c) + d[3] + 3572445317 & 4294967295;
    e = f + (g << 16 & 4294967295 | g >>> 16);
    g = c + (e ^ f ^ b) + d[6] + 76029189 & 4294967295;
    c = e + (g << 23 & 4294967295 | g >>> 9);
    g = b + (c ^ e ^ f) + d[9] + 3654602809 & 4294967295;
    b = c + (g << 4 & 4294967295 | g >>> 28);
    g = f + (b ^ c ^ e) + d[12] +
        3873151461 & 4294967295;
    f = b + (g << 11 & 4294967295 | g >>> 21);
    g = e + (f ^ b ^ c) + d[15] + 530742520 & 4294967295;
    e = f + (g << 16 & 4294967295 | g >>> 16);
    g = c + (e ^ f ^ b) + d[2] + 3299628645 & 4294967295;
    c = e + (g << 23 & 4294967295 | g >>> 9);
    g = b + (e ^ (c | ~f)) + d[0] + 4096336452 & 4294967295;
    b = c + (g << 6 & 4294967295 | g >>> 26);
    g = f + (c ^ (b | ~e)) + d[7] + 1126891415 & 4294967295;
    f = b + (g << 10 & 4294967295 | g >>> 22);
    g = e + (b ^ (f | ~c)) + d[14] + 2878612391 & 4294967295;
    e = f + (g << 15 & 4294967295 | g >>> 17);
    g = c + (f ^ (e | ~b)) + d[5] + 4237533241 & 4294967295;
    c = e + (g << 21 & 4294967295 | g >>> 11);
    g = b + (e ^ (c | ~f)) + d[12] + 1700485571 &
        4294967295;
    b = c + (g << 6 & 4294967295 | g >>> 26);
    g = f + (c ^ (b | ~e)) + d[3] + 2399980690 & 4294967295;
    f = b + (g << 10 & 4294967295 | g >>> 22);
    g = e + (b ^ (f | ~c)) + d[10] + 4293915773 & 4294967295;
    e = f + (g << 15 & 4294967295 | g >>> 17);
    g = c + (f ^ (e | ~b)) + d[1] + 2240044497 & 4294967295;
    c = e + (g << 21 & 4294967295 | g >>> 11);
    g = b + (e ^ (c | ~f)) + d[8] + 1873313359 & 4294967295;
    b = c + (g << 6 & 4294967295 | g >>> 26);
    g = f + (c ^ (b | ~e)) + d[15] + 4264355552 & 4294967295;
    f = b + (g << 10 & 4294967295 | g >>> 22);
    g = e + (b ^ (f | ~c)) + d[6] + 2734768916 & 4294967295;
    e = f + (g << 15 & 4294967295 | g >>> 17);
    g = c + (f ^ (e | ~b)) + d[13] + 1309151649 &
        4294967295;
    c = e + (g << 21 & 4294967295 | g >>> 11);
    g = b + (e ^ (c | ~f)) + d[4] + 4149444226 & 4294967295;
    b = c + (g << 6 & 4294967295 | g >>> 26);
    g = f + (c ^ (b | ~e)) + d[11] + 3174756917 & 4294967295;
    f = b + (g << 10 & 4294967295 | g >>> 22);
    g = e + (b ^ (f | ~c)) + d[2] + 718787259 & 4294967295;
    e = f + (g << 15 & 4294967295 | g >>> 17);
    g = c + (f ^ (e | ~b)) + d[9] + 3951481745 & 4294967295;
    a.A[0] = a.A[0] + b & 4294967295;
    a.A[1] = a.A[1] + (e + (g << 21 & 4294967295 | g >>> 11)) & 4294967295;
    a.A[2] = a.A[2] + e & 4294967295;
    a.A[3] = a.A[3] + f & 4294967295
};
Jb.prototype.update = function(a, b) {
    void 0 === b && (b = a.length);
    for (var c = b - this.blockSize, d = this.Ie, e = this.Ra, f = 0; f < b;) {
        if (0 == e)
            for (; f <= c;) Kb(this, a, f), f += this.blockSize;
        if ("string" === typeof a)
            for (; f < b;) {
                if (d[e++] = a.charCodeAt(f++), e == this.blockSize) {
                    Kb(this, d);
                    e = 0;
                    break
                }
            } else
                for (; f < b;)
                    if (d[e++] = a[f++], e == this.blockSize) {
                        Kb(this, d);
                        e = 0;
                        break
                    }
    }
    this.Ra = e;
    this.Nb += b
};
Jb.prototype.digest = function() {
    var a = Array((56 > this.Ra ? this.blockSize : 2 * this.blockSize) - this.Ra);
    a[0] = 128;
    for (var b = 1; b < a.length - 8; ++b) a[b] = 0;
    var c = 8 * this.Nb;
    for (b = a.length - 8; b < a.length; ++b) a[b] = c & 255, c /= 256;
    this.update(a);
    a = Array(16);
    for (b = c = 0; 4 > b; ++b)
        for (var d = 0; 32 > d; d += 8) a[c++] = this.A[b] >>> d & 255;
    return a
};
var Lb = {};
var Mb = function() {},
    Nb = function(a, b) {
        if (b !== Lb) throw Error("Bad secret");
        this.de = a
    };
u(Nb, Mb);
Nb.prototype.toString = function() {
    return this.de
};
var Ob = new Nb("about:invalid#zTSz", Lb);
var Pb = function(a) {
    this.Df = a
};

function Qb(a) {
    return new Pb(function(b) {
        return b.substr(0, a.length + 1).toLowerCase() === a + ":"
    })
}
var Rb = [Qb("data"), Qb("http"), Qb("https"), Qb("mailto"), Qb("ftp"), new Pb(function(a) {
    return /^[^:]*([/?#]|$)/.test(a)
})];

function Sb(a) {
    var b = void 0 === b ? Rb : b;
    a: {
        b = void 0 === b ? Rb : b;
        for (var c = 0; c < b.length; ++c) {
            var d = b[c];
            if (d instanceof Pb && d.Df(a)) {
                a = new Nb(a, Lb);
                break a
            }
        }
        a = void 0
    }
    return a || Ob
};
var Tb;
var Wb = function(a, b) {
    this.Lc = a === Ub && b || "";
    this.Be = Vb
};
Wb.prototype.wb = !0;
Wb.prototype.Xa = function() {
    return this.Lc
};
Wb.prototype.toString = function() {
    return "Const{" + this.Lc + "}"
};
var Xb = function(a) {
        if (a instanceof Wb && a.constructor === Wb && a.Be === Vb) return a.Lc;
        Ca("expected object of type Const, got '" + a + "'");
        return "type_error:Const"
    },
    Vb = {},
    Ub = {};
var Zb = function(a, b) {
    this.Cc = b === Yb ? a : ""
};
m = Zb.prototype;
m.wb = !0;
m.Xa = function() {
    return this.Cc.toString()
};
m.Ed = !0;
m.mc = function() {
    return 1
};
m.toString = function() {
    return this.Cc.toString()
};
var $b = function(a) {
        if (a instanceof Zb && a.constructor === Zb) return a.Cc;
        Ca("expected object of type SafeUrl, got '" + a + "' of type " + ra(a));
        return "type_error:SafeUrl"
    },
    ac = RegExp('^(?:audio/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-matroska|x-wav|wav|webm)|font/\\w+|image/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon)|video/(?:mpeg|mp4|ogg|webm|quicktime|x-matroska))(?:;\\w+=(?:\\w+|"[\\w;,= ]+"))*$', "i"),
    bc = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
    cc = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
    Yb = {},
    dc = new Zb("about:invalid#zClosurez", Yb);
var ec = {},
    fc = function(a, b, c) {
        this.Bc = c === ec ? a : "";
        this.We = b;
        this.wb = this.Ed = !0
    };
fc.prototype.mc = function() {
    return this.We
};
fc.prototype.Xa = function() {
    return this.Bc.toString()
};
fc.prototype.toString = function() {
    return this.Bc.toString()
};
var gc = function(a) {
        if (a instanceof fc && a.constructor === fc) return a.Bc;
        Ca("expected object of type SafeHtml, got '" + a + "' of type " + ra(a));
        return "type_error:SafeHtml"
    },
    ic = function(a) {
        if (a instanceof fc) return a;
        var b = "object" == typeof a,
            c = null;
        b && a.Ed && (c = a.mc());
        a = b && a.wb ? a.Xa() : String(a);
        Sa.test(a) && (-1 != a.indexOf("&") && (a = a.replace(Ma, "&amp;")), -1 != a.indexOf("<") && (a = a.replace(Na, "&lt;")), -1 != a.indexOf(">") && (a = a.replace(Oa, "&gt;")), -1 != a.indexOf('"') && (a = a.replace(Pa, "&quot;")), -1 != a.indexOf("'") &&
            (a = a.replace(Qa, "&#39;")), -1 != a.indexOf("\x00") && (a = a.replace(Ra, "&#0;")));
        return hc(a, c)
    },
    hc = function(a, b) {
        if (void 0 === Tb) {
            var c = null;
            var d = x.trustedTypes;
            if (d && d.createPolicy) try {
                c = d.createPolicy("goog#html", {
                    createHTML: ya,
                    createScript: ya,
                    createScriptURL: ya
                })
            } catch (e) {
                x.console && x.console.error(e.message)
            }
            Tb = c
        }
        a = (c = Tb) ? c.createHTML(a) : a;
        return new fc(a, b, ec)
    },
    jc = new fc(x.trustedTypes && x.trustedTypes.emptyHTML || "", 0, ec);
var lc = function(a) {
    var b = b || 0;
    return function() {
        return a.apply(this, Array.prototype.slice.call(arguments, 0, b))
    }
};
var mc = function(a) {
    var b = !1,
        c;
    return function() {
        b || (c = a(), b = !0);
        return c
    }
}(function() {
    if ("undefined" === typeof document) return !1;
    var a = document.createElement("div"),
        b = document.createElement("div");
    b.appendChild(document.createElement("div"));
    a.appendChild(b);
    if (!a.firstChild) return !1;
    b = a.firstChild.firstChild;
    a.innerHTML = gc(jc);
    return !b.parentElement
});
var nc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
    oc = function(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        0 > c && (c = a.length);
        var d = a.indexOf("?");
        if (0 > d || d > c) {
            d = c;
            var e = ""
        } else e = a.substring(d + 1, c);
        a = [a.substr(0, d), e, a.substr(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    },
    pc = function(a, b, c) {
        Da(a);
        if (Array.isArray(b)) {
            Ea(b);
            for (var d = 0; d < b.length; d++) pc(a, String(b[d]), c)
        } else null != b &&
            c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    },
    qc = function(a, b) {
        A(0 == Math.max(a.length - (b || 0), 0) % 2, "goog.uri.utils: Key/value lists must be even in length.");
        var c = [];
        for (b = b || 0; b < a.length; b += 2) pc(a[b], a[b + 1], c);
        return c.join("&")
    },
    rc = function(a, b) {
        var c = 2 == arguments.length ? qc(arguments[1], 0) : qc(arguments, 1);
        return oc(a, c)
    },
    sc = function(a, b, c) {
        c = null != c ? "=" + encodeURIComponent(String(c)) : "";
        return oc(a, b + c)
    },
    tc = function(a, b, c, d) {
        for (var e = c.length; 0 <= (b = a.indexOf(c, b)) && b < d;) {
            var f = a.charCodeAt(b -
                1);
            if (38 == f || 63 == f)
                if (f = a.charCodeAt(b + e), !f || 61 == f || 38 == f || 35 == f) return b;
            b += e + 1
        }
        return -1
    },
    uc = /#|$/,
    vc = /[?&]($|#)/,
    wc = function(a, b) {
        for (var c = a.search(uc), d = 0, e, f = []; 0 <= (e = tc(a, d, b, c));) f.push(a.substring(d, e)), d = Math.min(a.indexOf("&", e) + 1 || c, c);
        f.push(a.substr(d));
        return f.join("").replace(vc, "$1")
    },
    xc = function(a) {
        return sc(wc(document.location.href, "hl"), "hl", a)
    };
var yc = {
        Dg: !0
    },
    zc = function() {
        throw Error("Do not instantiate directly");
    };
zc.prototype.dc = null;
zc.prototype.toString = function() {
    return this.content
};
var Ac = function() {
    zc.call(this)
};
z(Ac, zc);
Ac.prototype.ya = yc;
var Bc = function(a) {
    var b = null != a && a.ya === yc;
    b && A(a.constructor === Ac);
    return b
};
var Cc = Object.freeze || function(a) {
    return a
};
var Dc = function(a) {
        if (null != a) switch (a.dc) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    },
    Gc = function(a) {
        return Bc(a) ? a : a instanceof fc ? C(gc(a).toString(), a.mc()) : C(String(String(a)).replace(Ec, Fc), Dc(a))
    },
    C = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.dc = d);
            return c
        }
    }(Ac),
    D = {},
    E = function(a) {
        if (Bc(a)) {
            var b = String;
            a = String(a.content).replace(Hc, "").replace(Ic, "&lt;");
            b = b(a).replace(Jc, Fc)
        } else b = String(a).replace(Ec,
            Fc);
        return b
    },
    Kc = function(a, b) {
        a || (a = b instanceof Function ? b.displayName || b.name || "unknown type name" : b instanceof Object ? b.constructor.displayName || b.constructor.name || Object.prototype.toString.call(b) : null === b ? "null" : typeof b, Ca("expected @param origin of type string, but got " + a + "."))
    },
    Lc = {},
    Mc = function() {
        A(Lc === Lc, "found an incorrect call marker, was an internal function called from the top level?")
    },
    Nc = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\x0B": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    },
    Fc = function(a) {
        return Nc[a]
    },
    Ec = /[\x00\x22\x26\x27\x3c\x3e]/g,
    Jc = /[\x00\x22\x27\x3c\x3e]/g,
    Hc = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
    Ic = /</g;
var Oc = function(a, b) {
    return a + Math.random() * (b - a)
};
var Pc = function(a) {
    var b = document;
    return "string" === typeof a ? b.getElementById(a) : a
};
/*
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
function Qc(a, b, c, d) {
    c = b(c || Rc, d);
    if (sa(c))
        if (c instanceof zc) {
            if (c.ya !== yc) throw Error("Sanitized content was not of kind HTML.");
            b = c.toString();
            c = c.dc;
            d = new Wb(Ub, "Soy SanitizedContent of kind HTML produces SafeHtml-contract-compliant value.");
            Da(Xb(d), "must provide justification");
            A(!/^[\s\xa0]*$/.test(Xb(d)), "must provide non-empty justification");
            b = hc(b, c || null)
        } else Ca("Soy template output is unsafe for use as HTML: " + c), b = ic("zSoyz");
    else b = ic(String(c));
    a = A(a);
    if (mc())
        for (; a.lastChild;) a.removeChild(a.lastChild);
    a.innerHTML = gc(b)
}
var Rc = {};
var Sc = function(a) {
        if (D["oauth2.gsi.soy.common.dialogHeader"]) return D["oauth2.gsi.soy.common.dialogHeader"](null, a);
        var b = '<div class="' + E("dialog-header") + '"><div class="' + E("google-icon") + '">';
        a = D["oauth2.gsi.soy.common.googleIcon"] ? D["oauth2.gsi.soy.common.googleIcon"](null, a) : C('<svg class="' + E("icon") + '" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 48 48"><path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/><path fill="none" d="M2 2h44v44H2z"/></svg>');
        return C(b + a + "</div><p>Continue with Google</p></div>")
    },
    Tc = function(a) {
        if (D["oauth2.gsi.soy.common.dialogFooter"]) var b = D["oauth2.gsi.soy.common.dialogFooter"](null, a);
        else {
            b = C;
            var c = '<div class="' + E("dialog-footer") + '">';
            if (D["oauth2.gsi.soy.common.languageSelector"]) var d = D["oauth2.gsi.soy.common.languageSelector"](null, a);
            else {
                var e = a.fc;
                d = a.languages;
                var f = '<div id="language_selector" class="' + E("language-selector") + '"><div class="' + E("language-selected") + '">';
                if ((e instanceof zc ? e.content : e) &&
                    (d instanceof zc ? d.content : d)) {
                    for (var g = "", h = d.length, k = 0; k < h; k++) {
                        var l = d[k],
                            p = l.code;
                        g += (p && e && p.Af && e.Af ? p.ya !== e.ya ? 0 : p.toString() === e.toString() : p instanceof zc && e instanceof zc ? p.ya != e.ya ? 0 : p.toString() == e.toString() : p == e) ? "" + l.displayName : ""
                    }
                    f += "<div>" + Gc(g) + "</div>"
                }
                f += '<div class="' + E("chevron") + '"></div></div><div id="language_list" class="' + E("language-list") + '">';
                if (d)
                    for (e = d.length, g = 0; g < e; g++) h = d[g], f += '<div class="' + E("language-option") + '" data-languagecode="' + E(h.code) + '">' + Gc(h.displayName) +
                        "</div>";
                d = C(f + "</div></div>")
            }
            c += d;
            D["oauth2.gsi.soy.common.footerMenu"] ? a = D["oauth2.gsi.soy.common.footerMenu"](null, a) : (a = '<ul class="' + E("footer-menu") + '"><li class="' + E("menu-item") + '"><a class="' + E("menu-content") + '" href="#">', a = a + 'Help</a></li><li class="' + (E("menu-item") + '"><a class="' + E("menu-content") + '" href="#">'), a = a + 'Privacy</a></li><li class="' + (E("menu-item") + '"><a class="' + E("menu-content") + '" href="#">'), a = C(a + "Terms</a></li></ul>"));
            b = b(c + a + "</div>")
        }
        return b
    };
var Uc = function(a, b) {
    var c = a.origin;
    Mc();
    if (D["oauth2.gsi.soy.itp.newgrant.dialog"]) b = D["oauth2.gsi.soy.itp.newgrant.dialog"]({
        origin: c
    }, b);
    else {
        Kc("string" === typeof c, c);
        a = C;
        var d = '<div class="' + E("dialog-container dialog-modal") + '"><div class="' + E("dialog inflated-dialog") + '"><div class="' + E("dialog-body") + '">' + Sc(b) + '<div class="' + E("dialog-content") + '">';
        if (D["oauth2.gsi.soy.itp.newgrant.title"]) var e = D["oauth2.gsi.soy.itp.newgrant.title"](null, b);
        else e = '<h1 class="' + E("title") + '">', e = C(e + "You'll need to give Safari permission to continue</h1>");
        d += e;
        Mc();
        D["oauth2.gsi.soy.itp.newgrant.consentForm"] ? c = D["oauth2.gsi.soy.itp.newgrant.consentForm"]({
            origin: c
        }, b) : (Kc("string" === typeof c, c), e = '<div class="' + E("consent-form") + '"><p class="' + E("consent-text") + '">', c = "In order to continue with your Google Account, Safari will ask if it's ok for Google to use cookies on " + Gc(c) + ".", c = C(e + c + "</p></div>"));
        c = d + c;
        D["oauth2.gsi.soy.itp.newgrant.buttonGroup"] ? d = D["oauth2.gsi.soy.itp.newgrant.buttonGroup"](null, b) : (d = '<div class="' + E("button-group") + '"><div class="' +
            E("button button-cancel") + '" id="confirm_no">', d = d + 'Cancel</div><div class="' + (E("button button-confirm") + '" id="confirm_yes">'), d = C(d + "Continue</div></div>"));
        b = a(c + d + "</div></div>" + Tc(b) + "</div></div>")
    }
    return b
};
var Vc = function(a, b) {
    var c = a.origin;
    Mc();
    if (D["oauth2.gsi.soy.itp.regrant.dialog"]) b = D["oauth2.gsi.soy.itp.regrant.dialog"]({
        origin: c
    }, b);
    else {
        Kc("string" === typeof c, c);
        a = C;
        var d = '<div class="' + E("dialog-container dialog-modal") + '"><div class="' + E("dialog") + '"><div class="' + E("dialog-body") + '">' + Sc(b) + '<div class="' + E("dialog-content") + '">';
        Mc();
        if (D["oauth2.gsi.soy.itp.regrant.title"]) var e = D["oauth2.gsi.soy.itp.regrant.title"]({
            origin: c
        }, b);
        else Kc("string" === typeof c, c), e = '<h1 class="' + E("title") +
            '">', c = "Do you still want Safari to let Google use cookies on " + Gc(c) + "?", e = C(e + c + "</h1>");
        d += e;
        D["oauth2.gsi.soy.itp.regrant.buttonGroup"] ? e = D["oauth2.gsi.soy.itp.regrant.buttonGroup"](null, b) : (e = '<div class="' + E("button-group button-group-high") + '"><div class="' + E("button button-cancel") + '" id="confirm_no">', e = e + 'No thanks</div><div class="' + (E("button button-confirm") + '" id="confirm_yes">'), e = C(e + "Yes</div></div>"));
        b = a(d + e + "</div></div>" + Tc(b) + "</div></div>")
    }
    return b
};

function Wc(a) {
    a && "function" == typeof a.U && a.U()
};
var Xc = function() {
    this.Ca = this.Ca;
    this.ra = this.ra
};
Xc.prototype.Ca = !1;
Xc.prototype.U = function() {
    this.Ca || (this.Ca = !0, this.da())
};
var Yc = function(a, b) {
    a.Ca ? b() : (a.ra || (a.ra = []), a.ra.push(b))
};
Xc.prototype.da = function() {
    if (this.ra)
        for (; this.ra.length;) this.ra.shift()()
};
var Zc = function(a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = this.cb = !1
};
Zc.prototype.stopPropagation = function() {
    this.cb = !0
};
Zc.prototype.preventDefault = function() {
    this.defaultPrevented = !0
};
var $c = function() {
    if (!x.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
        b = Object.defineProperty({}, "passive", {
            get: function() {
                a = !0
            }
        });
    try {
        x.addEventListener("test", qa, b), x.removeEventListener("test", qa, b)
    } catch (c) {}
    return a
}();
var ad;
ad = tb ? "webkitTransitionEnd" : "transitionend";
var bd = function(a, b) {
    Zc.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
    this.key = "";
    this.charCode = this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.Va = null;
    a && this.V(a, b)
};
z(bd, Zc);
var cd = Cc({
    2: "touch",
    3: "pen",
    4: "mouse"
});
bd.prototype.V = function(a, b) {
    var c = this.type = a.type,
        d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    if (b = a.relatedTarget) {
        if (sb) {
            a: {
                try {
                    mb(b.nodeName);
                    var e = !0;
                    break a
                } catch (f) {}
                e = !1
            }
            e || (b = null)
        }
    } else "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
    this.relatedTarget = b;
    d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY =
        d.screenY || 0) : (this.offsetX = tb || void 0 !== a.offsetX ? a.offsetX : a.layerX, this.offsetY = tb || void 0 !== a.offsetY ? a.offsetY : a.layerY, this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId =
        a.pointerId || 0;
    this.pointerType = "string" === typeof a.pointerType ? a.pointerType : cd[a.pointerType] || "";
    this.state = a.state;
    this.Va = a;
    a.defaultPrevented && bd.sa.preventDefault.call(this)
};
bd.prototype.stopPropagation = function() {
    bd.sa.stopPropagation.call(this);
    this.Va.stopPropagation ? this.Va.stopPropagation() : this.Va.cancelBubble = !0
};
bd.prototype.preventDefault = function() {
    bd.sa.preventDefault.call(this);
    var a = this.Va;
    a.preventDefault ? a.preventDefault() : a.returnValue = !1
};
var dd = "closure_listenable_" + (1E6 * Math.random() | 0);
var ed = 0;
var fd = function(a, b, c, d, e) {
        this.listener = a;
        this.Hb = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.m = e;
        this.key = ++ed;
        this.hb = this.qb = !1
    },
    gd = function(a) {
        a.hb = !0;
        a.listener = null;
        a.Hb = null;
        a.src = null;
        a.m = null
    };
var hd = function(a) {
    this.src = a;
    this.D = {};
    this.nb = 0
};
hd.prototype.add = function(a, b, c, d, e) {
    var f = a.toString();
    a = this.D[f];
    a || (a = this.D[f] = [], this.nb++);
    var g = id(a, b, d, e); - 1 < g ? (b = a[g], c || (b.qb = !1)) : (b = new fd(b, this.src, f, !!d, e), b.qb = c, a.push(b));
    return b
};
hd.prototype.remove = function(a, b, c, d) {
    a = a.toString();
    if (!(a in this.D)) return !1;
    var e = this.D[a];
    b = id(e, b, c, d);
    return -1 < b ? (gd(e[b]), A(null != e.length), Array.prototype.splice.call(e, b, 1), 0 == e.length && (delete this.D[a], this.nb--), !0) : !1
};
var jd = function(a, b) {
    var c = b.type;
    c in a.D && Ka(a.D[c], b) && (gd(b), 0 == a.D[c].length && (delete a.D[c], a.nb--))
};
hd.prototype.nc = function(a, b, c, d) {
    a = this.D[a.toString()];
    var e = -1;
    a && (e = id(a, b, c, d));
    return -1 < e ? a[e] : null
};
hd.prototype.hasListener = function(a, b) {
    var c = void 0 !== a,
        d = c ? a.toString() : "",
        e = void 0 !== b;
    return Za(this.D, function(f) {
        for (var g = 0; g < f.length; ++g)
            if (!(c && f[g].type != d || e && f[g].capture != b)) return !0;
        return !1
    })
};
var id = function(a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.hb && f.listener == b && f.capture == !!c && f.m == d) return e
    }
    return -1
};
var kd = "closure_lm_" + (1E6 * Math.random() | 0),
    ld = {},
    md = 0,
    F = function(a, b, c, d, e) {
        if (d && d.once) return nd(a, b, c, d, e);
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) F(a, b[f], c, d, e);
            return null
        }
        c = od(c);
        return a && a[dd] ? a.O(b, c, sa(d) ? !!d.capture : !!d, e) : pd(a, b, c, !1, d, e)
    },
    pd = function(a, b, c, d, e, f) {
        if (!b) throw Error("Invalid event type");
        var g = sa(e) ? !!e.capture : !!e,
            h = qd(a);
        h || (a[kd] = h = new hd(a));
        c = h.add(b, c, d, g, f);
        if (c.Hb) return c;
        d = rd();
        c.Hb = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener) $c || (e = g), void 0 === e && (e = !1), a.addEventListener(b.toString(), d, e);
        else if (a.attachEvent) a.attachEvent(sd(b.toString()), d);
        else if (a.addListener && a.removeListener) A("change" === b, "MediaQueryList only has a change event"), a.addListener(d);
        else throw Error("addEventListener and attachEvent are unavailable.");
        md++;
        return c
    },
    rd = function() {
        var a = td,
            b = function(c) {
                return a.call(b.src, b.listener, c)
            };
        return b
    },
    nd = function(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (var f = 0; f < b.length; f++) nd(a, b[f], c, d, e);
            return null
        }
        c = od(c);
        return a && a[dd] ?
            a.M.add(String(b), c, !0, sa(d) ? !!d.capture : !!d, e) : pd(a, b, c, !0, d, e)
    },
    ud = function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) ud(a, b[f], c, d, e);
        else d = sa(d) ? !!d.capture : !!d, c = od(c), a && a[dd] ? a.ob(b, c, d, e) : a && (a = qd(a)) && (b = a.nc(b, c, d, e)) && vd(b)
    },
    vd = function(a) {
        if ("number" !== typeof a && a && !a.hb) {
            var b = a.src;
            if (b && b[dd]) jd(b.M, a);
            else {
                var c = a.type,
                    d = a.Hb;
                b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(sd(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                md--;
                (c = qd(b)) ? (jd(c, a), 0 == c.nb && (c.src = null, b[kd] = null)) : gd(a)
            }
        }
    },
    sd = function(a) {
        return a in ld ? ld[a] : ld[a] = "on" + a
    },
    td = function(a, b) {
        if (a.hb) a = !0;
        else {
            b = new bd(b, this);
            var c = a.listener,
                d = a.m || a.src;
            a.qb && vd(a);
            a = c.call(d, b)
        }
        return a
    },
    qd = function(a) {
        a = a[kd];
        return a instanceof hd ? a : null
    },
    wd = "__closure_events_fn_" + (1E9 * Math.random() >>> 0),
    od = function(a) {
        A(a, "Listener can not be null.");
        if ("function" === typeof a) return a;
        A(a.handleEvent, "An object listener must have handleEvent method.");
        a[wd] || (a[wd] =
            function(b) {
                return a.handleEvent(b)
            });
        return a[wd]
    };
var xd = function() {
    this.Cb = new Set;
    this.rd = !1
};
xd.prototype.O = function(a, b, c) {
    a = F(a, b, c);
    this.Cb.add(a);
    return a
};
xd.prototype.ob = function(a) {
    vd(a);
    this.Cb.delete(a)
};
xd.prototype.U = function() {
    this.rd || (this.Cb.forEach(function(a) {
        vd(a)
    }), this.Cb.clear(), this.rd = !0)
};
var yd = function() {
    xd.call(this);
    this.tb = null;
    this.cc = !1
};
u(yd, xd);
var zd = function(a, b) {
    if (a.tb) throw Error("Component already rendered.");
    a.cc = !1;
    a.tb = b
};
yd.prototype.U = function() {
    if (!this.cc) {
        xd.prototype.U.call(this);
        for (var a = this.tb, b; b = a.firstChild;) a.removeChild(b);
        this.tb = null;
        this.cc = !0
    }
};

function Ad(a) {
    if (a instanceof Mb)
        if (a instanceof Nb) a = a.de;
        else throw Error("Unexpected type when unwrapping SafeUrl");
    else a = $b(a);
    return a
};
/*

 Copyright 2021 The Safevalues Authors
 SPDX-License-Identifier: Apache-2.0
*/
function Bd(a, b) {
    a.href = Ad(b)
};
var Cd = function() {
    xd.call(this);
    this.la = this.Jb = this.Ib = null;
    this.fe = this.Rd = !1
};
u(Cd, xd);
Cd.prototype.register = function(a, b) {
    var c = this;
    if (this.fe) throw Error("LanguageSelectorModel is already registered.");
    this.fe = !0;
    this.Jb = a;
    this.la = b;
    this.Qd = this.O(this.Jb, "click", function() {
        return Dd(c)
    })
};
var Dd = function(a) {
        a.la.style.visibility = "visible";
        a.la.style.opacity = 1;
        a.ob(a.Qd);
        a.Gf = a.O(document, "mouseup", function(b) {
            return Ed(a, b)
        })
    },
    Ed = function(a, b) {
        a.Ib = b.target.getAttribute("data-languagecode");
        if (null != a.Ib || b.target != a.la) a.ob(a.Gf), a.Ff = a.O(a.la, ad, function() {
            return Fd(a)
        }), a.la.style.opacity = 0
    },
    Fd = function(a) {
        a.ob(a.Ff);
        a.la.style.visibility = "hidden";
        a.Qd = a.O(a.Jb, "click", function() {
            return Dd(a)
        });
        if (null != a.Ib) {
            var b = xc(a.Ib);
            Bd(document.location, Sb(b))
        }
    };
Cd.prototype.U = function() {
    this.Rd || (xd.prototype.U.call(this), this.la = this.Jb = null, this.Rd = !0)
};
var Gd = function(a) {
    var b = a.origin,
        c = a.fc;
    a = a.languages;
    yd.call(this);
    this.j = b;
    this.od = c;
    this.Sd = a;
    this.Nd = !1
};
u(Gd, yd);
Gd.prototype.Tf = function(a, b, c) {
    zd(this, a);
    Qc(a, Uc, {
        origin: this.j
    }, {
        fc: this.od,
        languages: this.Sd
    });
    a = Pc("confirm_yes");
    this.O(a, "click", function() {
        (void 0 == document.hasStorageAccess ? Promise.resolve() : document.requestStorageAccess()).then(function() {
            return b()
        }, function() {
            return c()
        })
    });
    a = Pc("confirm_no");
    this.O(a, "click", function() {
        return c()
    });
    Hd(this)
};
Gd.prototype.Uf = function(a, b, c) {
    zd(this, a);
    Qc(a, Vc, {
        origin: this.j
    }, {
        fc: this.od,
        languages: this.Sd
    });
    a = Pc("confirm_yes");
    this.O(a, "click", function() {
        return b()
    });
    a = Pc("confirm_no");
    this.O(a, "click", function() {
        return c()
    });
    Hd(this)
};
var Hd = function(a) {
    void 0 == a.Ab && (a.Ab = new Cd);
    var b = Pc("language_selector"),
        c = Pc("language_list");
    a.Ab.register(b, c)
};
Gd.prototype.U = function() {
    this.Nd || (yd.prototype.U.call(this), void 0 != this.Ab && this.Ab.U(), this.Nd = !0)
};
var Id, Jd, Kd = void 0,
    Ld = function(a) {
        try {
            return x.JSON.parse.call(x.JSON, a)
        } catch (b) {
            return !1
        }
    },
    Md = function(a) {
        return Object.prototype.toString.call(a)
    },
    Nd = Md(0),
    Od = Md(new Date(0)),
    Pd = Md(!0),
    Qd = Md(""),
    Rd = Md({}),
    Sd = Md([]),
    Td = function(a, b) {
        if (b)
            for (var c = 0, d = b.length; c < d; ++c)
                if (a === b[c]) throw new TypeError("Converting circular structure to JSON");
        d = typeof a;
        if ("undefined" !== d) {
            c = Array.prototype.slice.call(b || [], 0);
            c[c.length] = a;
            b = [];
            var e = Md(a);
            if (null != a && "function" === typeof a.toJSON && (Object.prototype.hasOwnProperty.call(a,
                    "toJSON") || (e !== Sd || a.constructor !== Array && a.constructor !== Object) && (e !== Rd || a.constructor !== Array && a.constructor !== Object) && e !== Qd && e !== Nd && e !== Pd && e !== Od)) return Td(a.toJSON.call(a), c);
            if (null == a) b[b.length] = "null";
            else if (e === Nd) a = Number(a), isNaN(a) || isNaN(a - a) ? a = "null" : -0 === a && 0 > 1 / a && (a = "-0"), b[b.length] = String(a);
            else if (e === Pd) b[b.length] = String(!!Number(a));
            else {
                if (e === Od) return Td(a.toISOString.call(a), c);
                if (e === Sd && Md(a.length) === Nd) {
                    b[b.length] = "[";
                    var f = 0;
                    for (d = Number(a.length) >> 0; f < d; ++f) f &&
                        (b[b.length] = ","), b[b.length] = Td(a[f], c) || "null";
                    b[b.length] = "]"
                } else if (e == Qd && Md(a.length) === Nd) {
                    b[b.length] = '"';
                    f = 0;
                    for (c = Number(a.length) >> 0; f < c; ++f) d = String.prototype.charAt.call(a, f), e = String.prototype.charCodeAt.call(a, f), b[b.length] = "\b" === d ? "\\b" : "\f" === d ? "\\f" : "\n" === d ? "\\n" : "\r" === d ? "\\r" : "\t" === d ? "\\t" : "\\" === d || '"' === d ? "\\" + d : 31 >= e ? "\\u" + (e + 65536).toString(16).substr(1) : 32 <= e && 65535 >= e ? d : "\ufffd";
                    b[b.length] = '"'
                } else if ("object" === d) {
                    b[b.length] = "{";
                    d = 0;
                    for (f in a) Object.prototype.hasOwnProperty.call(a,
                        f) && (e = Td(a[f], c), void 0 !== e && (d++ && (b[b.length] = ","), b[b.length] = Td(f), b[b.length] = ":", b[b.length] = e));
                    b[b.length] = "}"
                } else return
            }
            return b.join("")
        }
    },
    Ud = /[\0-\x07\x0b\x0e-\x1f]/,
    Vd = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*[\0-\x1f]/,
    Wd = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\[^\\\/"bfnrtu]/,
    Xd = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\u([0-9a-fA-F]{0,3}[^0-9a-fA-F])/,
    Yd = /"([^\0-\x1f\\"]|\\[\\\/"bfnrt]|\\u[0-9a-fA-F]{4})*"/g,
    Zd = /-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?/g,
    $d = /[ \t\n\r]+/g,
    ae = /[^"]:/,
    be = /""/g,
    ce = /true|false|null/g,
    de = /00/,
    ee = /[\{]([^0\}]|0[^:])/,
    fe = /(^|\[)[,:]|[,:](\]|\}|[,:]|$)/,
    ge = /[^\[,:][\[\{]/,
    he = /^(\{|\}|\[|\]|,|:|0)+/,
    ie = /\u2028/g,
    je = /\u2029/g,
    ke = function(a) {
        a = String(a);
        if (Ud.test(a) || Vd.test(a) || Wd.test(a) || Xd.test(a)) return !1;
        var b = a.replace(Yd, '""');
        b = b.replace(Zd, "0");
        b = b.replace($d, "");
        if (ae.test(b)) return !1;
        b = b.replace(be, "0");
        b = b.replace(ce, "0");
        if (de.test(b) || ee.test(b) || fe.test(b) || ge.test(b) || !b || (b = b.replace(he, ""))) return !1;
        a = a.replace(ie, "\\u2028").replace(je,
            "\\u2029");
        b = void 0;
        try {
            b = Kd ? [Ld(a)] : eval("(function (var_args) {\n  return Array.prototype.slice.call(arguments, 0);\n})(\n" + a + "\n)")
        } catch (c) {
            return !1
        }
        return b && 1 === b.length ? b[0] : !1
    },
    le = function() {
        var a = ((x.document || {}).scripts || []).length;
        if ((void 0 === Id || void 0 === Kd || Jd !== a) && -1 !== Jd) {
            Id = Kd = !1;
            Jd = -1;
            try {
                try {
                    Kd = !!x.JSON && '{"a":[3,true,"1970-01-01T00:00:00.000Z"]}' === x.JSON.stringify.call(x.JSON, {
                        a: [3, !0, new Date(0)],
                        c: function() {}
                    }) && !0 === Ld("true") && 3 === Ld('[{"a":3}]')[0].a
                } catch (b) {}
                Id = Kd &&
                    !Ld("[00]") && !Ld('"\u0007"') && !Ld('"\\0"') && !Ld('"\\v"')
            } finally {
                Jd = a
            }
        }
    },
    me = !Date.prototype.toISOString || "function" !== typeof Date.prototype.toISOString || "1970-01-01T00:00:00.000Z" !== (new Date(0)).toISOString(),
    ne = function() {
        var a = Date.prototype.getUTCFullYear.call(this);
        return [0 > a ? "-" + String(1E6 - a).substr(1) : 9999 >= a ? String(1E4 + a).substr(1) : "+" + String(1E6 + a).substr(1), "-", String(101 + Date.prototype.getUTCMonth.call(this)).substr(1), "-", String(100 + Date.prototype.getUTCDate.call(this)).substr(1), "T",
            String(100 + Date.prototype.getUTCHours.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCMinutes.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCSeconds.call(this)).substr(1), ".", String(1E3 + Date.prototype.getUTCMilliseconds.call(this)).substr(1), "Z"
        ].join("")
    };
Date.prototype.toISOString = me ? ne : Date.prototype.toISOString;
var oe, pe = !1,
    G = function(a) {
        try {
            pe && window.console && window.console.log && window.console.log(a)
        } catch (b) {}
    },
    qe = function(a, b) {
        if (!a) return -1;
        if (a.indexOf) return a.indexOf(b, void 0);
        for (var c = 0, d = a.length; c < d; c++)
            if (a[c] === b) return c;
        return -1
    },
    I = function(a, b) {
        function c() {}
        if (!a) throw Error("Child class cannot be empty.");
        if (!b) throw Error("Parent class cannot be empty.");
        c.prototype = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a
    },
    re = function(a) {
        return "[object Function]" === Object.prototype.toString.call(a)
    },
    se = function(a) {
        var b = [],
            c;
        for (c in a)
            if (a.hasOwnProperty(c)) {
                var d = a[c];
                if (null === d || void 0 === d) d = "";
                b.push(encodeURIComponent(c) + "=" + encodeURIComponent(d))
            }
        return b.join("&")
    },
    te = function(a) {
        var b = window.location.hash;
        a = new RegExp("[&#]" + a + "=([^&]*)");
        b = decodeURIComponent(b);
        b = a.exec(b);
        return null == b ? "" : b[1].replace(/\+/g, " ")
    },
    ue = function(a, b, c) {
        if (a.addEventListener) a.addEventListener(b, c, !1);
        else if (a.attachEvent) a.attachEvent("on" + b, c);
        else throw Error("Add event handler for " + b + " failed.");
    },
    ve = function(a, b) {
        a = (a || "").split(" ");
        b = (b || "").split(" ");
        for (var c = 0; c < b.length; c++)
            if (b[c] && 0 > qe(a, b[c])) return !1;
        return !0
    },
    we = function() {
        if ("undefined" != typeof oe) return oe;
        a: {
            try {
                if (window.localStorage) {
                    var a = window.localStorage;
                    break a
                }
            } catch (b) {}
            a = void 0
        }
        if (!a) return oe = !1;
        try {
            a.setItem("test", "test"), a.removeItem("test"), oe = !0
        } catch (b) {
            oe = !1
        }
        return oe
    },
    xe = function() {
        var a = navigator.userAgent.toLowerCase();
        return -1 != a.indexOf("msie") && 8 == parseInt(a.split("msie")[1], 10)
    },
    ye = function() {
        return Object.hasOwnProperty.call(window,
            "ActiveXObject") && !window.ActiveXObject
    },
    ze = function() {
        var a = navigator.userAgent.toLowerCase();
        return 0 > a.indexOf("edge/") && (-1 < a.indexOf("chrome/") || -1 < a.indexOf("crios/"))
    },
    Ae = function() {
        var a = navigator.userAgent,
            b;
        if (b = !!a && -1 != a.indexOf("CriOS")) b = -1, (a = a.match(/CriOS\/(\d+)/)) && a[1] && (b = parseInt(a[1], 10) || -1), b = 48 > b;
        return b
    },
    Be = function() {
        var a = navigator.userAgent.toLowerCase();
        return -1 < a.indexOf("safari/") && 0 > a.indexOf("chrome/") && 0 > a.indexOf("crios/") && 0 > a.indexOf("android")
    },
    J = window.JSON,
    Ce = function(a) {
        this.Tc = a || [];
        this.P = {}
    };
Ce.prototype.addEventListener = function(a, b) {
    if (!(0 <= qe(this.Tc, a))) throw Error("Unrecognized event type: " + a);
    if (!re(b)) throw Error("The listener for event '" + a + "' is not a function.");
    this.P[a] || (this.P[a] = []);
    0 > qe(this.P[a], b) && this.P[a].push(b)
};
Ce.prototype.removeEventListener = function(a, b) {
    if (!(0 <= qe(this.Tc, a))) throw Error("Unrecognized event type: " + a);
    re(b) && this.P[a] && this.P[a].length && (b = qe(this.P[a], b), 0 <= b && this.P[a].splice(b, 1))
};
Ce.prototype.dispatchEvent = function(a) {
    var b = a.type;
    if (!(b && 0 <= qe(this.Tc, b))) throw Error("Failed to dispatch unrecognized event type: " + b);
    if (this.P[b] && this.P[b].length)
        for (var c = 0, d = this.P[b].length; c < d; c++) this.P[b][c](a)
};
J = {
    parse: function(a) {
        a = "[" + String(a) + "]"; - 1 === Jd ? a = !1 : (le(), a = (Id ? Ld : ke)(a));
        if (!1 === a || 1 !== a.length) throw new SyntaxError("JSON parsing failed.");
        return a[0]
    },
    stringify: function(a) {
        -1 !== Jd ? (le(), a = Kd ? x.JSON.stringify.call(x.JSON, a) : Td(a)) : a = void 0;
        return a
    }
};
var De = function(a) {
    this.hd = a
};
var Ee = function(a, b, c) {
    this.$a = a;
    this.Me = b;
    this.vb = c || [];
    this.wa = new Map
};
m = Ee.prototype;
m.fg = function(a, b) {
    for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
    this.wa.set(this.zd(c), [new De(a)])
};
m.xd = function(a) {
    for (var b = [], c = 0; c < arguments.length; ++c) b[c - 0] = arguments[c];
    b = this.zd(b);
    return this.wa.has(b) ? this.wa.get(b) : void 0
};
m.mf = function(a) {
    for (var b = [], c = 0; c < arguments.length; ++c) b[c - 0] = arguments[c];
    return (b = this.xd(b)) && b.length ? b[0] : void 0
};
m.clear = function() {
    this.wa.clear()
};
m.zd = function(a) {
    for (var b = [], c = 0; c < arguments.length; ++c) b[c - 0] = arguments[c];
    return b ? b.join(",") : "key"
};
var Fe = function(a, b) {
    Ee.call(this, a, 3, b)
};
u(Fe, Ee);
Fe.prototype.Fd = function(a) {
    for (var b = [], c = 0; c < arguments.length; ++c) b[c - 0] = arguments[c];
    this.yb(1, b)
};
Fe.prototype.yb = function(a, b) {
    for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
    d = 0;
    var e = this.mf(c);
    e && (d = e.hd);
    this.fg(d + a, c)
};
var K = function() {
    Xc.call(this);
    this.M = new hd(this);
    this.Ce = this;
    this.Ac = null
};
z(K, Xc);
K.prototype[dd] = !0;
m = K.prototype;
m.addEventListener = function(a, b, c, d) {
    F(this, a, b, c, d)
};
m.removeEventListener = function(a, b, c, d) {
    ud(this, a, b, c, d)
};
m.dispatchEvent = function(a) {
    Ge(this);
    var b = this.Ac;
    if (b) {
        var c = [];
        for (var d = 1; b; b = b.Ac) c.push(b), A(1E3 > ++d, "infinite loop")
    }
    b = this.Ce;
    d = a.type || a;
    if ("string" === typeof a) a = new Zc(a, b);
    else if (a instanceof Zc) a.target = a.target || b;
    else {
        var e = a;
        a = new Zc(d, b);
        bb(a, e)
    }
    e = !0;
    if (c)
        for (var f = c.length - 1; !a.cb && 0 <= f; f--) {
            var g = a.currentTarget = c[f];
            e = He(g, d, !0, a) && e
        }
    a.cb || (g = a.currentTarget = b, e = He(g, d, !0, a) && e, a.cb || (e = He(g, d, !1, a) && e));
    if (c)
        for (f = 0; !a.cb && f < c.length; f++) g = a.currentTarget = c[f], e = He(g, d, !1, a) &&
            e;
    return e
};
m.da = function() {
    K.sa.da.call(this);
    if (this.M) {
        var a = this.M,
            b = 0,
            c;
        for (c in a.D) {
            for (var d = a.D[c], e = 0; e < d.length; e++) ++b, gd(d[e]);
            delete a.D[c];
            a.nb--
        }
    }
    this.Ac = null
};
m.O = function(a, b, c, d) {
    Ge(this);
    return this.M.add(String(a), b, !1, c, d)
};
m.ob = function(a, b, c, d) {
    this.M.remove(String(a), b, c, d)
};
var He = function(a, b, c, d) {
    b = a.M.D[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
        var g = b[f];
        if (g && !g.hb && g.capture == c) {
            var h = g.listener,
                k = g.m || g.src;
            g.qb && jd(a.M, g);
            e = !1 !== h.call(k, d) && e
        }
    }
    return e && !d.defaultPrevented
};
K.prototype.nc = function(a, b, c, d) {
    return this.M.nc(String(a), b, c, d)
};
K.prototype.hasListener = function(a, b) {
    return this.M.hasListener(void 0 !== a ? String(a) : void 0, b)
};
var Ge = function(a) {
    A(a.M, "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?")
};
var Ie = function(a, b) {
    K.call(this);
    this.zb = a || 1;
    this.mb = b || x;
    this.dd = wa(this.rg, this);
    this.Vd = Date.now()
};
z(Ie, K);
m = Ie.prototype;
m.enabled = !1;
m.l = null;
m.setInterval = function(a) {
    this.zb = a;
    this.l && this.enabled ? (this.stop(), this.start()) : this.l && this.stop()
};
m.rg = function() {
    if (this.enabled) {
        var a = Date.now() - this.Vd;
        0 < a && a < .8 * this.zb ? this.l = this.mb.setTimeout(this.dd, this.zb - a) : (this.l && (this.mb.clearTimeout(this.l), this.l = null), this.dispatchEvent("tick"), this.enabled && (this.stop(), this.start()))
    }
};
m.start = function() {
    this.enabled = !0;
    this.l || (this.l = this.mb.setTimeout(this.dd, this.zb), this.Vd = Date.now())
};
m.stop = function() {
    this.enabled = !1;
    this.l && (this.mb.clearTimeout(this.l), this.l = null)
};
m.da = function() {
    Ie.sa.da.call(this);
    this.stop();
    delete this.mb
};
var Je = function(a, b, c) {
    if ("function" === typeof a) c && (a = wa(a, c));
    else if (a && "function" == typeof a.handleEvent) a = wa(a.handleEvent, a);
    else throw Error("Invalid listener argument");
    return 2147483647 < Number(b) ? -1 : x.setTimeout(a, b || 0)
};
var Ke = function(a) {
    this.pg = a;
    this.Eb = new Map;
    this.Ye = new Set;
    this.vc = 0;
    this.zf = 100;
    this.kf = 3E4;
    this.s = new Ie(this.kf);
    this.s.O("tick", this.Hc, !1, this);
    this.bg = !1
};
m = Ke.prototype;
m.Hc = function() {
    var a = this.Eb.values();
    a = [].concat(a instanceof Array ? a : fa(t(a))).filter(function(b) {
        return b.wa.size
    });
    a.length && this.pg.flush(a, this.bg);
    Le(a);
    this.vc = 0;
    this.s.enabled && this.s.stop()
};
m.De = function(a, b) {
    for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
    this.Eb.has(a) || this.Eb.set(a, new Fe(a, c))
};
m.oc = function(a) {
    return this.Ye.has(a) ? void 0 : this.Eb.get(a)
};
m.Fd = function(a, b) {
    for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
    this.yb.apply(this, [a, 1].concat(c instanceof Array ? c : fa(t(c))))
};
m.yb = function(a, b, c) {
    for (var d = [], e = 2; e < arguments.length; ++e) d[e - 2] = arguments[e];
    (e = this.oc(a)) && e instanceof Fe && (e.yb(b, d), this.s.enabled || this.s.start(), this.vc++, this.vc >= this.zf && this.Hc())
};
var Le = function(a) {
    for (var b = 0; b < a.length; b++) a[b].clear()
};
var Me = function(a) {
    this.$a = "/client_streamz/google_sign_in_web_client/idpiframe/cookie_blocked_count";
    this.Kc = a;
    this.Kc.De(this.$a, {
        td: 3,
        sd: "browser"
    }, {
        td: 3,
        sd: "browser_version"
    })
};
Me.prototype.tc = function(a, b) {
    this.Kc.Fd(this.$a, a, b)
};
Me.prototype.oc = function() {
    return this.Kc.oc(this.$a)
};
A(!0);
var Ne = "function" === typeof Uint8Array;

function Oe(a, b, c) {
    if (null != a) return "object" === typeof a ? Ne && a instanceof Uint8Array ? c(a) : Pe(a, b, c) : b(a)
}

function Pe(a, b, c) {
    if (Array.isArray(a)) {
        for (var d = Array(a.length), e = 0; e < a.length; e++) d[e] = Oe(a[e], b, c);
        Array.isArray(a) && a.Cf && Qe(d);
        return d
    }
    d = {};
    for (e in a) d[e] = Oe(a[e], b, c);
    return d
}
var Re = function(a) {
        return "number" === typeof a ? isFinite(a) ? a : String(a) : a
    },
    Se = function(a) {
        return new Uint8Array(a)
    },
    Te = function(a) {
        return a
    },
    Ue = {
        Cf: {
            value: !0,
            configurable: !0
        }
    },
    Qe = function(a) {
        Array.isArray(a) && !Object.isFrozen(a) && Object.defineProperties(a, Ue);
        return a
    },
    Ve, We = Symbol("exempted jspb subclass"),
    Xe = Symbol("generated by jspb");
var Ze = function(a, b) {
    this.ba = a;
    this.Na = b;
    this.map = {};
    this.Qa = !0;
    this.Wd = null;
    if (0 < this.ba.length) {
        for (a = 0; a < this.ba.length; a++) {
            b = this.ba[a];
            var c = b[0];
            this.map[c.toString()] = new Ye(c, b[1])
        }
        this.Qa = !0
    }
};
m = Ze.prototype;
m.isFrozen = function() {
    return !1
};
m.toJSON = function() {
    var a = this.S(!1);
    return Ve ? a : Pe(a, Re, Gb)
};
m.S = function(a) {
    if (this.Qa) {
        if (this.Na) {
            var b = this.map,
                c;
            for (c in b)
                if (Object.prototype.hasOwnProperty.call(b, c)) {
                    var d = b[c].ta;
                    d && d.S(a)
                }
        }
    } else {
        this.ba.length = 0;
        b = $e(this);
        b.sort();
        for (c = 0; c < b.length; c++) {
            d = this.map[b[c]];
            var e = d.ta;
            e && e.S(a);
            this.ba.push([d.key, d.value])
        }
        this.Qa = !0
    }
    return this.ba
};
m.clear = function() {
    this.map = {};
    this.Qa = !1
};
m.entries = function() {
    var a = [],
        b = $e(this);
    b.sort();
    for (var c = 0; c < b.length; c++) {
        var d = this.map[b[c]];
        a.push([d.key, af(this, d)])
    }
    return new bf(a)
};
m.keys = function() {
    var a = [],
        b = $e(this);
    b.sort();
    for (var c = 0; c < b.length; c++) a.push(this.map[b[c]].key);
    return new bf(a)
};
m.values = function() {
    var a = [],
        b = $e(this);
    b.sort();
    for (var c = 0; c < b.length; c++) a.push(af(this, this.map[b[c]]));
    return new bf(a)
};
m.forEach = function(a, b) {
    var c = $e(this);
    c.sort();
    for (var d = 0; d < c.length; d++) {
        var e = this.map[c[d]];
        a.call(b, af(this, e), e.key, this)
    }
};
m.set = function(a, b) {
    var c = new Ye(a);
    this.Na ? (c.ta = b, c.value = b.S(!1)) : c.value = b;
    this.map[a.toString()] = c;
    this.Qa = !1;
    return this
};
var af = function(a, b) {
    return a.Na ? (b.ta || (b.ta = new a.Na(b.value), a.isFrozen() && (A(null != a.Wd), a.Wd(b.ta))), b.ta) : b.value
};
Ze.prototype.get = function(a) {
    if (a = this.map[a.toString()]) return af(this, a)
};
Ze.prototype.has = function(a) {
    return a.toString() in this.map
};
var $e = function(a) {
    a = a.map;
    var b = [],
        c;
    for (c in a) Object.prototype.hasOwnProperty.call(a, c) && b.push(c);
    return b
};
Ze.prototype[Symbol.iterator] = function() {
    return this.entries()
};
var Ye = function(a, b) {
        this.key = a;
        this.value = b;
        this.ta = void 0
    },
    bf = function(a) {
        this.Cd = 0;
        this.ba = a
    };
bf.prototype.next = function() {
    return this.Cd < this.ba.length ? {
        done: !1,
        value: this.ba[this.Cd++]
    } : {
        done: !0,
        value: void 0
    }
};
bf.prototype[Symbol.iterator] = function() {
    return this
};
var cf;
var L = function(a, b, c) {
        Ga(this, L, "The message constructor should only be used by subclasses");
        A(this.constructor !== L, "Message is an abstract class and cannot be directly constructed");
        if (!0 !== this[We]) {
            A(!0 === this[Xe], "Message can only be subclassed by proto gencode.");
            var d = Object.getPrototypeOf(A(Object.getPrototypeOf(this)));
            A(d.hasOwnProperty(Xe), "Generated jspb classes should not be extended")
        }
        d = cf;
        cf = null;
        a || (a = d);
        d = this.constructor.Bg;
        a || (a = d ? [d] : []);
        this.ua = d ? 0 : -1;
        this.i = null;
        this.fa = a;
        a: {
            d =
            this.fa.length;a = d - 1;
            if (d && (d = this.fa[a], null !== d && "object" === typeof d && d.constructor === Object)) {
                this.Ha = a - this.ua;
                this.ka = d;
                break a
            }
            void 0 !== b && -1 < b ? (this.Ha = Math.max(b, a + 1 - this.ua), this.ka = null) : this.Ha = Number.MAX_VALUE
        }
        if (c)
            for (b = 0; b < c.length; b++) a = c[b], a < this.Ha ? (a += this.ua, (d = this.fa[a]) ? Qe(d) : this.fa[a] = df) : (ef(this), (d = this.ka[a]) ? Qe(d) : this.ka[a] = df)
    },
    df = Object.freeze(Qe([])),
    ef = function(a) {
        var b = a.Ha + a.ua;
        a.fa[b] || (a.ka = a.fa[b] = {})
    },
    ff = function(a, b, c) {
        return -1 === b ? null : (void 0 === c ? 0 : c) ||
            b >= a.Ha ? a.ka ? a.ka[b] : void 0 : a.fa[b + a.ua]
    },
    gf = function(a, b) {
        var c = void 0 === c ? !1 : c;
        var d = ff(a, b, c);
        null == d && (d = df);
        d === df && (d = Qe([]), M(a, b, d, c));
        return d
    },
    hf = function(a, b) {
        a = ff(a, 1);
        return null == a ? b : a
    },
    jf = function(a, b, c) {
        a.i || (a.i = {});
        if (b in a.i) return a.i[b];
        var d = ff(a, b);
        d || (d = Qe([]), M(a, b, d));
        c = new Ze(d, c);
        return a.i[b] = c
    },
    M = function(a, b, c, d) {
        (void 0 === d ? 0 : d) || b >= a.Ha ? (ef(a), a.ka[b] = c) : a.fa[b + a.ua] = c;
        return a
    },
    kf = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return M(a, b, Qe(c || []), d)
    },
    lf = function(a, b, c,
        d) {
        for (var e = 0, f = 0; f < c.length; f++) {
            var g = c[f];
            null != ff(a, g) && (0 !== e && M(a, e, void 0), e = g)
        }(c = e) && c !== b && null != d && (a.i && c in a.i && (a.i[c] = void 0), M(a, c, void 0));
        M(a, b, d)
    },
    mf = function(a, b, c, d, e) {
        if (-1 === c) return null;
        a.i || (a.i = {});
        !a.i[c] && (e = ff(a, c, void 0 === e ? !1 : e), d || e) && (a.i[c] = new b(e));
        return a.i[c]
    },
    nf = function(a, b, c) {
        a.i || (a.i = {});
        var d = a.i[c];
        if (!d) {
            var e = gf(a, c);
            d = [];
            for (var f = 0; f < e.length; f++) d[f] = new b(e[f]);
            a.i[c] = d
        }
        return d
    },
    of = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        a.i || (a.i = {});
        var e = c ?
            c.S(!1) : c;
        a.i[b] = c;
        return M(a, b, e, d)
    },
    pf = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        if (c) {
            var e = Qe([]);
            for (var f = 0; f < c.length; f++) e[f] = c[f].S(!1);
            a.i || (a.i = {});
            a.i[b] = c
        } else a.i && (a.i[b] = void 0), e = df;
        return M(a, b, e, d)
    };
L.prototype.toJSON = function() {
    var a = this.S(!1);
    return Ve ? a : Pe(a, Re, Gb)
};
L.prototype.S = function(a) {
    if (this.i)
        for (var b in this.i) {
            var c = this.i[b];
            if (Array.isArray(c))
                for (var d = 0; d < c.length; d++) c[d] && c[d].S(a);
            else c && c.S(a)
        }
    return this.fa
};
var rf = function(a) {
        Ve = !0;
        try {
            return JSON.stringify(a.toJSON(), qf)
        } finally {
            Ve = !1
        }
    },
    qf = function(a, b) {
        switch (typeof b) {
            case "number":
                return isFinite(b) ? b : String(b);
            case "object":
                if (Ne && null != b && b instanceof Uint8Array) return Gb(b)
        }
        return b
    };
L.prototype.toString = function() {
    return this.S(!1).toString()
};
L.prototype.getExtension = function(a) {
    var b = a.jf,
        c = a.Se;
    return a.Bf ? c ? nf(this, c, b) : gf(this, b) : c ? mf(this, c, b, 0, !0) : ff(this, b, !0)
};
L.prototype.clone = function() {
    var a = Ga(this, L),
        b = a.constructor,
        c = Pe(a.S(!1), Te, Se);
    cf = c;
    b = new b(c);
    cf = null;
    sf(b, a);
    return b
};

function sf(a, b) {
    A(a, "expected `to` to be non-null");
    A(b, "expected `from` to be non-null");
    b.Hd && (a.Hd = b.Hd.slice());
    var c = b.i;
    if (c) {
        b = b.ka;
        var d = {},
            e;
        for (e in c) {
            var f = c[e];
            if (f) {
                var g = !(!b || !b[e]),
                    h = +e;
                if (Array.isArray(f)) {
                    if (f.length)
                        for (g = nf(a, f[0].constructor, h), h = 0; h < Math.min(g.length, f.length); h++) sf(g[h], Ga(f[h], L))
                } else f instanceof Ze ? f.Na && (d.Rb = jf(a, h, f.Na), f.forEach(function(k) {
                    return function(l, p) {
                        return sf(k.Rb.get(p), l)
                    }
                }(d))) : (Ga(f, L), (g = mf(a, f.constructor, h, 0, g)) && sf(g, f))
            }
            d = {
                Rb: d.Rb
            }
        }
    }
};
var N = function() {
    L.apply(this, arguments)
};
u(N, L);
N.prototype[Xe] = !0;
var uf = function(a) {
    N.call(this, a, -1, tf)
};
u(uf, N);
var tf = [2];
var vf = function(a) {
    if (!a) return "";
    a = a.split("#")[0].split("?")[0];
    a = a.toLowerCase();
    0 == a.indexOf("//") && (a = window.location.protocol + a);
    /^[\w\-]*:\/\//.test(a) || (a = window.location.href);
    var b = a.substring(a.indexOf("://") + 3),
        c = b.indexOf("/"); - 1 != c && (b = b.substring(0, c));
    c = a.substring(0, a.indexOf("://"));
    if (!c) throw Error("URI is missing protocol: " + a);
    if ("http" !== c && "https" !== c && "chrome-extension" !== c && "moz-extension" !== c && "file" !== c && "android-app" !== c && "chrome-search" !== c && "chrome-untrusted" !== c && "chrome" !==
        c && "app" !== c && "devtools" !== c) throw Error("Invalid URI scheme in origin: " + c);
    a = "";
    var d = b.indexOf(":");
    if (-1 != d) {
        var e = b.substring(d + 1);
        b = b.substring(0, d);
        if ("http" === c && "80" !== e || "https" === c && "443" !== e) a = ":" + e
    }
    return c + "://" + b + a
};

function wf() {
    function a() {
        e[0] = 1732584193;
        e[1] = 4023233417;
        e[2] = 2562383102;
        e[3] = 271733878;
        e[4] = 3285377520;
        p = l = 0
    }

    function b(q) {
        for (var w = g, r = 0; 64 > r; r += 4) w[r / 4] = q[r] << 24 | q[r + 1] << 16 | q[r + 2] << 8 | q[r + 3];
        for (r = 16; 80 > r; r++) q = w[r - 3] ^ w[r - 8] ^ w[r - 14] ^ w[r - 16], w[r] = (q << 1 | q >>> 31) & 4294967295;
        q = e[0];
        var v = e[1],
            y = e[2],
            H = e[3],
            Y = e[4];
        for (r = 0; 80 > r; r++) {
            if (40 > r)
                if (20 > r) {
                    var U = H ^ v & (y ^ H);
                    var ua = 1518500249
                } else U = v ^ y ^ H, ua = 1859775393;
            else 60 > r ? (U = v & y | H & (v | y), ua = 2400959708) : (U = v ^ y ^ H, ua = 3395469782);
            U = ((q << 5 | q >>> 27) & 4294967295) +
                U + Y + ua + w[r] & 4294967295;
            Y = H;
            H = y;
            y = (v << 30 | v >>> 2) & 4294967295;
            v = q;
            q = U
        }
        e[0] = e[0] + q & 4294967295;
        e[1] = e[1] + v & 4294967295;
        e[2] = e[2] + y & 4294967295;
        e[3] = e[3] + H & 4294967295;
        e[4] = e[4] + Y & 4294967295
    }

    function c(q, w) {
        if ("string" === typeof q) {
            q = unescape(encodeURIComponent(q));
            for (var r = [], v = 0, y = q.length; v < y; ++v) r.push(q.charCodeAt(v));
            q = r
        }
        w || (w = q.length);
        r = 0;
        if (0 == l)
            for (; r + 64 < w;) b(q.slice(r, r + 64)), r += 64, p += 64;
        for (; r < w;)
            if (f[l++] = q[r++], p++, 64 == l)
                for (l = 0, b(f); r + 64 < w;) b(q.slice(r, r + 64)), r += 64, p += 64
    }

    function d() {
        var q = [],
            w = 8 * p;
        56 > l ? c(h, 56 - l) : c(h, 64 - (l - 56));
        for (var r = 63; 56 <= r; r--) f[r] = w & 255, w >>>= 8;
        b(f);
        for (r = w = 0; 5 > r; r++)
            for (var v = 24; 0 <= v; v -= 8) q[w++] = e[r] >> v & 255;
        return q
    }
    for (var e = [], f = [], g = [], h = [128], k = 1; 64 > k; ++k) h[k] = 0;
    var l, p;
    a();
    return {
        reset: a,
        update: c,
        digest: d,
        Ve: function() {
            for (var q = d(), w = "", r = 0; r < q.length; r++) w += "0123456789ABCDEF".charAt(Math.floor(q[r] / 16)) + "0123456789ABCDEF".charAt(q[r] % 16);
            return w
        }
    }
};
var yf = function(a, b, c) {
        var d = String(x.location.href);
        return d && a && b ? [b, xf(vf(d), a, c || null)].join(" ") : null
    },
    xf = function(a, b, c) {
        var d = [],
            e = [];
        if (1 == (Array.isArray(c) ? 2 : 1)) return e = [b, a], Ja(d, function(h) {
            e.push(h)
        }), zf(e.join(" "));
        var f = [],
            g = [];
        Ja(c, function(h) {
            g.push(h.key);
            f.push(h.value)
        });
        c = Math.floor((new Date).getTime() / 1E3);
        e = 0 == f.length ? [c, b, a] : [f.join(":"), c, b, a];
        Ja(d, function(h) {
            e.push(h)
        });
        a = zf(e.join(" "));
        a = [c, a];
        0 == g.length || a.push(g.join(""));
        return a.join("_")
    },
    zf = function(a) {
        var b =
            wf();
        b.update(a);
        return b.Ve().toLowerCase()
    };
var Af = {};
var Bf = function(a) {
    this.ub = a || {
        cookie: ""
    }
};
m = Bf.prototype;
m.isEnabled = function() {
    if (!x.navigator.cookieEnabled) return !1;
    if (this.ub.cookie) return !0;
    this.set("TESTCOOKIESENABLED", "1", {
        Xd: 60
    });
    if ("1" !== this.get("TESTCOOKIESENABLED")) return !1;
    this.remove("TESTCOOKIESENABLED");
    return !0
};
m.set = function(a, b, c) {
    var d = !1;
    if ("object" === typeof c) {
        var e = c.Cg;
        d = c.ag || !1;
        var f = c.domain || void 0;
        var g = c.path || void 0;
        var h = c.Xd
    }
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    void 0 === h && (h = -1);
    this.ub.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
};
m.get = function(a, b) {
    for (var c = a + "=", d = (this.ub.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
        f = La(d[e]);
        if (0 == f.lastIndexOf(c, 0)) return f.substr(c.length);
        if (f == a) return ""
    }
    return b
};
m.remove = function(a, b, c) {
    var d = void 0 !== this.get(a);
    this.set(a, "", {
        Xd: 0,
        path: b,
        domain: c
    });
    return d
};
m.clear = function() {
    for (var a = Cf(this).keys, b = a.length - 1; 0 <= b; b--) this.remove(a[b])
};
var Cf = function(a) {
        a = (a.ub.cookie || "").split(";");
        for (var b = [], c = [], d, e, f = 0; f < a.length; f++) e = La(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        return {
            keys: b,
            values: c
        }
    },
    Df = new Bf("undefined" == typeof document ? null : document);
var Ef = function(a) {
        return !!Af.FPA_SAMESITE_PHASE2_MOD || !(void 0 === a || !a)
    },
    Ff = function(a, b, c, d) {
        (a = x[a]) || (a = (new Bf(document)).get(b));
        return a ? yf(a, c, d) : null
    },
    Gf = function(a, b) {
        b = void 0 === b ? !1 : b;
        var c = vf(String(x.location.href)),
            d = [];
        var e = b;
        e = void 0 === e ? !1 : e;
        var f = x.__SAPISID || x.__APISID || x.__3PSAPISID || x.__OVERRIDE_SID;
        Ef(e) && (f = f || x.__1PSAPISID);
        if (f) e = !0;
        else {
            var g = new Bf(document);
            f = g.get("SAPISID") || g.get("APISID") || g.get("__Secure-3PAPISID") || g.get("SID");
            Ef(e) && (f = f || g.get("__Secure-1PAPISID"));
            e = !!f
        }
        e && (e = (c = 0 == c.indexOf("https:") || 0 == c.indexOf("chrome-extension:") || 0 == c.indexOf("moz-extension:")) ? x.__SAPISID : x.__APISID, e || (e = new Bf(document), e = e.get(c ? "SAPISID" : "APISID") || e.get("__Secure-3PAPISID")), (e = e ? yf(e, c ? "SAPISIDHASH" : "APISIDHASH", a) : null) && d.push(e), c && Ef(b) && ((b = Ff("__1PSAPISID", "__Secure-1PAPISID", "SAPISID1PHASH", a)) && d.push(b), (a = Ff("__3PSAPISID", "__Secure-3PAPISID", "SAPISID3PHASH", a)) && d.push(a)));
        return 0 == d.length ? null : d.join(" ")
    };
var If = function(a) {
    N.call(this, a, -1, Hf)
};
u(If, N);
var Kf = function(a) {
    N.call(this, a, -1, Jf)
};
u(Kf, N);
var Lf = function(a) {
    N.call(this, a)
};
u(Lf, N);
var Mf = function(a) {
    N.call(this, a)
};
u(Mf, N);
var Hf = [3, 6, 4],
    Jf = [1],
    Nf = [1, 2, 3],
    Of = [1, 2, 3];
var Qf = function(a) {
    N.call(this, a, -1, Pf)
};
u(Qf, N);
var Pf = [1];
var Rf = function(a, b) {
    this.name = a;
    this.value = b
};
Rf.prototype.toString = function() {
    return this.name
};
var Sf = new Rf("OFF", Infinity),
    Tf = new Rf("SEVERE", 1E3),
    Uf = new Rf("WARNING", 900),
    Vf = new Rf("INFO", 800),
    Wf = new Rf("CONFIG", 700),
    Xf = new Rf("FINE", 500),
    Yf = function() {
        this.sb = 0;
        this.clear()
    },
    Zf;
Yf.prototype.clear = function() {
    this.ed = Array(this.sb);
    this.nd = -1;
    this.Id = !1
};
var $f = function(a, b, c) {
    this.reset(a || Sf, b, c, void 0, void 0)
};
$f.prototype.reset = function() {};
var ag = function(a, b) {
        this.level = null;
        this.vf = [];
        this.parent = (void 0 === b ? null : b) || null;
        this.children = [];
        this.R = {
            pc: function() {
                return a
            }
        }
    },
    bg = function(a) {
        if (a.level) return a.level;
        if (a.parent) return bg(a.parent);
        Ca("Root logger has no level set.");
        return Sf
    },
    cg = function(a, b) {
        for (; a;) a.vf.forEach(function(c) {
            c(b)
        }), a = a.parent
    },
    dg = function() {
        this.entries = {};
        var a = new ag("");
        a.level = Wf;
        this.entries[""] = a
    },
    eg, fg = function(a, b, c) {
        var d = a.entries[b];
        if (d) return void 0 !== c && (d.level = c), d;
        d = fg(a, b.substr(0,
            b.lastIndexOf(".")));
        var e = new ag(b, d);
        a.entries[b] = e;
        d.children.push(e);
        void 0 !== c && (e.level = c);
        return e
    },
    gg = function() {
        eg || (eg = new dg);
        return eg
    },
    hg = function(a, b, c) {
        var d;
        if (d = a)
            if (d = a && b) {
                d = b.value;
                var e = a ? bg(fg(gg(), a.pc())) : Sf;
                d = d >= e.value
            }
        if (d) {
            b = b || Sf;
            d = fg(gg(), a.pc());
            "function" === typeof c && (c = c());
            Zf || (Zf = new Yf);
            e = Zf;
            a = a.pc();
            if (0 < e.sb) {
                var f = (e.nd + 1) % e.sb;
                e.nd = f;
                e.Id ? (e = e.ed[f], e.reset(b, c, a), a = e) : (e.Id = f == e.sb - 1, a = e.ed[f] = new $f(b, c, a))
            } else a = new $f(b, c, a);
            cg(d, a)
        }
    },
    ig = function(a, b) {
        a &&
            hg(a, Vf, b)
    },
    O = function(a, b) {
        a && hg(a, Xf, b)
    };
var jg = function(a) {
    A(0 < a, "Initial value must be greater than zero.");
    A(3E5 >= a, "Max value should be at least as large as initial value.");
    A(!0, "Randomness factor should be between 0 and 1.");
    this.Gd = a;
    this.Yd = 3E5;
    this.Sa = this.za = a;
    this.ee = .1;
    this.He = 2
};
jg.prototype.reset = function() {
    this.Sa = this.za = this.Gd
};
var kg = function() {};
kg.prototype.gd = null;
var mg = function(a) {
    var b;
    (b = a.gd) || (b = {}, lg(a) && (b[0] = !0, b[1] = !0), b = a.gd = b);
    return b
};
var ng, og = function() {};
z(og, kg);
var pg = function(a) {
        return (a = lg(a)) ? new ActiveXObject(a) : new XMLHttpRequest
    },
    lg = function(a) {
        if (!a.Dd && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
            for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
                var d = b[c];
                try {
                    return new ActiveXObject(d), a.Dd = d
                } catch (e) {}
            }
            throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
        }
        return a.Dd
    };
ng = new og;
var P = function(a) {
    K.call(this);
    this.headers = new Map;
    this.Qb = a || null;
    this.ha = !1;
    this.Pb = this.g = null;
    this.Za = this.Ud = this.Bb = "";
    this.qa = this.sc = this.xb = this.jc = !1;
    this.La = 0;
    this.Mb = null;
    this.ge = "";
    this.Ob = this.Rf = this.Uc = !1;
    this.Oc = null
};
z(P, K);
P.prototype.K = fg(gg(), "goog.net.XhrIo", void 0).R;
var qg = /^https?$/i,
    rg = ["POST", "PUT"],
    sg = [],
    tg = function(a, b, c, d, e, f, g) {
        var h = new P;
        sg.push(h);
        b && h.O("complete", b);
        h.M.add("ready", h.Oe, !0, void 0, void 0);
        f && (h.La = Math.max(0, f));
        g && (h.Uc = g);
        h.send(a, c, d, e)
    };
P.prototype.Oe = function() {
    this.U();
    Ka(sg, this)
};
P.prototype.setTrustToken = function(a) {
    this.Oc = a
};
P.prototype.send = function(a, b, c, d) {
    if (this.g) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.Bb + "; newUri=" + a);
    b = b ? b.toUpperCase() : "GET";
    this.Bb = a;
    this.Za = "";
    this.Ud = b;
    this.jc = !1;
    this.ha = !0;
    this.g = this.Qb ? pg(this.Qb) : pg(ng);
    this.Pb = this.Qb ? mg(this.Qb) : mg(ng);
    this.g.onreadystatechange = wa(this.be, this);
    this.Rf && "onprogress" in this.g && (this.g.onprogress = wa(function(g) {
        this.ae(g, !0)
    }, this), this.g.upload && (this.g.upload.onprogress = wa(this.ae, this)));
    try {
        O(this.K, ug(this, "Opening Xhr")),
            this.sc = !0, this.g.open(b, String(a), !0), this.sc = !1
    } catch (g) {
        O(this.K, ug(this, "Error opening Xhr: " + g.message));
        vg(this, g);
        return
    }
    a = c || "";
    c = new Map(this.headers);
    if (d)
        if (Object.getPrototypeOf(d) === Object.prototype)
            for (var e in d) c.set(e, d[e]);
        else if ("function" === typeof d.keys && "function" === typeof d.get) {
        e = t(d.keys());
        for (var f = e.next(); !f.done; f = e.next()) f = f.value, c.set(f, d.get(f))
    } else throw Error("Unknown input type for opt_headers: " + String(d));
    d = Array.from(c.keys()).find(function(g) {
        return "content-type" ==
            g.toLowerCase()
    });
    e = x.FormData && a instanceof x.FormData;
    !(0 <= Ia(rg, b)) || d || e || c.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    b = t(c);
    for (d = b.next(); !d.done; d = b.next()) c = t(d.value), d = c.next().value, c = c.next().value, this.g.setRequestHeader(d, c);
    this.ge && (this.g.responseType = this.ge);
    "withCredentials" in this.g && this.g.withCredentials !== this.Uc && (this.g.withCredentials = this.Uc);
    if ("setTrustToken" in this.g && this.Oc) try {
        this.g.setTrustToken(this.Oc)
    } catch (g) {
        O(this.K, ug(this, "Error SetTrustToken: " +
            g.message))
    }
    try {
        wg(this), 0 < this.La && (this.Ob = xg(this.g), O(this.K, ug(this, "Will abort after " + this.La + "ms if incomplete, xhr2 " + this.Ob)), this.Ob ? (this.g.timeout = this.La, this.g.ontimeout = wa(this.qe, this)) : this.Mb = Je(this.qe, this.La, this)), O(this.K, ug(this, "Sending request")), this.xb = !0, this.g.send(a), this.xb = !1
    } catch (g) {
        O(this.K, ug(this, "Send error: " + g.message)), vg(this, g)
    }
};
var xg = function(a) {
    return qb && Ab(9) && "number" === typeof a.timeout && void 0 !== a.ontimeout
};
P.prototype.qe = function() {
    "undefined" != typeof pa && this.g && (this.Za = "Timed out after " + this.La + "ms, aborting", O(this.K, ug(this, this.Za)), this.dispatchEvent("timeout"), this.abort(8))
};
var vg = function(a, b) {
        a.ha = !1;
        a.g && (a.qa = !0, a.g.abort(), a.qa = !1);
        a.Za = b;
        yg(a);
        zg(a)
    },
    yg = function(a) {
        a.jc || (a.jc = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
    };
P.prototype.abort = function() {
    this.g && this.ha && (O(this.K, ug(this, "Aborting")), this.ha = !1, this.qa = !0, this.g.abort(), this.qa = !1, this.dispatchEvent("complete"), this.dispatchEvent("abort"), zg(this))
};
P.prototype.da = function() {
    this.g && (this.ha && (this.ha = !1, this.qa = !0, this.g.abort(), this.qa = !1), zg(this, !0));
    P.sa.da.call(this)
};
P.prototype.be = function() {
    this.Ca || (this.sc || this.xb || this.qa ? Ag(this) : this.Nf())
};
P.prototype.Nf = function() {
    Ag(this)
};
var Ag = function(a) {
    if (a.ha && "undefined" != typeof pa)
        if (a.Pb[1] && 4 == Bg(a) && 2 == Cg(a)) O(a.K, ug(a, "Local request error detected and ignored"));
        else if (a.xb && 4 == Bg(a)) Je(a.be, 0, a);
    else if (a.dispatchEvent("readystatechange"), 4 == Bg(a)) {
        O(a.K, ug(a, "Request complete"));
        a.ha = !1;
        try {
            if (Dg(a)) a.dispatchEvent("complete"), a.dispatchEvent("success");
            else {
                try {
                    var b = 2 < Bg(a) ? a.g.statusText : ""
                } catch (c) {
                    O(a.K, "Can not get status: " + c.message), b = ""
                }
                a.Za = b + " [" + Cg(a) + "]";
                yg(a)
            }
        } finally {
            zg(a)
        }
    }
};
P.prototype.ae = function(a, b) {
    A("progress" === a.type, "goog.net.EventType.PROGRESS is of the same type as raw XHR progress.");
    this.dispatchEvent(Eg(a, "progress"));
    this.dispatchEvent(Eg(a, b ? "downloadprogress" : "uploadprogress"))
};
var Eg = function(a, b) {
        return {
            type: b,
            lengthComputable: a.lengthComputable,
            loaded: a.loaded,
            total: a.total
        }
    },
    zg = function(a, b) {
        if (a.g) {
            wg(a);
            var c = a.g,
                d = a.Pb[0] ? qa : null;
            a.g = null;
            a.Pb = null;
            b || a.dispatchEvent("ready");
            try {
                c.onreadystatechange = d
            } catch (e) {
                (a = a.K) && hg(a, Tf, "Problem encountered resetting onreadystatechange: " + e.message)
            }
        }
    },
    wg = function(a) {
        a.g && a.Ob && (a.g.ontimeout = null);
        a.Mb && (x.clearTimeout(a.Mb), a.Mb = null)
    },
    Dg = function(a) {
        var b = Cg(a);
        a: switch (b) {
            case 200:
            case 201:
            case 202:
            case 204:
            case 206:
            case 304:
            case 1223:
                var c = !0;
                break a;
            default:
                c = !1
        }
        if (!c) {
            if (b = 0 === b) a = String(a.Bb).match(nc)[1] || null, !a && x.self && x.self.location && (a = x.self.location.protocol, a = a.substr(0, a.length - 1)), b = !qg.test(a ? a.toLowerCase() : "");
            c = b
        }
        return c
    },
    Bg = function(a) {
        return a.g ? a.g.readyState : 0
    },
    Cg = function(a) {
        try {
            return 2 < Bg(a) ? a.g.status : -1
        } catch (b) {
            return -1
        }
    };
P.prototype.getResponseHeader = function(a) {
    if (this.g && 4 == Bg(this)) return a = this.g.getResponseHeader(a), null === a ? void 0 : a
};
P.prototype.getAllResponseHeaders = function() {
    return this.g && 4 == Bg(this) ? this.g.getAllResponseHeaders() || "" : ""
};
var ug = function(a, b) {
    return b + " [" + a.Ud + " " + a.Bb + " " + Cg(a) + "]"
};
var Fg = function(a) {
    N.call(this, a)
};
u(Fg, N);
var Gg = function() {
    var a = new Fg,
        b = document.documentElement.getAttribute("lang");
    return M(a, 5, b)
};
Fg.prototype.jb = function(a) {
    M(this, 7, a)
};
var Hg = function(a) {
    N.call(this, a)
};
u(Hg, N);
var Jg = function(a) {
    N.call(this, a, 31, Ig)
};
u(Jg, N);
Jg.prototype.kb = function(a) {
    return M(this, 26, a)
};
var Ig = [3, 20, 27];
var Lg = function(a) {
    N.call(this, a, 17, Kg)
};
u(Lg, N);
var Mg = function(a, b) {
        return pf(a, 3, b)
    },
    Ng = function(a, b) {
        return M(a, 14, b)
    };
Lg.prototype.ke = function(a) { of (this, 13, a)
};
var Kg = [3, 5];
var Pg = function(a) {
    N.call(this, a, 6, Og)
};
u(Pg, N);
var Og = [5];
var Qg = function(a) {
    N.call(this, a)
};
u(Qg, N);
var Rg = new function(a, b, c, d, e) {
    this.jf = a;
    this.Se = c;
    this.Bf = e
}(175237375, {
    Ag: 0
}, Qg, function(a, b) {
    if (null != b) {
        var c = {
            Eg: hf(b, -1)
        };
        a && (c.ug = b);
        return c
    }
}, 0);
var Tg = function(a, b, c, d, e, f, g, h, k, l, p) {
    K.call(this);
    var q = this;
    this.ja = "";
    this.L = [];
    this.Td = "";
    this.Pc = this.Rc = this.ac = !1;
    this.Zd = this.Ic = -1;
    this.ld = !1;
    this.pa = this.Y = null;
    this.ab = 0;
    this.cg = 1;
    this.bc = null;
    this.Mc = 0;
    this.Kb = !1;
    K.call(this);
    this.Db = a;
    this.wd = b || qa;
    this.va = new Lg;
    this.yc = d;
    this.Fb = p;
    this.bufferSize = 1E3;
    this.sg = xa(Oc, 0, 1);
    this.$b = e || null;
    this.Ia = c || null;
    this.ic = g || !1;
    this.zc = k || null;
    this.R = fg(gg(), "playlog.clearcut.ClearcutBase", void 0).R;
    this.withCredentials = !h;
    this.Md = f || !1;
    this.Ld = !this.Md && (Cb && Ab(65) || Bb && Ab(45) || Db && Ab(12) || (kb() || B("iPad") || B("iPod")) && lb()) && !!window && !!window.navigator && !!window.navigator.sendBeacon;
    a = M(new Hg, 1, 1);
    f || (f = Gg(), of (a, 11, f)); of (this.va, 1, a);
    M(this.va, 2, this.Db);
    this.oa = new jg(1E4);
    this.s = new Ie(this.oa.za);
    Yc(this, xa(Wc, this.s));
    F(this.s, "tick", lc(Sg(this, l)), !1, this);
    this.Zb = new Ie(6E5);
    Yc(this, xa(Wc, this.Zb));
    F(this.Zb, "tick", lc(Sg(this, l)), !1, this);
    this.ic || this.Zb.start();
    this.Md || (F(window, "beforeunload", this.Wa, !1, this), F(window, "unload",
        this.Wa, !1, this), F(document, "visibilitychange", function() {
        "hidden" === document.visibilityState && q.Wa()
    }), F(document, "pagehide", this.Wa, !1, this))
};
u(Tg, K);
var Sg = function(a, b) {
    return b ? function() {
        b().then(a.flush.bind(a))
    } : a.flush
};
Tg.prototype.da = function() {
    this.Wa();
    K.prototype.da.call(this)
};
var Ug = function(a) {
    a.$b || (a.$b = .01 > a.sg() ? "https://www.google.com/log?format=json&hasfast=true" : "https://play.google.com/log?format=json&hasfast=true");
    return a.$b
};
m = Tg.prototype;
m.Gc = function(a) {
    ff(a, 1) || M(a, 1, 1); of (this.va, 1, a)
};
m.kb = function(a) {
    this.ja = a
};
m.oe = function(a) {
    this.Y || (this.Y = new uf);
    kf(this.Y, 2, a)
};
m.je = function(a) {
    a ? (this.Y || (this.Y = new uf), a = rf(a), M(this.Y, 4, a)) : this.Y && M(this.Y, 4, void 0)
};
m.ke = function(a) {
    this.bc = a
};
m.ne = function(a) {
    this.pa = a
};
m.jb = function(a) {
    var b = mf(this.va, Hg, 1),
        c = mf(b, Fg, 11);
    c || (c = new Fg);
    c.jb(a); of (b, 11, c);
    this.Gc(b)
};
m.me = function(a) {
    this.ld = !0;
    Vg(this, a)
};
var Vg = function(a, b) {
    a.oa = new jg(1 > b ? 1 : b);
    a.s.setInterval(a.oa.za)
};
Tg.prototype.log = function(a) {
    a = a.clone();
    var b = this.cg++;
    M(a, 21, b);
    this.ja && a.kb(this.ja);
    ff(a, 1) || M(a, 1, Date.now().toString());
    null != ff(a, 15) || M(a, 15, 60 * (new Date).getTimezoneOffset());
    this.Y && (b = this.Y.clone(), of (a, 16, b));
    for (; this.L.length >= this.bufferSize;) this.L.shift(), ++this.ab;
    this.L.push(a);
    this.dispatchEvent(new Wg(a));
    this.ic || this.s.enabled || this.s.start()
};
Tg.prototype.flush = function(a, b) {
    var c = this;
    if (0 === this.L.length) a && a();
    else if (this.Kb) Xg(this);
    else {
        var d = Date.now();
        if (this.Zd > d && this.Ic < d) ig(this.R, "Not flushing because server requested delay."), b && b("throttled");
        else {
            var e = Ng(Mg(M(this.va.clone(), 4, Date.now().toString()), this.L), this.ab);
            this.bc && e.ke(this.bc);
            d = {};
            var f = this.wd();
            f && (d.Authorization = f);
            var g = Ug(this);
            this.Ia && (d["X-Goog-AuthUser"] = this.Ia, g = sc(g, "authuser", this.Ia));
            this.zc && (d["X-Goog-PageId"] = this.zc, g = sc(g, "pageId", this.zc));
            if (f && this.Td === f) ig(this.R, "XHR with unauthorized request not retried"), b && b("stale-auth-token");
            else if (ig(this.R, "Flushing log to clearcut."), this.L = [], this.s.enabled && this.s.stop(), this.ab = 0, this.ac) ig(this.R, rf(e)), d && ig(this.R, JSON.stringify(d)), a && a();
            else {
                var h = rf(e),
                    k;
                this.pa && this.pa.zg(h.length) && (k = this.pa.yg(h));
                var l = {
                        url: g,
                        body: h,
                        Je: 1,
                        Ec: d,
                        Vf: "POST",
                        withCredentials: this.withCredentials,
                        Mc: this.Mc
                    },
                    p = function(r) {
                        c.oa.reset();
                        c.s.setInterval(c.oa.za);
                        if (r) {
                            var v = null;
                            try {
                                var y = JSON.parse(r.replace(")]}'\n",
                                    ""));
                                v = new Pg(y)
                            } catch (H) {
                                (r = c.R) && hg(r, Uf, "Response parse failed: " + H.toString())
                            }
                            v && (r = Number(hf(v, "-1")), 0 < r && (c.Ic = Date.now(), c.Zd = c.Ic + r), v = v.getExtension(Rg)) && (v = hf(v, -1), -1 != v && (c.ld || Vg(c, v)))
                        }
                        a && a()
                    },
                    q = function(r) {
                        var v = nf(e, Jg, 3),
                            y = c.oa;
                        y.Sa = Math.min(y.Yd, y.Sa * y.He);
                        y.za = Math.min(y.Yd, y.Sa + (y.ee ? Math.round(y.ee * (Math.random() - .5) * 2 * y.Sa) : 0));
                        c.s.setInterval(c.oa.za);
                        401 === r && f && (c.Td = f);
                        if (500 <= r && 600 > r || 401 === r || 0 === r) c.L = v.concat(c.L), c.ic || c.s.enabled || c.s.start();
                        (v = c.R) && hg(v, Uf, "Flush failed. Status code: " +
                            r);
                        b && b("net-send-failed", r)
                    },
                    w = function() {
                        c.Fb ? c.Fb.send(l, p, q) : c.yc(l, p, q)
                    };
                k ? k.then(function(r) {
                    l.Ec["Content-Encoding"] = "gzip";
                    l.Ec["Content-Type"] = "application/binary";
                    l.body = r;
                    l.Je = 2;
                    w()
                }, function() {
                    w()
                }) : w()
            }
        }
    }
};
Tg.prototype.Wa = function() {
    this.ac || (this.Rc && Xg(this), this.Pc && Yg(this), this.flush())
};
var Xg = function(a) {
        ig(a.R, "Flushing log using sendBeacon.");
        Zg(a, 32, 10, function(b, c) {
            b = sc(b, "format", "json");
            b = window.navigator.sendBeacon(b, rf(c));
            a.Kb && !b && (a.Kb = !1);
            return b
        })
    },
    Yg = function(a) {
        ig(a.R, "Flushing log using Image GET.");
        Zg(a, 6, 5, function(b, c) {
            c = rf(c);
            c = Gb(Ha(c), 3);
            c = rc(b, "format", "base64json", "p", c);
            if (15360 < c.length) return !1;
            b = new Image;
            a: {
                try {
                    var d = b && b.ownerDocument,
                        e = d && (d.defaultView || d.parentWindow);
                    e = e || x;
                    if (e.Element && e.Location) {
                        var f = e;
                        break a
                    }
                } catch (h) {}
                f = null
            }
            if (f && "undefined" !=
                typeof f.HTMLImageElement && (!b || !(b instanceof f.HTMLImageElement) && (b instanceof f.Location || b instanceof f.Element))) {
                if (sa(b)) try {
                    var g = b.constructor.displayName || b.constructor.name || Object.prototype.toString.call(b)
                } catch (h) {
                    g = "<object could not be stringified>"
                } else g = void 0 === b ? "undefined" : null === b ? "null" : typeof b;
                Ca("Argument is not a %s (or a non-Element, non-Location mock); got: %s", "HTMLImageElement", g)
            }
            if (c instanceof Zb) f = c;
            else a: if (f = c, d = /^data:image\//i.test(c), !(f instanceof Zb)) {
                f =
                    "object" == typeof f && f.wb ? f.Xa() : String(f);
                if (d && /^data:/i.test(f) && (d = String(f), d = d.replace(/(%0A|%0D)/g, ""), d = ((e = d.match(bc)) && ac.test(e[1]) ? new Zb(d, Yb) : null) || dc, d.Xa() == f)) {
                    f = d;
                    break a
                }
                A(cc.test(f), "%s does not match the safe URL pattern", f) || (f = "about:invalid#zClosurez");
                f = new Zb(f, Yb)
            }
            b.src = $b(f);
            return !0
        })
    },
    Zg = function(a, b, c, d) {
        if (0 !== a.L.length) {
            var e = wc(Ug(a), "format");
            e = rc(e, "auth", a.wd(), "authuser", a.Ia || "0");
            for (var f = 0; f < c && a.L.length; ++f) {
                var g = a.L.slice(0, b),
                    h = Mg(M(a.va.clone(), 4,
                        Date.now().toString()), g);
                0 === f && Ng(h, a.ab);
                if (!d(e, h)) break;
                a.L = a.L.slice(g.length)
            }
            a.s.enabled && a.s.stop();
            a.ab = 0
        }
    },
    Wg = function() {
        Zc.call(this, "event-logged", void 0)
    };
u(Wg, Zc);

function $g(a, b, c) {
    tg(a.url, function(d) {
        d = d.target;
        if (Dg(d)) {
            try {
                var e = d.g ? d.g.responseText : ""
            } catch (f) {
                O(d.K, "Can not get responseText: " + f.message), e = ""
            }
            b(e)
        } else c(Cg(d))
    }, a.Vf, a.body, a.Ec, a.Mc, a.withCredentials)
};

function ah(a) {
    this.Db = a;
    this.Ia = "0";
    this.pd = "https://play.google.com/log?format=json&hasfast=true";
    this.Xe = !1;
    this.Ef = !0;
    this.qd = !1;
    this.yc = $g;
    this.ja = "";
    this.$e = this.Qc = this.Sc = !1
}
m = ah.prototype;
m.jb = function(a) {
    this.fd = a
};
m.ne = function(a) {
    this.pa = a
};
m.kb = function(a) {
    this.ja = a;
    return this
};
m.je = function(a) {
    this.jd = a
};
m.oe = function(a) {
    this.ce = a
};
m.Gc = function(a) {
    this.kd = a
};
m.Rc = function() {
    this.Sc = !0;
    return this
};
m.Pc = function() {
    this.Qc = !0;
    return this
};
m.me = function(a) {
    this.ud = Math.max(a, 5E3)
};
var bh = function() {
    var a = 1609;
    a = void 0 === a ? -1 : a;
    var b = void 0 === b ? "" : b;
    var c = void 0 === c ? "" : c;
    var d = void 0 === d ? !1 : d;
    var e = void 0 === e ? "" : e;
    var f = (new ah(a)).kb(b);
    "" != c && (f.pd = c);
    d && (f.qd = !0);
    e && f.jb(e);
    c = new Tg(f.Db, f.lf ? f.lf : Gf, f.Ia, f.yc, f.pd, f.qd, f.Xe, void 0, void 0, void 0, f.Fb ? f.Fb : void 0);
    f.Ef || (c.ac = !0);
    f.kd && c.Gc(f.kd);
    f.fd && c.jb(f.fd);
    f.pa && c.ne(f.pa);
    f.ja && c.kb(f.ja);
    f.jd && c.je(f.jd);
    f.ce && c.oe(f.ce);
    f.Sc && (c.Rc = f.Sc && c.Ld);
    f.Qc && (c.Pc = f.Qc);
    f.ud && c.me(f.ud);
    f.$e && (c.Kb = c.Ld);
    this.Db = a;
    this.ja =
        b;
    this.re = c
};
bh.prototype.flush = function(a) {
    var b = a || [];
    if (b.length) {
        a = new Qf;
        for (var c = [], d = 0; d < b.length; d++) {
            var e = b[d],
                f = e;
            var g = new If;
            g = M(g, 1, f.$a);
            for (var h = f, k = [], l = 0; l < h.vb.length; l++) k.push(h.vb[l].sd);
            g = kf(g, 3, k);
            h = [];
            k = [];
            l = t(f.wa.keys());
            for (var p = l.next(); !p.done; p = l.next()) k.push(p.value.split(","));
            for (l = 0; l < k.length; l++) {
                p = k[l];
                var q = f.Me;
                for (var w = f.xd(p) || [], r = [], v = 0; v < w.length; v++) {
                    var y = w[v];
                    y = y && y.hd;
                    var H = new Mf;
                    switch (q) {
                        case 3:
                            lf(H, 1, Of, Number(y));
                            break;
                        case 2:
                            lf(H, 2, Of, Number(y))
                    }
                    r.push(H)
                }
                q = r;
                for (w = 0; w < q.length; w++) {
                    r = q[w];
                    v = new Kf;
                    r = of (v, 2, r);
                    v = p;
                    y = [];
                    H = f;
                    for (var Y = [], U = 0; U < H.vb.length; U++) Y.push(H.vb[U].td);
                    H = Y;
                    for (Y = 0; Y < H.length; Y++) {
                        U = H[Y];
                        var ua = v[Y],
                            kc = new Lf;
                        switch (U) {
                            case 3:
                                lf(kc, 1, Nf, String(ua));
                                break;
                            case 2:
                                lf(kc, 2, Nf, Number(ua));
                                break;
                            case 1:
                                lf(kc, 3, Nf, "true" == ua)
                        }
                        y.push(kc)
                    }
                    pf(r, 1, y);
                    h.push(r)
                }
            }
            pf(g, 4, h);
            c.push(g);
            e.clear()
        }
        pf(a, 1, c);
        b = this.re;
        a instanceof Jg ? b.log(a) : (c = new Jg, a = rf(a), a = M(c, 8, a), b.log(a));
        this.re.flush()
    }
};
var Q = {
        vg: {}
    },
    R = R || {};
R.Yb = "APISID";
R.Xb = "SAPISID";
R.Vb = "__Secure-3PAPISID";
R.Z = function(a) {
    a = encodeURIComponent(a);
    if (a = Df.get(a)) return decodeURIComponent(a)
};
R.kc = function(a) {
    var b;
    (a = R.Z(a)) && (b = String(ch(a)));
    return b
};
R.gg = function(a, b, c) {
    Df.set(a, b, c)
};
Q = Q || {};
Q.xf = function(a, b, c, d) {
    d = void 0 === d ? !1 : d;
    if (!0 === Q.uc) a();
    else {
        var e = 2,
            f = function() {
                e--;
                0 == e && (Q.uc = !0, a())
            },
            g = function(h) {
                b(h)
            };
        switch (dh()) {
            case "sessionStorage":
                Q.lb = new eh;
                Q.lb.V(f, g);
                if (c) try {
                    Q.lb.clear()
                } catch (h) {}
                break;
            case "inMemoryStorage":
                Q.lb = new fh;
                Q.lb.V(f, g);
                break;
            default:
                c = Error("Unsupported storage type: " + dh());
                b(c);
                return
        }
        switch (gh()) {
            case "localStorage":
                Q.Ga = new hh;
                Q.Ga.V(f, g);
                break;
            case "indexedDb":
                Q.Ga = new ih;
                Q.Ga.V(f, g);
                break;
            case "cookieStorage":
                Q.Ga = new jh;
                d ? f() : Q.Ga.V(f, g);
                break;
            default:
                c = Error("Unsupported storage type: " + gh()), b(c)
        }
    }
};
Q.Ad = function() {
    if (!Q.uc) throw Error("Storages are not initialized yet!");
    return Q.Ga
};
Q.tf = function() {
    if (!Q.uc) throw Error("Storages are not initialized yet!");
    return Q.lb
};
var hh = function() {
    this.Da = null
};
m = hh.prototype;
m.V = function(a, b) {
    we() ? (this.Da = window.localStorage, a()) : b && b(Error("localStorage is not available in the current environment."))
};
m.getItem = function(a, b) {
    b(this.Da.getItem(a))
};
m.setItem = function(a, b, c) {
    void 0 === b || null === b ? this.Da.removeItem(a) : this.Da.setItem(a, b);
    c && c()
};
m.removeItem = function(a, b) {
    this.Da.removeItem(a);
    b && b()
};
m.clear = function(a) {
    this.Da.clear();
    a && a()
};
var ih = function() {
    this.Ua = void 0
};
m = ih.prototype;
m.V = function(a, b) {
    var c = this,
        d = window.indexedDB.open("oauth");
    d.onsuccess = function(e) {
        c.Ua = e.target.result;
        a()
    };
    d.onupgradeneeded = function(e) {
        e.target.result.createObjectStore("oauth")
    };
    d.onerror = function(e) {
        e = e.target.errorCode;
        b && b(Error("IndexedDb initialization failed: " + e))
    }
};
m.getItem = function(a, b) {
    var c = this.Ua.transaction("oauth", "readwrite").objectStore("oauth").get(a);
    c.onsuccess = function() {
        b(c.result)
    }
};
m.setItem = function(a, b, c) {
    var d = this.Ua.transaction("oauth", "readwrite").objectStore("oauth");
    if (void 0 === b || null === b) d["delete"](a);
    else d.put(b, a);
    d.transaction.oncomplete = function() {
        c && c()
    }
};
m.removeItem = function(a, b) {
    var c = this.Ua.transaction("oauth", "readwrite").objectStore("oauth");
    c["delete"](a);
    c.transaction.oncomplete = function() {
        b && b()
    }
};
m.clear = function(a) {
    var b = this.Ua.transaction("oauth", "readwrite").objectStore("oauth");
    b.clear();
    b.transaction.oncomplete = function() {
        a && a()
    }
};
var fh = function() {};
m = fh.prototype;
m.V = function(a) {
    this.Lb = {};
    a()
};
m.getItem = function(a, b) {
    b(this.Lb[a] || null)
};
m.setItem = function(a, b, c) {
    this.Lb[a] = b;
    c && c()
};
m.removeItem = function(a, b) {
    delete this.Lb[a];
    b && b()
};
m.clear = function(a) {
    this.Lb = {};
    a && a()
};
var eh = function() {
    this.Ja = null
};
m = eh.prototype;
m.V = function(a, b) {
    we() ? (this.Ja = window.sessionStorage, a()) : b && b(Error("sessionStorage is not available in the current environment."))
};
m.getItem = function(a, b) {
    b(this.Ja.getItem(a))
};
m.setItem = function(a, b, c) {
    void 0 === b || null === b ? this.Ja.removeItem(a) : this.Ja.setItem(a, b);
    c && c()
};
m.removeItem = function(a, b) {
    this.Ja.removeItem(a);
    b && b()
};
m.clear = function(a) {
    this.Ja.clear();
    a && a()
};
var jh = function() {
    this.Jf = S.ve
};
m = jh.prototype;
m.V = function(a, b) {
    navigator.cookieEnabled ? a() : b && b(Error("Cookies are not enabled in current environment."))
};
m.getItem = function(a, b) {
    for (var c = null, d = kh(a), e = 0; e < d.length; e++)
        if (d[e].key == a) {
            c = d[e].value;
            break
        }
    b(c)
};
m.setItem = function(a, b, c) {
    var d = S.lc(a.split(S.v)[0]);
    if (d) {
        var e = lh(d);
        b = {
            key: a,
            value: b
        };
        for (var f = 0; f < e.length; f++)
            if (e[f].key == a) {
                e.splice(f, 1);
                break
            }
        e.push(b);
        mh(this, d, e)
    }
    c && c()
};
m.removeItem = function(a, b) {
    for (var c = kh(a), d = 0; d < c.length; d++)
        if (c[d].key == a) {
            c.splice(d, 1);
            break
        }(a = S.lc(a.split(S.v)[0])) && mh(this, a, c);
    b && b()
};
m.clear = function(a) {
    Q.Qe();
    a && a()
};
var kh = function(a) {
        return (a = S.lc(a.split(S.v)[0])) ? lh(a) : []
    },
    lh = function(a) {
        a = R.Z(a);
        return Q.Ue(a || null)
    },
    mh = function(a, b, c) {
        var d = Q.bf(c);
        d.length > a.Jf ? (c.splice(0, 1), 0 < c.length ? mh(a, b, c) : G("Failed to write Cookie based cache due to the big size.")) : Q.le(b, d)
    };
Q.Te = function(a) {
    try {
        return atob(a)
    } catch (b) {
        return a
    }
};
Q.af = function(a) {
    try {
        return btoa(a)
    } catch (b) {
        return a
    }
};
Q.Ue = function(a) {
    if (!a) return [];
    a = Q.Te(a);
    try {
        return J.parse(a).items || []
    } catch (b) {
        return G("Error while parsing items from cookie:" + b.message), []
    }
};
Q.bf = function(a) {
    return Q.af(J.stringify({
        items: a
    }))
};
Q.le = function(a, b) {
    var c = window.location.pathname;
    c = {
        domain: window.location.hostname,
        path: -1 != navigator.userAgent.toLowerCase().indexOf("msie") || ye() ? void 0 : c,
        ag: "https:" === window.location.protocol ? !0 : void 0
    };
    R.gg(encodeURIComponent(a), encodeURIComponent(b), c)
};
Q.Qe = function() {
    var a = S.Tb;
    var b = Cf(Df).keys;
    for (var c = 0; c < b.length; c++) {
        var d = decodeURIComponent(b[c]);
        0 == d.indexOf(a) && Q.le(d, "")
    }
};
var nh = function(a) {
    this.Pd = a;
    this.l = void 0;
    Ce.call(this, ["storageValueChanged"])
};
I(nh, Ce);
var oh = function(a, b) {
    Q.Ad().getItem(a.Pd, b)
};
nh.prototype.addListener = function(a) {
    this.addEventListener("storageValueChanged", a)
};
nh.prototype.start = function() {
    var a = this;
    oh(this, function(b) {
        a.Pf = b;
        a.$d = 0;
        a.l = new Ie;
        F(a.l, "tick", ph(a));
        a.l.setInterval(200);
        a.l.start()
    })
};
nh.prototype.stop = function() {
    void 0 !== this.l && (this.l.stop(), this.l = void 0)
};
var ph = function(a) {
        return function() {
            a.$d++;
            oh(a, function(b) {
                b != a.Pf ? (a.dispatchEvent({
                    type: "storageValueChanged",
                    key: a.Pd,
                    newValue: b
                }), a.stop()) : 1500 <= a.$d && a.stop()
            })
        }
    },
    ch = function(a) {
        var b = 0,
            c;
        if (a) {
            var d = 0;
            for (c = a.length; d < c; d++) {
                var e = a.charCodeAt(d);
                b = (b << 5) - b + e;
                b |= 0
            }
        }
        return b
    },
    T = function(a) {
        return !!a && 0 <= a.indexOf(S.v)
    },
    qh = function(a, b) {
        if (!a && !b) return !0;
        if (!a || !b) return !1;
        a = a.extraQueryParams;
        b = b.extraQueryParams;
        if (!a && !b) return !0;
        if (!a || !b || Object.keys && Object.keys(a).length != Object.keys(b).length) return !1;
        for (var c in a)
            if (a[c] !== b[c]) return !1;
        if (!Object.keys)
            for (c in b)
                if (a[c] !== b[c]) return !1;
        return !0
    },
    S = S || {};
S.ue = 100;
S.ad = "/oauth2/sessionstate/action/updateState";
S.Vc = "/oauth2/sessionstate/action/checkOrigin";
S.Zc = "/oauth2/permission/action/refresh";
S.Yc = "/oauth2/permission/action/code";
S.Wb = "/oauth2/permission/action/listSessions";
S.Ae = "/o/oauth2/revoke";
S.pb = "response_type login_hint client_id origin scope ss_domain authuser hd enable_serial_consent include_granted_scopes nonce".split(" ");
S.xe = "login_hint client_id origin scope ss_domain authuser hd enable_serial_consent include_granted_scopes".split(" ");
S.ye = "client_id origin scope ss_domain authuser hd enable_serial_consent".split(" ");
S.v = "::";
S.Ub = "_ss_";
S.Xc = "_tr_";
S.Pa = "oauth2_ss";
S.Wc = "oauth2_cs";
S.$c = "oauth2_tr";
S.we = "oauth2_is";
S.Oa = "oauth2_ar";
S.Tb = "oauth2c_";
S.ve = 1500;
S.tg = function() {
    var a = {
            Ub: 1,
            Xc: 2,
            Pa: 3,
            Wc: 4,
            $c: 5,
            Oa: 6
        },
        b;
    for (b in a)
        if (a = S[b], !a || 0 <= a.indexOf(S.v)) throw Error("Invalid value for 'oauth2.spi." + b + "'.");
};
S.tg();
S.ze = 512;
S.Ee = function(a) {
    var b;
    (b = void 0 === a.hint) || (b = a.hint, b = ("" === b ? !0 : b ? "string" == typeof b || "object" == typeof b && b.constructor === String : !1) && a.hint.length <= S.ze);
    return !a.id && b
};
S.rf = function() {
    var a = R.Z("https:" == window.location.protocol ? R.Xb : R.Yb);
    a || (a = R.Z(R.Vb));
    return a
};
S.lc = function(a) {
    switch (a) {
        case S.Oa:
            return S.Tb + S.Oa;
        case S.Pa:
            return S.Tb + S.Pa;
        default:
            return null
    }
};
var gh = function() {
        return (Be() || ze()) && !we() || ye() && !window.indexedDB ? "cookieStorage" : ye() ? "indexedDb" : "localStorage"
    },
    dh = function() {
        return !Be() && !ze() || we() ? "sessionStorage" : "inMemoryStorage"
    };
R = R || {};
R.Sb = "cookieValueChanged";
var rh = function(a) {
    this.l = void 0;
    this.yf = a;
    Ce.call(this, [R.Sb])
};
I(rh, Ce);
rh.prototype.Z = function() {
    return R.Z(R.Yb) || R.Z(R.Xb) || R.Z(R.Vb)
};
var sh = function() {
    return R.kc(R.Yb) || R.kc(R.Xb) || R.kc(R.Vb)
};
rh.prototype.addListener = function(a) {
    this.addEventListener(R.Sb, a)
};
var vh = function(a) {
        th(a);
        a.Gb = a.Z();
        a.l = new Ie;
        F(a.l, "tick", uh(a));
        a.l.setInterval(a.yf);
        a.l.start();
        G("IDP Session Cookie monitor is started.")
    },
    th = function(a) {
        void 0 !== a.l && (a.l.stop(), a.l = void 0, G("IDP Session Cookie monitor is stoped."))
    },
    uh = function(a) {
        return function() {
            var b = a.Z();
            if (a.Gb != b) {
                var c = {
                    type: R.Sb,
                    newHash: b && ch(b),
                    oldHash: a.Gb && ch(a.Gb)
                };
                a.Gb = b;
                a.dispatchEvent(c)
            }
        }
    },
    wh = function(a) {
        this.j = a;
        this.se = void 0
    },
    xh = function(a, b, c) {
        var d = S.Ae,
            e = new XMLHttpRequest;
        e.onreadystatechange = function() {
            if (4 ==
                e.readyState && 200 == e.status) {
                var h;
                e.responseText && (h = J.parse(e.responseText));
                c(h)
            } else 4 == e.readyState && 0 == e.status ? c({
                error: "network_error"
            }) : 4 == e.readyState && c({
                error: "server_error",
                error_subtype: e.responseText
            })
        };
        e.open("POST", d, !0);
        e.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        var f = "xsrfToken=";
        a.se && (f += a.se);
        if (b)
            for (var g in b) g && b[g] && (f += "&" + g + "=" + encodeURIComponent(b[g]));
        G("Call " + d + " with postData: " + f);
        e.send(f)
    },
    yh = function(a, b, c, d) {
        var e = new XMLHttpRequest;
        e.onreadystatechange = function() {
            if (4 == e.readyState && 200 == e.status) {
                var g;
                if (e.responseText && (g = J.parse(e.responseText))) {
                    var h = g;
                    if (h.error) {
                        h.thrown_by = "server";
                        try {
                            h.error = h.error.toLowerCase()
                        } catch (k) {}
                    }
                }
                d(g)
            } else 4 == e.readyState && 0 == e.status ? d({
                error: "network_error"
            }) : 4 == e.readyState && d({
                error: "server_error",
                error_subtype: e.responseText
            })
        };
        if (b = se(b)) a += 0 > a.indexOf("?") ? "?" : "&", a += b;
        e.open("GET", a, !0);
        e.setRequestHeader("X-Requested-With", "XmlHttpRequest");
        if (c)
            for (var f in c)
                if (c.hasOwnProperty(f)) {
                    b =
                        c[f];
                    if (null === b || void 0 === b) b = "";
                    e.setRequestHeader(f, b)
                }
        G("Call " + a + " with Get method.");
        e.send()
    },
    zh = function(a, b, c) {
        yh(S.Vc, {
            origin: a.j,
            client_id: b
        }, null, c)
    },
    Ah = function(a, b, c) {
        b && b.length ? yh(S.ad, {
            login_hint: b.join(" "),
            origin: a.j
        }, null, c) : c({
            activeHints: {}
        })
    },
    Ch = function(a, b, c) {
        b.origin = a.j;
        0 > S.pb.indexOf("enable_serial_consent") && S.pb.push("enable_serial_consent");
        b = Bh(b, S.pb);
        yh(S.Zc, b, null, c)
    },
    Dh = function(a, b, c) {
        b.origin = a.j;
        b = Bh(b, S.xe);
        yh(S.Yc, b, null, c)
    },
    Eh = function(a, b, c) {
        b.origin = a.j;
        b = Bh(b, S.ye);
        yh(S.Wb, b, null, c)
    },
    Fh = function(a, b, c) {
        xh(a, {
            token: b
        }, c)
    },
    Bh = function(a, b) {
        for (var c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            void 0 !== a[e] && null !== a[e] && (c[e] = a[e])
        }
        return c
    };
Q = Q || {};
var Gh = function() {};
Gh.prototype.J = function() {
    return !1
};
var Hh = {};
Q.Sf = function() {
    var a = new Ih;
    if (!a) throw Error("policy cannot be empty.");
    if (Q.Jd("DEFAULT")) throw Error("Duplicate policyName [DEFAULT].");
    Hh.DEFAULT = a
};
Q.Jd = function(a) {
    for (var b in Hh)
        if (a == b) return !0;
    return !1
};
Q.yd = function(a) {
    return a && Q.Jd(a) ? a : "DEFAULT"
};
Q.nf = function(a) {
    return Hh[Q.yd(a)]
};
Q.J = function(a, b, c, d) {
    return Q.nf(d).J(a, b, c)
};
Q.xg = function(a, b, c, d) {
    if (!Q.J(a, b, c, d)) throw Error("permission_error");
};
var Jh = function() {};
I(Jh, Gh);
Jh.prototype.J = function(a, b, c) {
    a = c ? this.qc(a) : this.rc(a);
    return 0 <= qe(a, b)
};
Jh.prototype.rc = function(a) {
    var b = [];
    if (a && (b.push(a), "http://" == a.substring(0, 7) || "https://" == a.substring(0, 8))) {
        var c = document.createElement("a");
        c.href = a;
        a != c.protocol + "//" + c.hostname && b.push(c.protocol + "//" + c.hostname);
        "https:" == c.protocol && b.push("http://" + c.hostname)
    }
    return b
};
Jh.prototype.qc = function(a) {
    var b = [];
    if (a) {
        b.push(a);
        var c = document.createElement("a");
        c.href = a;
        if ("http:" == c.protocol || "https:" == c.protocol)
            for (a = c.hostname.split("."); 1 < a.length;) b.push(c.protocol + "//" + a.join(".")), "https:" == c.protocol && b.push("http://" + a.join(".")), a.shift()
    }
    return b
};
var Ih = function() {};
I(Ih, Gh);
Ih.prototype.J = function(a, b, c) {
    a = c ? this.qc(a) : this.rc(a);
    return 0 <= qe(a, b)
};
Ih.prototype.rc = function(a) {
    var b = [];
    if (a && (b.push(a), "https://" == a.substring(0, 8))) {
        var c = document.createElement("a");
        c.href = a;
        "" != c.port && 0 != c.port && 443 != c.port || b.push("http://" + c.hostname)
    }
    return b
};
Ih.prototype.qc = function(a) {
    var b = [];
    if (a) {
        var c = document.createElement("a");
        c.href = a;
        if ("https:" == c.protocol && ("" == c.port || 0 == c.port || 443 == c.port) || "http:" == c.protocol && ("" == c.port || 0 == c.port || 80 == c.port))
            for (a = c.hostname.split("."); 1 < a.length;) b.push(c.protocol + "//" + a.join(".")), "https:" == c.protocol && b.push("http://" + a.join(".")), a.shift();
        else b.push(a)
    }
    return b
};
Q.Sf();
var Kh = function() {};
Kh.prototype.wc = function() {
    return !0
};
var V = function(a) {
    return a.wc() ? Q.tf() : Q.Ad()
};
Kh.prototype.u = function() {
    throw Error("unimplemented abstract method");
};
Kh.prototype.Ea = function() {
    throw Error("unimplemented abstract method");
};
Kh.prototype.G = function() {
    throw Error("unimplemented abstract method");
};
Kh.prototype.H = function() {
    throw Error("unimplemented abstract method");
};
var W = function() {};
I(W, Kh);
W.prototype.G = function(a, b, c) {
    var d = this,
        e = this.u(a);
    V(this).getItem(e, function(f) {
        if (f) try {
            var g = J.parse(f);
            if (g.cookieHash != b) {
                V(d).removeItem(e, function() {
                    c(void 0)
                });
                return
            }
            var h = g && g.cachedValue
        } catch (k) {}
        c(h)
    })
};
W.prototype.H = function(a, b, c, d) {
    a = this.u(a);
    void 0 === b || null === b ? V(this).removeItem(a, d) : (b = J.stringify({
        cookieHash: c,
        cachedValue: b
    }), V(this).setItem(a, b, d))
};
var Lh = function() {};
I(Lh, Kh);
Lh.prototype.G = function(a, b, c) {
    V(this).getItem(this.u(a), function(d) {
        if (d) try {
            var e = J.parse(d);
            var f = e && e.cachedValue
        } catch (g) {}
        c(f)
    })
};
Lh.prototype.H = function(a, b, c, d) {
    a = this.u(a);
    void 0 === b || null === b ? V(this).removeItem(a, d) : (b = J.stringify({
        cachedValue: b
    }), V(this).setItem(a, b, d))
};
var Mh = function() {};
I(Mh, Lh);
Mh.prototype.wc = function() {
    return !1
};
Mh.prototype.u = function(a) {
    return [S.Oa, a.origin, a.clientId, a.id].join(S.v)
};
Mh.prototype.Ea = function(a) {
    var b = {};
    a && (a = a.split(S.v), 4 == a.length && (b.origin = a[1], b.clientId = a[2], b.id = a[3]));
    return b
};
var Nh = function() {};
I(Nh, W);
Nh.prototype.u = function(a) {
    return [S.Wc, a.origin, a.clientId].join(S.v)
};
Nh.prototype.Ea = function(a) {
    a = a.split(S.v);
    var b = {};
    3 == a.length && (b.origin = a[1], b.clientId = a[2]);
    return b
};
var Oh = function() {};
I(Oh, W);
Oh.prototype.u = function(a) {
    return [S.we, a.origin, a.clientId].join(S.v)
};
Oh.prototype.G = function(a, b, c) {
    var d = this;
    W.prototype.G.call(this, a, b, function(e) {
        e && e.expires_at ? 6E4 > e.expires_at - (new Date).getTime() ? V(d).removeItem(d.u(a), c) : ve(e.scope, a.scope) && ve(a.scope, e.scope) ? (e.expires_in = Math.floor((e.expires_at - (new Date).getTime()) / 1E3), c && c(e)) : V(d).removeItem(d.u(a), c) : c && c(void 0)
    })
};
Oh.prototype.H = function(a, b, c, d) {
    var e;
    b && b.expires_at && 18E4 < b.expires_at - (new Date).getTime() && (e = b);
    W.prototype.H.call(this, a, e, c, d)
};
var Ph = function() {};
I(Ph, Lh);
Ph.prototype.wc = function() {
    return !1
};
Ph.prototype.u = function(a) {
    return [S.Pa, a.domain, a.crossSubDomains ? "1" : "0", Q.yd(a.policy), a.id || S.Ub].join(S.v)
};
Ph.prototype.Ea = function(a) {
    a = a.split(S.v);
    var b = {};
    5 == a.length && (b.domain = a[1], b.crossSubDomains = "1" == a[2], b.policy = a[3], b.id = a[4]);
    "DEFAULT" == b.policy && delete b.policy;
    b.id == S.Ub && delete b.id;
    return b
};
var Qh = function(a) {
    this.Of = a || S.$c
};
I(Qh, W);
Qh.prototype.u = function(a) {
    return [this.Of, a.origin, a.clientId, a.id || S.Xc].join(S.v)
};
Qh.prototype.G = function(a, b, c) {
    var d = this;
    W.prototype.G.call(this, a, b, function(e) {
        e && e.Ma && e.Ma.expires_at ? a.loginHint != e.Ma.login_hint ? V(d).removeItem(d.u(a), c) : 6E4 > e.Ma.expires_at - (new Date).getTime() ? V(d).removeItem(d.u(a), c) : ve(e.Ma.scope, a.scope) ? ve(e.responseType, a.responseType) ? (e = e.Ma, e.expires_in = Math.floor((e.expires_at - (new Date).getTime()) / 1E3), c && c(e)) : V(d).removeItem(d.u(a), c) : V(d).removeItem(d.u(a), c) : c && c(void 0)
    })
};
Qh.prototype.H = function(a, b, c, d) {
    var e;
    b && b.expires_at && 18E4 < b.expires_at - (new Date).getTime() && (e = {
        Ma: b,
        responseType: a.responseType
    });
    W.prototype.H.call(this, a, e, c, d)
};
var Rh = function(a, b) {
        this.j = a;
        this.Fc = b;
        this.hc = !1;
        this.gb = {};
        this.fb = {};
        this.eb = {}
    },
    Sh = function(a, b) {
        if (!b) throw Error("message object cannot be null.");
        b.rpcToken = a.Fc;
        b = J.stringify(b);
        G("IDP IFrame sends message: " + b);
        window.parent.postMessage(b, a.j)
    },
    X = function(a, b, c) {
        b && Sh(a, {
            id: b,
            result: c
        })
    };
Rh.prototype.Qf = function(a) {
    if (a.source == window.parent && a.origin == this.j) {
        G("IDP Session State IFrame receive message:" + a.data);
        try {
            var b = J.parse(a.data)
        } catch (d) {
            return
        }
        if ((b.rpcToken || this.Fc) && b.rpcToken != this.Fc) G("RPC token mismatch.");
        else if (b && b.method && ("showDialog" == b.method || this.gb[b.method]))
            if ("showDialog" == b.method)
                if (this.hc) Sh(this, {
                    id: b.id,
                    error: "dialog_already_displayed"
                });
                else if (a = b.params, b.id && a && a.dialogType && this.eb[a.dialogType]) {
            var c = this.eb[a.dialogType];
            c.B && !c.B(a) ?
                (G("Bad request."), Sh(this, {
                    id: b.id,
                    error: "bad_request"
                })) : c.m(b)
        } else G("Bad dialog request.");
        else a = this.gb[b.method], a.aa && !b.id ? G("Bad request.") : a.B && !a.B(b) ? (G("Bad request."), Sh(this, {
            id: b.id,
            error: "bad_request"
        })) : a.m(b);
        else G("Bad request.")
    }
};
var Th = function(a, b) {
        if (b && b.type && a.fb[b.type]) {
            var c = a.fb[b.type].filter;
            c && !c(b) || Sh(a, {
                method: "fireIdpEvent",
                params: b
            })
        } else G("Invalid event type.")
    },
    Uh = function(a) {
        Th(a, {
            type: "displayIFrame",
            wf: !1,
            options: {
                fullScreen: !0
            }
        });
        a.hc = !0
    },
    Vh = function(a) {
        Th(a, {
            type: "displayIFrame",
            wf: !0
        });
        a.hc = !1
    },
    Wh = function(a, b) {
        a.gb = {};
        a.fb = {};
        a.eb = {};
        if (b) {
            if (b.F)
                for (var c = 0; c < b.F.length; c++) {
                    var d = b.F[c];
                    if (!d.method || !d.m) throw Error("Error in RPC policy: method or handler is empty.");
                    if (a.gb[d.method]) throw Error("Error in RPC policy: duplicate entry for RPC '" +
                        d.method + "'.");
                    var e = d.method;
                    a.gb[e] = {
                        m: d.m,
                        aa: d.aa,
                        B: d.B,
                        method: e
                    }
                }
            if (b.X)
                for (c = 0; c < b.X.length; c++) {
                    d = b.X[c];
                    if (!d.type) throw Error("Error in Event policy: type is empty.");
                    if (a.fb[d.type]) throw Error("Error in Event policy: duplicate entry for type '" + d.type + "'.");
                    e = d.type;
                    a.fb[e] = {
                        filter: d.filter,
                        type: e
                    }
                }
            if (b.Aa)
                for (c = 0; c < b.Aa.length; c++) {
                    d = b.Aa[c];
                    if (!d.Ba) throw Error("Error in Dialog policy: dialogType is empty.");
                    if (a.eb[d.Ba]) throw Error("Error in Dialog policy: duplicate entry for dialogType '" +
                        d.Ba + "'.");
                    e = d.Ba;
                    a.eb[e] = {
                        Ba: e,
                        m: d.m,
                        B: d.B
                    }
                }
        }
    },
    Xh = function(a, b, c, d) {
        Th(a, {
            type: "sessionStateChanged",
            clientId: b,
            user: c,
            sessionState: d
        })
    },
    Yh = function(a) {
        var b = new Ph,
            c = S.Pa + S.v;
        return function(d) {
            if (d.key && 0 === d.key.indexOf(c)) {
                var e = b.Ea(d.key);
                if (Q.J(a.j, e.domain, e.crossSubDomains, e.policy)) {
                    var f;
                    if (d.newValue) try {
                        var g = J.parse(d.newValue);
                        g && (f = g.cachedValue)
                    } catch (h) {
                        return
                    }
                    Th(a, {
                        type: "sessionSelectorChanged",
                        newValue: f,
                        crossSubDomains: e.crossSubDomains,
                        domain: e.domain,
                        policy: e.policy,
                        id: e.id
                    })
                }
            }
        }
    },
    Zh = function(a) {
        var b = new Mh,
            c = [S.Oa, a.j].join(S.v) + S.v;
        return function(d) {
            if (!d.key && xe()) {
                var e = null,
                    f = [];
                for (d = 0; d < window.localStorage.length; d++) {
                    var g = window.localStorage.key(d);
                    if (0 === g.indexOf(c))
                        if (e) f.push(g);
                        else {
                            var h = window.localStorage.getItem(g);
                            f.push(g);
                            if (h) {
                                try {
                                    var k = J.parse(h)
                                } catch (l) {
                                    continue
                                }
                                k && k.cachedValue && (e = b.Ea(g), e = {
                                    type: "authResult",
                                    clientId: e.clientId,
                                    id: e.id,
                                    authResult: k.cachedValue
                                })
                            }
                        }
                }
                for (d = 0; d < f.length; d++) window.localStorage.removeItem(f[d]);
                (k = e) && Th(a, k)
            } else if (d.key &&
                0 === d.key.indexOf(c) && d.newValue) {
                try {
                    f = J.parse(d.newValue)
                } catch (l) {
                    return
                }
                f && f.cachedValue && (k = b.Ea(d.key), k = {
                    type: "authResult",
                    clientId: k.clientId,
                    id: k.id,
                    authResult: f.cachedValue
                }, Th(a, k))
            }
        }
    },
    $h = function(a, b) {
        this.j = a;
        this.na = b;
        this.md = new Nh;
        this.ie = new Ph;
        this.Nc = new Qh;
        this.Bd = new Oh
    },
    ai = function(a, b, c, d, e) {
        a.md.H({
            origin: a.j,
            clientId: b
        }, {
            user: c.T,
            session: c.T ? c.ma : void 0
        }, d, e)
    },
    bi = function(a, b, c) {
        a.md.G({
            origin: a.j,
            clientId: b
        }, sh(), c)
    },
    ci = function(a, b, c, d, e, f, g) {
        a.Nc.G({
            loginHint: b,
            origin: a.j,
            clientId: c,
            responseType: d,
            scope: e,
            id: f
        }, sh(), g)
    },
    di = function(a, b, c, d, e, f, g) {
        a.Nc.H({
            origin: a.j,
            clientId: c,
            responseType: d,
            id: f
        }, e, b, g)
    },
    ei = function(a, b, c) {
        var d = a.Nc;
        a = {
            origin: a.j,
            clientId: b
        };
        V(d).removeItem(d.u(a), c)
    },
    fi = function(a, b, c, d, e, f) {
        if (!a.J(b, c, e)) throw Error("Permission denied for '" + a.j + "' to read session selector for domain '" + b + "'.");
        a.ie.G({
            domain: b,
            crossSubDomains: c,
            policy: e,
            id: d
        }, void 0, function(g) {
            f && f(g)
        })
    },
    gi = function(a, b, c, d, e, f, g) {
        if (!a.J(b, c, f)) throw Error("Permission denied for '" +
            a.j + "' to write session selector for domain '" + b + "'.");
        a.ie.H({
            domain: b,
            crossSubDomains: c,
            policy: f,
            id: e
        }, d, void 0, g)
    };
$h.prototype.J = function(a, b, c) {
    return Q.J(this.j, a, b, c)
};
var hi = function(a, b, c, d) {
        a.Bd.G({
            origin: a.j,
            clientId: b,
            scope: c
        }, sh(), d)
    },
    ii = function(a, b, c, d, e) {
        a.Bd.H({
            origin: a.j,
            clientId: c
        }, d, b, e)
    },
    ji = function(a, b, c) {
        this.xa = a;
        this.h = b;
        this.o = c;
        this.ma = this.T = void 0
    },
    ki = function(a, b, c) {
        a.T ? c && void 0 !== c[a.T] ? (c = c[a.T], qh(a.ma, c) || (a.ma = c, ai(a.o, a.xa, a, b, function() {
            Xh(a.h, a.xa, a.T, a.ma)
        }))) : a.ma && (a.ma = void 0, ai(a.o, a.xa, a, b, function() {
            Xh(a.h, a.xa, a.T, void 0)
        })) : b && Xh(a.h, a.xa, a.T, void 0)
    },
    mi = function(a, b, c, d) {
        this.na = a;
        this.h = b;
        this.W = c;
        this.o = d;
        this.bb = void 0;
        this.I = {};
        this.Jc = [];
        var e = this;
        this.na.addListener(function(f) {
            li(e, f)
        })
    },
    ni = function(a) {
        var b = [],
            c;
        for (c in a.I) {
            var d = a.I[c].T;
            d && b.push(d)
        }
        return b
    },
    li = function(a, b) {
        if (b.newHash) Ah(a.W, ni(a), function(d) {
            for (var e in a.I) ki(a.I[e], b.newHash, d && d.activeHints)
        });
        else
            for (var c in a.I) ki(a.I[c], b.newHash, void 0)
    },
    oi = function(a, b, c, d, e) {
        var f = a.I[b];
        f || (f = new ji(b, a.h, a.o), a.I[b] = f);
        a = f;
        b = c.login_hint;
        c = c.session_state;
        a.T != b ? (a.T = b, a.ma = b ? c : void 0, ai(a.o, a.xa, a, d, e)) : e && e()
    },
    pi = function(a, b, c) {
        var d =
            a.I[b];
        d ? c(!0) : bi(a.o, b, function(e) {
            e ? (d = new ji(b, a.h, a.o), a.I[b] = d, d.T = e.user, d.ma = e.session, c(!0)) : zh(a.W, b, function(f) {
                f && f.valid ? (f = new ji(b, a.h, a.o), a.I[b] = f, ai(a.o, b, f, sh(), function() {
                    c(!0)
                })) : c(!1)
            })
        })
    },
    qi = function(a, b) {
        ye() || Ae() ? a.Jc.push(b) : ue(xe() ? document : window, "storage", b)
    },
    ri = function(a, b, c, d) {
        this.j = a;
        this.Pe = c;
        this.qg = void 0 === d ? !1 : d;
        this.h = new Rh(a, b);
        this.na = new rh(S.ue);
        this.W = new wh(a);
        this.o = new $h(a, this.na);
        this.ca = new mi(this.na, this.h, this.W, this.o)
    };
m = ri.prototype;
m.start = function() {
    var a = this,
        b = function() {
            a.h.Qf.apply(a.h, arguments)
        },
        c = function() {
            Th(a.h, {
                type: "idpReady",
                cookieDisabled: !navigator.cookieEnabled
            });
            G("Initialize IDP IFrame successfully.")
        },
        d = function(e) {
            var f = window;
            if (f.removeEventListener) f.removeEventListener("message", b, !1);
            else if (f.detachEvent) f.detachEvent("onmessage", b);
            else throw Error("Remove event handler for message failed.");
            th(a.na);
            Th(a.h, {
                type: "idpError",
                error: e.message
            })
        };
    try {
        Wh(this.h, this.createPolicy()), ue(window, "message",
            b), qi(this.ca, Yh(this.h)), qi(this.ca, Zh(this.h)), vh(this.na), Q.xf(c, d, this.Pe, this.qg)
    } catch (e) {
        d(e)
    }
};
m.Kf = function(a) {
    var b = this;
    pi(this.ca, (a.params || {}).clientId, function(c) {
        X(b.h, a.id, c)
    })
};
m.hf = function(a) {
    var b = a.params || {},
        c = this,
        d = function(q) {
            X(c.h, a.id, q)
        },
        e = b.clientId,
        f = b.loginHint,
        g = b.request,
        h = b.sessionSelector;
    g.client_id = e;
    g.login_hint = f;
    g.ss_domain = h.domain;
    var k = sh();
    if (k) {
        var l = !!g.enable_serial_consent,
            p = function(q) {
                q && !q.error && q.login_hint ? (q.first_issued_at = (new Date).getTime(), q.expires_at = q.first_issued_at + 1E3 * q.expires_in, q.session_state || (q.session_state = {}), l || q.scope || (q.scope = g.scope), b.skipCache ? oi(c.ca, e, q, k, function() {
                    d(q)
                }) : di(c.o, k, e, g.response_type, q, b.id,
                    function() {
                        oi(c.ca, e, q, k, function() {
                            d(q)
                        })
                    })) : (q = q || {}, d(q))
            };
        b.forceRefresh ? Ch(this.W, g, p) : ci(this.o, f, e, g.response_type, g.scope, b.id, function(q) {
            q && 18E4 < q.expires_at - (new Date).getTime() ? oi(c.ca, e, q, k, function() {
                d(q)
            }) : Ch(c.W, g, p)
        })
    } else X(c.h, a.id, {
        error: "user_logged_out"
    }), b.userInteracted && (f = si(), ti(f).tc(), f.flush())
};
m.pf = function(a) {
    var b = this,
        c = function(g) {
            X(b.h, a.id, g)
        };
    if (sh()) {
        var d = a.params || {},
            e = d.request,
            f = d.sessionSelector;
        e.client_id = d.clientId;
        e.login_hint = d.loginHint;
        e.ss_domain = f.domain;
        Dh(this.W, e, c)
    } else c({
        error: "user_logged_out"
    })
};
m.Yf = function(a) {
    var b = a.params || {},
        c = b.clientId,
        d = this;
    Fh(this.W, b.token, function(e) {
        ei(d.o, c, function() {
            X(d.h, a.id, e)
        })
    })
};
m.ng = function(a) {
    if (ye() || Ae()) {
        var b = a.params || {},
            c = (new Mh).u({
                clientId: b.clientId,
                id: b.id,
                origin: b.origin
            });
        b = this.ca;
        if (ye() || Ae()) {
            b.bb && b.bb.stop();
            b.bb = new nh(c);
            for (c = 0; c < b.Jc.length; c++) b.bb.addListener(b.Jc[c]);
            b.bb.start()
        }
    }
    X(this.h, a.id, !0)
};
m.gf = function(a) {
    var b = this,
        c = a.params || {};
    fi(this.o, c.domain, c.crossSubDomains, c.id, c.policy, function(d) {
        X(b.h, a.id, d)
    })
};
m.hg = function(a) {
    var b = a.params || {},
        c = b.hint,
        d = !!b.disabled,
        e = b.domain,
        f = b.crossSubDomains,
        g = b.id,
        h = b.policy,
        k = this;
    if (c || d) var l = {
        hint: c,
        disabled: d
    };
    gi(this.o, e, f, l, g, h, function() {
        Th(k.h, {
            type: "sessionSelectorChanged",
            newValue: l,
            domain: e,
            crossSubDomains: f,
            id: g,
            policy: h
        });
        X(k.h, a.id, !0)
    })
};
m.Hf = function(a) {
    var b = a.params || {},
        c = this,
        d = function(l) {
            X(c.h, a.id, l)
        },
        e = b.clientId,
        f = b.request,
        g = b.sessionSelector;
    f.client_id = e;
    f.response_type = "id_token";
    f.ss_domain = g.domain;
    var h = sh();
    if (h) {
        var k = function(l) {
            l && !l.error ? (l.first_issued_at = (new Date).getTime(), l.expires_at = l.first_issued_at + 1E3 * l.expires_in, l.scope = f.scope, ii(c.o, h, e, l, function() {
                d(l)
            })) : (l = l || {
                error: "No response returned from Server."
            }, d(l))
        };
        b.forceRefresh ? Eh(this.W, f, k) : hi(this.o, e, f.scope, function(l) {
            l ? d(l) : Eh(c.W, f, k)
        })
    } else d({
        scope: f.scope,
        sessions: []
    })
};
m.Ne = function(a) {
    if (document.hasStorageAccess && re(document.hasStorageAccess)) {
        var b = this;
        document.hasStorageAccess().then(function(c) {
            X(b.h, a.id, {
                hasAccess: c
            })
        }, function(c) {
            G("CheckStorageAccess failed: " + c);
            X(b.h, a.id, {
                hasAccess: !1
            })
        })
    } else X(this.h, a.id, {
        hasAccess: !0
    })
};
m.Lf = function(a) {
    a = a && a.params || {};
    return a.clientId && !T(a.clientId)
};
m.uf = function(a) {
    var b = a && a.params || {};
    a = b.loginHint;
    var c = !T(b.id),
        d = b.clientId && !T(b.clientId),
        e = !!b.request,
        f = e && b.request.scope;
    (b = (e = e && b.request.response_type) && 0 <= b.request.response_type.indexOf("code")) && G("Bad request: 'code' response_type is not supported.");
    return a && c && d && f && e && !b
};
m.qf = function(a) {
    a = a && a.params || {};
    var b = !T(a.id),
        c = a.clientId && !T(a.clientId),
        d = !!a.request && a.request.scope;
    return a.loginHint && b && c && d
};
m.sf = function(a) {
    a = a && a.params || {};
    var b = a.domain && !T(a.domain),
        c = !T(a.policy);
    return !T(a.id) && b && c && this.o.J(a.domain, !!a.crossSubDomains, a.policy)
};
m.ig = function(a) {
    a = a && a.params || {};
    var b = a.domain && !T(a.domain),
        c = !T(a.policy);
    return !T(a.id) && b && c && this.o.J(a.domain, !!a.crossSubDomains, a.policy) && S.Ee(a)
};
m.If = function(a) {
    a = a && a.params || {};
    var b = a.clientId && !T(a.clientId),
        c = !!a.request && a.request.scope;
    return !T(a.id) && b && c
};
m.Zf = function(a) {
    a = a && a.params || {};
    var b = !!a.token,
        c = a.clientId && !T(a.clientId);
    return !T(a.id) && b && c
};
m.og = function(a) {
    a = a && a.params || {};
    var b = a.origin && !T(a.origin),
        c = a.id && !T(a.id);
    return a.clientId && !T(a.clientId) && b && c
};
m.eg = function(a) {
    var b;
    if (b = a.clientId) a = a.clientId, b = !(!a || !this.ca.I[a]);
    return b
};
m.Ge = function(a) {
    var b;
    if (b = a.clientId) b = a.clientId, b = !(!b || !this.ca.I[b]);
    return b && a.id && a.authResult
};
m.Ze = function(a) {
    return !!a.hide || !!a.options
};
m.dg = function(a) {
    return a.domain && this.o.J(a.domain, a.crossSubDomains, a.policy)
};
var Z = function(a, b) {
    return function() {
        return b.apply(a, arguments)
    }
};
ri.prototype.createPolicy = function() {
    var a = {
        F: [],
        X: [],
        Aa: []
    };
    ui(this, a);
    return a
};
var ui = function(a, b) {
        b.F.push({
            method: "monitorClient",
            m: Z(a, a.Kf),
            aa: !1,
            B: Z(a, a.Lf)
        });
        b.F.push({
            method: "getTokenResponse",
            m: Z(a, a.hf),
            aa: !0,
            B: Z(a, a.uf)
        });
        b.F.push({
            method: "getOnlineCode",
            m: Z(a, a.pf),
            aa: !0,
            B: Z(a, a.qf)
        });
        b.F.push({
            method: "getSessionSelector",
            m: Z(a, a.gf),
            aa: !0,
            B: Z(a, a.sf)
        });
        b.F.push({
            method: "setSessionSelector",
            m: Z(a, a.hg),
            aa: !1,
            B: Z(a, a.ig)
        });
        b.F.push({
            method: "listIdpSessions",
            m: Z(a, a.Hf),
            aa: !0,
            B: Z(a, a.If)
        });
        b.F.push({
            method: "revoke",
            m: Z(a, a.Yf),
            B: Z(a, a.Zf)
        });
        b.F.push({
            method: "startPolling",
            m: Z(a, a.ng),
            B: Z(a, a.og)
        });
        b.X.push({
            type: "idpReady"
        });
        b.X.push({
            type: "idpError"
        });
        b.X.push({
            type: "sessionStateChanged",
            filter: Z(a, a.eg)
        });
        b.X.push({
            type: "sessionSelectorChanged",
            filter: Z(a, a.dg)
        });
        b.X.push({
            type: "authResult",
            filter: Z(a, a.Ge)
        });
        b.X.push({
            type: "displayIFrame",
            filter: Z(a, a.Ze)
        });
        b.F.push({
            method: "checkStorageAccess",
            m: Z(a, a.Ne),
            aa: !0
        })
    },
    vi = function(a) {
        this.he = a
    },
    ti = function(a) {
        a = new Me(a.he);
        return new wi(a)
    };
vi.prototype.flush = function() {
    this.he.Hc()
};
var si = function() {
        var a = new bh;
        a = new Ke(a);
        return new vi(a)
    },
    wi = function(a) {
        this.Re = a;
        this.Le = db() ? "IE" : cb() ? "Opera" : B("OPR") ? "OPR" : B("Edge") ? "Edge" : B("Edg/") ? "Edg" : hb() ? "Android" : gb() ? "Chrome" : eb() ? "Firefox" : !B("iPad") && !B("iPhone") || fb() || gb() || B("Coast") || eb() || !B("AppleWebKit") ? fb() ? "Safari" : "Other" : "iOS Webview";
        (a = ib()) ? (a = a.split("."), a = 2 > a.length ? a[0] : a[0] + "." + a[1]) : a = "N/A";
        this.Ke = a
    };
wi.prototype.tc = function() {
    this.Re.tc(this.Le, this.Ke)
};
var xi = "client_id origin ss_domain scope privileged authuser".split(" ");
S.pb = "response_type login_hint client_id origin scope ss_domain authuser hd include_granted_scopes nonce spec_compliant".split(" ");
var yi = function() {};
I(yi, W);
yi.prototype.u = function(a) {
    a = void 0 === a ? {} : a;
    return ["gsi_gs", void 0 === a.origin ? null : a.origin, void 0 === a.clientId ? null : a.clientId].join(S.v)
};
yi.prototype.G = function(a, b, c) {
    var d = this;
    c = void 0 === c ? function() {} : c;
    W.prototype.G.call(this, a, b, function(e) {
        e ? !e.expires_at || e.expires_at <= (new Date).getTime() ? V(d).removeItem(d.u(a), function() {
            return c(null)
        }) : (e.expires_at = void 0, c(e)) : c(null)
    })
};
yi.prototype.H = function(a, b, c, d) {
    b && (b.expires_at = (new Date).getTime() + 864E5);
    W.prototype.H.call(this, a, b, c, d)
};
var Ai = function(a, b, c) {
    b.origin = a.j;
    b.privileged = !0;
    b = Bh(b, xi);
    yh(S.Wb, b, zi(a.j), function(d) {
        c(d)
    })
};

function zi(a) {
    var b = {},
        c = S.rf();
    if (c) {
        if (!c) throw Error("Session cookie value cannot be empty.");
        c = new Ib(new Jb, Ha(c));
        a = Ha(a);
        c.reset();
        c.update(a);
        a = c.digest();
        a = Gb(a);
        b["X-Csrf-Token"] = a
    }
    return b
};
ri.prototype.ef = function(a) {
    var b = this;
    a = void 0 === a ? {} : a;
    var c = a.id,
        d = void 0 === a.params ? {} : a.params,
        e = function(p) {
            p && p.sessions ? (p = Bi(f, p.sessions), X(b.h, c, p)) : X(b.h, c, null)
        },
        f = d.loginHint;
    delete d.loginHint;
    var g = sh();
    if (g) {
        a = d.clientId;
        var h = d.request;
        d = d.sessionSelector;
        h.client_id = a;
        h.ss_domain = d.domain;
        var k = new yi,
            l = {
                clientId: a,
                origin: this.j
            };
        k.G(l, g, function(p) {
            p ? e(p) : Ai(b.W, h, function(q) {
                !q || q.error ? e(null) : k.H(l, q, g, function() {
                    e(q)
                })
            })
        })
    } else e(null)
};

function Bi(a, b) {
    if (!b.length) return null;
    var c = a.toLowerCase();
    b = t(b);
    for (var d = b.next(); !d.done; d = b.next())
        if (d = d.value, d.login_hint) {
            if (a === d.obfuscatedGaiaId) return d.login_hint;
            if (d.emails && d.emails.length)
                for (var e = t(d.emails), f = e.next(); !f.done; f = e.next())
                    if (c === f.value.toLowerCase()) return d.login_hint
        }
    return null
}
ri.prototype.lg = function(a) {
    Ci(this, a, !1)
};
ri.prototype.mg = function(a) {
    Ci(this, a, !0)
};
var Ci = function(a, b, c) {
    document.requestStorageAccess && re(document.requestStorageAccess) ? document.hasStorageAccess().then(function(d) {
        if (d) X(a.h, b.id, {
            hasAccess: !0
        });
        else {
            d = new Gd({
                origin: a.j
            });
            var e = document.getElementById("container");
            (c ? d.Uf : d.Tf).call(d, e, function() {
                Vh(a.h);
                X(a.h, b.id, {
                    hasAccess: !0
                })
            }, function() {
                Vh(a.h);
                X(a.h, b.id, {
                    hasAccess: !1
                })
            });
            Uh(a.h)
        }
    }, function(d) {
        G("StorageAccess check failed: " + d);
        X(a.h, b.id, {
            hasAccess: !1
        })
    }) : X(a.h, b.id, {
        hasAccess: !0
    })
};
ri.prototype.ff = function(a) {
    a = void 0 === a ? {} : a;
    a = void 0 === a.params ? {} : a.params;
    var b = !!a.clientId && !T(a.clientId),
        c = !!a.request,
        d = !!a.sessionSelector;
    return !!a.loginHint && b && c && d
};
ri.prototype.createPolicy = function() {
    var a = {
        F: [],
        Aa: [],
        X: []
    };
    ui(this, a);
    a.F.push({
        method: "gsi:fetchLoginHint",
        m: Z(this, this.ef),
        aa: !0,
        B: Z(this, this.ff)
    });
    a.Aa.push({
        Ba: "itpNewGrant",
        m: Z(this, this.lg)
    });
    a.Aa.push({
        Ba: "itpRegrant",
        m: Z(this, this.mg)
    });
    return a
};
S.ad = "/o/oauth2/iframerpc?action=sessionState";
S.Vc = "/o/oauth2/iframerpc?action=checkOrigin";
S.Zc = "/o/oauth2/iframerpc?action=issueToken";
S.Yc = "/o/oauth2/iframerpc?action=issueOnlineCode";
S.Wb = "/o/oauth2/iframerpc?action=listSessions";
var Di = function() {
        var a = te("origin"),
            b = !!te("supportBlocked3PCookies");
        if (!a) throw Error("Failed to get parent origin from URL hash!");
        var c = te("rpcToken");
        if (!c) throw Error("Failed to get rpcToken from URL hash!");
        var d = !!te("clearCache"),
            e = te("debug");
        pe = "0" != e && !!e;
        (new ri(a, c, d, b)).start()
    },
    Ei = ["lso", "startIdpIFrame"],
    Fi = x;
Ei[0] in Fi || "undefined" == typeof Fi.execScript || Fi.execScript("var " + Ei[0]);
for (var Gi; Ei.length && (Gi = Ei.shift());) Ei.length || void 0 === Di ? Fi = Fi[Gi] && Fi[Gi] !== Object.prototype[Gi] ? Fi[Gi] : Fi[Gi] = {} : Fi[Gi] = Di;